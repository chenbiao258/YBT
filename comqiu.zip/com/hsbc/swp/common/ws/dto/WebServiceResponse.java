
package com.hsbc.swp.common.ws.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.CalculateAggregateAffordabilityRatioWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.CalculateGoalPortfolioWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.CalculateRiskCapacityWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RecordActivityAuditLogWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RecordGoalPlannerInfoWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RecordGoalSolutionDetailWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalPlannerInfoWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSolutionDetailWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSummaryListByLeadIdWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSummaryListWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.ReviewInvestmentsWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.ProductSelectionWSResponse;


/**
 * <p>Java class for webServiceResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="webServiceResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="reasonCode" type="{http://dto.ws.common.swp.hsbc.com/}reasonCode" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="responseDetails" type="{http://dto.ws.common.swp.hsbc.com/}responseDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "webServiceResponse", propOrder = {
    "reasonCode",
    "responseDetails"
})
@XmlSeeAlso({
    ReviewInvestmentsWSResponse.class,
    RecordGoalSolutionDetailWSResponse.class,
    CalculateAggregateAffordabilityRatioWSResponse.class,
    CalculateRiskCapacityWSResponse.class,
    RetrieveGoalSummaryListByLeadIdWSResponse.class,
    CalculateGoalPortfolioWSResponse.class,
    RetrieveGoalSummaryListWSResponse.class,
    RecordGoalPlannerInfoWSResponse.class,
    RetrieveGoalPlannerInfoWSResponse.class,
    RetrieveGoalSolutionDetailWSResponse.class,
    ProductSelectionWSResponse.class,
    RecordActivityAuditLogWSResponse.class
})
public abstract class WebServiceResponse {

    @XmlElement(nillable = true)
    protected List<ReasonCode> reasonCode;
    protected ResponseDetails responseDetails;

    /**
     * Gets the value of the reasonCode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reasonCode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReasonCode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReasonCode }
     * 
     * 
     */
    public List<ReasonCode> getReasonCode() {
        if (reasonCode == null) {
            reasonCode = new ArrayList<ReasonCode>();
        }
        return this.reasonCode;
    }

    /**
     * Gets the value of the responseDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ResponseDetails }
     *     
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets the value of the responseDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ResponseDetails }
     *     
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }

}
