
package com.hsbc.swp.common.ws.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.CalculateAggregateAffordabilityRatioWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.CalculateGoalPortfolioWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.CalculateRiskCapacityWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RecordActivityAuditLogWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RecordGoalPlannerInfoWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RecordGoalSolutionDetailWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalPlannerInfoWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSolutionDetailWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSummaryListByLeadIdWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSummaryListWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.ReviewInvestmentsWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.ProductSelectionWSRequest;


/**
 * <p>Java class for webServiceRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="webServiceRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sessionInfo" type="{http://dto.ws.common.swp.hsbc.com/}sessionInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "webServiceRequest", propOrder = {
    "sessionInfo"
})
@XmlSeeAlso({
    CalculateAggregateAffordabilityRatioWSRequest.class,
    CalculateRiskCapacityWSRequest.class,
    RecordActivityAuditLogWSRequest.class,
    ReviewInvestmentsWSRequest.class,
    RecordGoalPlannerInfoWSRequest.class,
    CalculateGoalPortfolioWSRequest.class,
    ProductSelectionWSRequest.class,
    RecordGoalSolutionDetailWSRequest.class,
    RetrieveGoalSummaryListWSRequest.class,
    RetrieveGoalPlannerInfoWSRequest.class,
    RetrieveGoalSolutionDetailWSRequest.class,
    RetrieveGoalSummaryListByLeadIdWSRequest.class
})
public abstract class WebServiceRequest {

    protected SessionInfo sessionInfo;

    /**
     * Gets the value of the sessionInfo property.
     * 
     * @return
     *     possible object is
     *     {@link SessionInfo }
     *     
     */
    public SessionInfo getSessionInfo() {
        return sessionInfo;
    }

    /**
     * Sets the value of the sessionInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link SessionInfo }
     *     
     */
    public void setSessionInfo(SessionInfo value) {
        this.sessionInfo = value;
    }

}
