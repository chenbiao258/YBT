
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.simulator.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for status complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="status">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="financialGoalProcessStatusChangeText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="financialGoalProcessStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "status", propOrder = {
    "financialGoalProcessStatusChangeText",
    "financialGoalProcessStatusCode"
})
public class Status {

    protected String financialGoalProcessStatusChangeText;
    protected String financialGoalProcessStatusCode;

    /**
     * Gets the value of the financialGoalProcessStatusChangeText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialGoalProcessStatusChangeText() {
        return financialGoalProcessStatusChangeText;
    }

    /**
     * Sets the value of the financialGoalProcessStatusChangeText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialGoalProcessStatusChangeText(String value) {
        this.financialGoalProcessStatusChangeText = value;
    }

    /**
     * Gets the value of the financialGoalProcessStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialGoalProcessStatusCode() {
        return financialGoalProcessStatusCode;
    }

    /**
     * Sets the value of the financialGoalProcessStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialGoalProcessStatusCode(String value) {
        this.financialGoalProcessStatusCode = value;
    }

}
