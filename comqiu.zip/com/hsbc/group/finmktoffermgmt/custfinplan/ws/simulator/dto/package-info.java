@javax.xml.bind.annotation.XmlSchema(namespace = "http://dto.simulator.ws.custfinplan.finmktoffermgmt.group.hsbc.com/")
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.simulator.dto;
