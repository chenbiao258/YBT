
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.taxoptimization.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for acctInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="acctInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountNickName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountProductTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="accountTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="countryInvestmentAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dashboardAccountSubGroupIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="groupMemberInvestmentAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="investmentAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="placeholderIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="restrictWrapperFromSwitchingComd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="restrictWrapperFromSwitchingIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wrapperDocument" type="{http://dto.taxoptimization.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}wrapperDocument" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "acctInfo", propOrder = {
    "accountNickName",
    "accountNumber",
    "accountProductTypeCode",
    "accountSequenceNumber",
    "accountTypeCode",
    "countryInvestmentAccountCode",
    "currencyAccountCode",
    "dashboardAccountSubGroupIdentifier",
    "groupMemberInvestmentAccountCode",
    "investmentAccountNumber",
    "placeholderIndicator",
    "restrictWrapperFromSwitchingComd",
    "restrictWrapperFromSwitchingIndicator",
    "wrapperDocument"
})
public class AcctInfo {

    protected String accountNickName;
    protected String accountNumber;
    protected String accountProductTypeCode;
    protected long accountSequenceNumber;
    protected String accountTypeCode;
    protected String countryInvestmentAccountCode;
    protected String currencyAccountCode;
    protected String dashboardAccountSubGroupIdentifier;
    protected String groupMemberInvestmentAccountCode;
    protected String investmentAccountNumber;
    protected String placeholderIndicator;
    protected String restrictWrapperFromSwitchingComd;
    protected String restrictWrapperFromSwitchingIndicator;
    @XmlElement(nillable = true)
    protected List<WrapperDocument> wrapperDocument;

    /**
     * Gets the value of the accountNickName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNickName() {
        return accountNickName;
    }

    /**
     * Sets the value of the accountNickName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNickName(String value) {
        this.accountNickName = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the accountProductTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountProductTypeCode() {
        return accountProductTypeCode;
    }

    /**
     * Sets the value of the accountProductTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountProductTypeCode(String value) {
        this.accountProductTypeCode = value;
    }

    /**
     * Gets the value of the accountSequenceNumber property.
     * 
     */
    public long getAccountSequenceNumber() {
        return accountSequenceNumber;
    }

    /**
     * Sets the value of the accountSequenceNumber property.
     * 
     */
    public void setAccountSequenceNumber(long value) {
        this.accountSequenceNumber = value;
    }

    /**
     * Gets the value of the accountTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTypeCode() {
        return accountTypeCode;
    }

    /**
     * Sets the value of the accountTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTypeCode(String value) {
        this.accountTypeCode = value;
    }

    /**
     * Gets the value of the countryInvestmentAccountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryInvestmentAccountCode() {
        return countryInvestmentAccountCode;
    }

    /**
     * Sets the value of the countryInvestmentAccountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryInvestmentAccountCode(String value) {
        this.countryInvestmentAccountCode = value;
    }

    /**
     * Gets the value of the currencyAccountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAccountCode() {
        return currencyAccountCode;
    }

    /**
     * Sets the value of the currencyAccountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAccountCode(String value) {
        this.currencyAccountCode = value;
    }

    /**
     * Gets the value of the dashboardAccountSubGroupIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDashboardAccountSubGroupIdentifier() {
        return dashboardAccountSubGroupIdentifier;
    }

    /**
     * Sets the value of the dashboardAccountSubGroupIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDashboardAccountSubGroupIdentifier(String value) {
        this.dashboardAccountSubGroupIdentifier = value;
    }

    /**
     * Gets the value of the groupMemberInvestmentAccountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupMemberInvestmentAccountCode() {
        return groupMemberInvestmentAccountCode;
    }

    /**
     * Sets the value of the groupMemberInvestmentAccountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupMemberInvestmentAccountCode(String value) {
        this.groupMemberInvestmentAccountCode = value;
    }

    /**
     * Gets the value of the investmentAccountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentAccountNumber() {
        return investmentAccountNumber;
    }

    /**
     * Sets the value of the investmentAccountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentAccountNumber(String value) {
        this.investmentAccountNumber = value;
    }

    /**
     * Gets the value of the placeholderIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlaceholderIndicator() {
        return placeholderIndicator;
    }

    /**
     * Sets the value of the placeholderIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlaceholderIndicator(String value) {
        this.placeholderIndicator = value;
    }

    /**
     * Gets the value of the restrictWrapperFromSwitchingComd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestrictWrapperFromSwitchingComd() {
        return restrictWrapperFromSwitchingComd;
    }

    /**
     * Sets the value of the restrictWrapperFromSwitchingComd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestrictWrapperFromSwitchingComd(String value) {
        this.restrictWrapperFromSwitchingComd = value;
    }

    /**
     * Gets the value of the restrictWrapperFromSwitchingIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestrictWrapperFromSwitchingIndicator() {
        return restrictWrapperFromSwitchingIndicator;
    }

    /**
     * Sets the value of the restrictWrapperFromSwitchingIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestrictWrapperFromSwitchingIndicator(String value) {
        this.restrictWrapperFromSwitchingIndicator = value;
    }

    /**
     * Gets the value of the wrapperDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wrapperDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWrapperDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WrapperDocument }
     * 
     * 
     */
    public List<WrapperDocument> getWrapperDocument() {
        if (wrapperDocument == null) {
            wrapperDocument = new ArrayList<WrapperDocument>();
        }
        return this.wrapperDocument;
    }

}
