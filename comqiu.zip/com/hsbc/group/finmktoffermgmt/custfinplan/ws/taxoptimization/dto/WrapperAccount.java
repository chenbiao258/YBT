
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.taxoptimization.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.CurrencyAmount;


/**
 * <p>Java class for wrapperAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="wrapperAccount">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountAllocationSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="acctInfo" type="{http://dto.taxoptimization.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}acctInfo" minOccurs="0"/>
 *         &lt;element name="constraintIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyAssetAllocationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyInvestmentCurrentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyInvestmentInitialCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyInvestmentTargetCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="eligibleIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="investmentCurrentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="investmentInitialAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="investmentMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="investmentTargetAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="wrapperAdditionalDetails" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}currencyAmount" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "wrapperAccount", propOrder = {
    "accountAllocationSequenceNumber",
    "acctInfo",
    "constraintIndicator",
    "currencyAssetAllocationCode",
    "currencyInvestmentCurrentCode",
    "currencyInvestmentInitialCode",
    "currencyInvestmentTargetCode",
    "eligibleIndicator",
    "investmentCurrentAmount",
    "investmentInitialAmount",
    "investmentMonthlyAmount",
    "investmentTargetAmount",
    "wrapperAdditionalDetails"
})
public class WrapperAccount {

    protected long accountAllocationSequenceNumber;
    protected AcctInfo acctInfo;
    protected String constraintIndicator;
    protected String currencyAssetAllocationCode;
    protected String currencyInvestmentCurrentCode;
    protected String currencyInvestmentInitialCode;
    protected String currencyInvestmentTargetCode;
    protected String eligibleIndicator;
    protected BigDecimal investmentCurrentAmount;
    protected BigDecimal investmentInitialAmount;
    protected BigDecimal investmentMonthlyAmount;
    protected BigDecimal investmentTargetAmount;
    @XmlElement(nillable = true)
    protected List<CurrencyAmount> wrapperAdditionalDetails;

    /**
     * Gets the value of the accountAllocationSequenceNumber property.
     * 
     */
    public long getAccountAllocationSequenceNumber() {
        return accountAllocationSequenceNumber;
    }

    /**
     * Sets the value of the accountAllocationSequenceNumber property.
     * 
     */
    public void setAccountAllocationSequenceNumber(long value) {
        this.accountAllocationSequenceNumber = value;
    }

    /**
     * Gets the value of the acctInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AcctInfo }
     *     
     */
    public AcctInfo getAcctInfo() {
        return acctInfo;
    }

    /**
     * Sets the value of the acctInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AcctInfo }
     *     
     */
    public void setAcctInfo(AcctInfo value) {
        this.acctInfo = value;
    }

    /**
     * Gets the value of the constraintIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConstraintIndicator() {
        return constraintIndicator;
    }

    /**
     * Sets the value of the constraintIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConstraintIndicator(String value) {
        this.constraintIndicator = value;
    }

    /**
     * Gets the value of the currencyAssetAllocationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAssetAllocationCode() {
        return currencyAssetAllocationCode;
    }

    /**
     * Sets the value of the currencyAssetAllocationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAssetAllocationCode(String value) {
        this.currencyAssetAllocationCode = value;
    }

    /**
     * Gets the value of the currencyInvestmentCurrentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentCurrentCode() {
        return currencyInvestmentCurrentCode;
    }

    /**
     * Sets the value of the currencyInvestmentCurrentCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentCurrentCode(String value) {
        this.currencyInvestmentCurrentCode = value;
    }

    /**
     * Gets the value of the currencyInvestmentInitialCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentInitialCode() {
        return currencyInvestmentInitialCode;
    }

    /**
     * Sets the value of the currencyInvestmentInitialCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentInitialCode(String value) {
        this.currencyInvestmentInitialCode = value;
    }

    /**
     * Gets the value of the currencyInvestmentTargetCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentTargetCode() {
        return currencyInvestmentTargetCode;
    }

    /**
     * Sets the value of the currencyInvestmentTargetCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentTargetCode(String value) {
        this.currencyInvestmentTargetCode = value;
    }

    /**
     * Gets the value of the eligibleIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibleIndicator() {
        return eligibleIndicator;
    }

    /**
     * Sets the value of the eligibleIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibleIndicator(String value) {
        this.eligibleIndicator = value;
    }

    /**
     * Gets the value of the investmentCurrentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentCurrentAmount() {
        return investmentCurrentAmount;
    }

    /**
     * Sets the value of the investmentCurrentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentCurrentAmount(BigDecimal value) {
        this.investmentCurrentAmount = value;
    }

    /**
     * Gets the value of the investmentInitialAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentInitialAmount() {
        return investmentInitialAmount;
    }

    /**
     * Sets the value of the investmentInitialAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentInitialAmount(BigDecimal value) {
        this.investmentInitialAmount = value;
    }

    /**
     * Gets the value of the investmentMonthlyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentMonthlyAmount() {
        return investmentMonthlyAmount;
    }

    /**
     * Sets the value of the investmentMonthlyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentMonthlyAmount(BigDecimal value) {
        this.investmentMonthlyAmount = value;
    }

    /**
     * Gets the value of the investmentTargetAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentTargetAmount() {
        return investmentTargetAmount;
    }

    /**
     * Sets the value of the investmentTargetAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentTargetAmount(BigDecimal value) {
        this.investmentTargetAmount = value;
    }

    /**
     * Gets the value of the wrapperAdditionalDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wrapperAdditionalDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWrapperAdditionalDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrencyAmount }
     * 
     * 
     */
    public List<CurrencyAmount> getWrapperAdditionalDetails() {
        if (wrapperAdditionalDetails == null) {
            wrapperAdditionalDetails = new ArrayList<CurrencyAmount>();
        }
        return this.wrapperAdditionalDetails;
    }

}
