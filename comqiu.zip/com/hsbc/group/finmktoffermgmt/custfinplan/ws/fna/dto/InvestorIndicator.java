
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for investorIndicator complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="investorIndicator">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="indicatorAcceptanceDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="indicatorExpiryDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="indicatorKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indicatorValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "investorIndicator", propOrder = {
    "indicatorAcceptanceDateTime",
    "indicatorExpiryDateTime",
    "indicatorKey",
    "indicatorValue"
})
public class InvestorIndicator {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar indicatorAcceptanceDateTime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar indicatorExpiryDateTime;
    protected String indicatorKey;
    protected String indicatorValue;

    /**
     * Gets the value of the indicatorAcceptanceDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIndicatorAcceptanceDateTime() {
        return indicatorAcceptanceDateTime;
    }

    /**
     * Sets the value of the indicatorAcceptanceDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIndicatorAcceptanceDateTime(XMLGregorianCalendar value) {
        this.indicatorAcceptanceDateTime = value;
    }

    /**
     * Gets the value of the indicatorExpiryDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIndicatorExpiryDateTime() {
        return indicatorExpiryDateTime;
    }

    /**
     * Sets the value of the indicatorExpiryDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIndicatorExpiryDateTime(XMLGregorianCalendar value) {
        this.indicatorExpiryDateTime = value;
    }

    /**
     * Gets the value of the indicatorKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndicatorKey() {
        return indicatorKey;
    }

    /**
     * Sets the value of the indicatorKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndicatorKey(String value) {
        this.indicatorKey = value;
    }

    /**
     * Gets the value of the indicatorValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndicatorValue() {
        return indicatorValue;
    }

    /**
     * Sets the value of the indicatorValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndicatorValue(String value) {
        this.indicatorValue = value;
    }

}
