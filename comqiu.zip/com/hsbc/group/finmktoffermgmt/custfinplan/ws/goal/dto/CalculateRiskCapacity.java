
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for calculateRiskCapacity complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="calculateRiskCapacity">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="calculateRiskCapacityCriteria" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculateRiskCapacityCriteria" minOccurs="0"/>
 *         &lt;element name="calculateTimeHorizonCriteria" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculateTimeHorizonCriteria" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="goalTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="needTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateRiskCapacity", propOrder = {
    "calculateRiskCapacityCriteria",
    "calculateTimeHorizonCriteria",
    "goalTypeCode",
    "needTypeCode"
})
public class CalculateRiskCapacity {

    protected CalculateRiskCapacityCriteria calculateRiskCapacityCriteria;
    @XmlElement(nillable = true)
    protected List<CalculateTimeHorizonCriteria> calculateTimeHorizonCriteria;
    protected String goalTypeCode;
    protected String needTypeCode;

    /**
     * Gets the value of the calculateRiskCapacityCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link CalculateRiskCapacityCriteria }
     *     
     */
    public CalculateRiskCapacityCriteria getCalculateRiskCapacityCriteria() {
        return calculateRiskCapacityCriteria;
    }

    /**
     * Sets the value of the calculateRiskCapacityCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link CalculateRiskCapacityCriteria }
     *     
     */
    public void setCalculateRiskCapacityCriteria(CalculateRiskCapacityCriteria value) {
        this.calculateRiskCapacityCriteria = value;
    }

    /**
     * Gets the value of the calculateTimeHorizonCriteria property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the calculateTimeHorizonCriteria property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCalculateTimeHorizonCriteria().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CalculateTimeHorizonCriteria }
     * 
     * 
     */
    public List<CalculateTimeHorizonCriteria> getCalculateTimeHorizonCriteria() {
        if (calculateTimeHorizonCriteria == null) {
            calculateTimeHorizonCriteria = new ArrayList<CalculateTimeHorizonCriteria>();
        }
        return this.calculateTimeHorizonCriteria;
    }

    /**
     * Gets the value of the goalTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTypeCode() {
        return goalTypeCode;
    }

    /**
     * Sets the value of the goalTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTypeCode(String value) {
        this.goalTypeCode = value;
    }

    /**
     * Gets the value of the needTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeedTypeCode() {
        return needTypeCode;
    }

    /**
     * Sets the value of the needTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeedTypeCode(String value) {
        this.needTypeCode = value;
    }

}
