
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for goalAttribute complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="goalAttribute">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="goalAttributeKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalAttributeValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalAttribute", propOrder = {
    "goalAttributeKey",
    "goalAttributeValue"
})
public class GoalAttribute {

    protected String goalAttributeKey;
    protected String goalAttributeValue;

    /**
     * Gets the value of the goalAttributeKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalAttributeKey() {
        return goalAttributeKey;
    }

    /**
     * Sets the value of the goalAttributeKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalAttributeKey(String value) {
        this.goalAttributeKey = value;
    }

    /**
     * Gets the value of the goalAttributeValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalAttributeValue() {
        return goalAttributeValue;
    }

    /**
     * Sets the value of the goalAttributeValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalAttributeValue(String value) {
        this.goalAttributeValue = value;
    }

}
