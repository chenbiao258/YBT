
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.ProductId;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ProductAttribute;


/**
 * <p>Java class for productAssetAllocationSnapshot complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productAssetAllocationSnapshot">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="currencyAssetAllocationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyProductCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productAssetAllocationSnapshotId" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAssetAllocationSnapshotId" minOccurs="0"/>
 *         &lt;element name="productAttribute" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAttribute" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="productDocument" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAttribute" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="productId" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productId" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="productNationalLanguageSupportName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productSubTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="riskLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productAssetAllocationSnapshot", propOrder = {
    "currencyAssetAllocationCode",
    "currencyProductCode",
    "productAssetAllocationSnapshotId",
    "productAttribute",
    "productDocument",
    "productId",
    "productNationalLanguageSupportName",
    "productSubTypeCode",
    "riskLevelCode"
})
public class ProductAssetAllocationSnapshot {

    protected String currencyAssetAllocationCode;
    protected String currencyProductCode;
    protected ProductAssetAllocationSnapshotId productAssetAllocationSnapshotId;
    @XmlElement(nillable = true)
    protected List<ProductAttribute> productAttribute;
    @XmlElement(nillable = true)
    protected List<ProductAttribute> productDocument;
    @XmlElement(nillable = true)
    protected List<ProductId> productId;
    protected String productNationalLanguageSupportName;
    protected String productSubTypeCode;
    protected String riskLevelCode;

    /**
     * Gets the value of the currencyAssetAllocationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAssetAllocationCode() {
        return currencyAssetAllocationCode;
    }

    /**
     * Sets the value of the currencyAssetAllocationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAssetAllocationCode(String value) {
        this.currencyAssetAllocationCode = value;
    }

    /**
     * Gets the value of the currencyProductCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyProductCode() {
        return currencyProductCode;
    }

    /**
     * Sets the value of the currencyProductCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyProductCode(String value) {
        this.currencyProductCode = value;
    }

    /**
     * Gets the value of the productAssetAllocationSnapshotId property.
     * 
     * @return
     *     possible object is
     *     {@link ProductAssetAllocationSnapshotId }
     *     
     */
    public ProductAssetAllocationSnapshotId getProductAssetAllocationSnapshotId() {
        return productAssetAllocationSnapshotId;
    }

    /**
     * Sets the value of the productAssetAllocationSnapshotId property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductAssetAllocationSnapshotId }
     *     
     */
    public void setProductAssetAllocationSnapshotId(ProductAssetAllocationSnapshotId value) {
        this.productAssetAllocationSnapshotId = value;
    }

    /**
     * Gets the value of the productAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAttribute }
     * 
     * 
     */
    public List<ProductAttribute> getProductAttribute() {
        if (productAttribute == null) {
            productAttribute = new ArrayList<ProductAttribute>();
        }
        return this.productAttribute;
    }

    /**
     * Gets the value of the productDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAttribute }
     * 
     * 
     */
    public List<ProductAttribute> getProductDocument() {
        if (productDocument == null) {
            productDocument = new ArrayList<ProductAttribute>();
        }
        return this.productDocument;
    }

    /**
     * Gets the value of the productId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductId }
     * 
     * 
     */
    public List<ProductId> getProductId() {
        if (productId == null) {
            productId = new ArrayList<ProductId>();
        }
        return this.productId;
    }

    /**
     * Gets the value of the productNationalLanguageSupportName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductNationalLanguageSupportName() {
        return productNationalLanguageSupportName;
    }

    /**
     * Sets the value of the productNationalLanguageSupportName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductNationalLanguageSupportName(String value) {
        this.productNationalLanguageSupportName = value;
    }

    /**
     * Gets the value of the productSubTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSubTypeCode() {
        return productSubTypeCode;
    }

    /**
     * Sets the value of the productSubTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSubTypeCode(String value) {
        this.productSubTypeCode = value;
    }

    /**
     * Gets the value of the riskLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRiskLevelCode() {
        return riskLevelCode;
    }

    /**
     * Sets the value of the riskLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRiskLevelCode(String value) {
        this.riskLevelCode = value;
    }

}
