
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.taxoptimization.dto.WrapperAccount;


/**
 * <p>Java class for productIdDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productIdDto">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="productAlternativeNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productCodeAlternativeClassCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productTradableCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wrapperAccount" type="{http://dto.taxoptimization.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}wrapperAccount" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productIdDto", propOrder = {
    "productAlternativeNumber",
    "productCodeAlternativeClassCode",
    "productSelectionMethodCode",
    "productTradableCode",
    "productTypeCode",
    "wrapperAccount"
})
public class ProductIdDto {

    protected String productAlternativeNumber;
    protected String productCodeAlternativeClassCode;
    protected String productSelectionMethodCode;
    protected String productTradableCode;
    protected String productTypeCode;
    @XmlElement(nillable = true)
    protected List<WrapperAccount> wrapperAccount;

    /**
     * Gets the value of the productAlternativeNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductAlternativeNumber() {
        return productAlternativeNumber;
    }

    /**
     * Sets the value of the productAlternativeNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductAlternativeNumber(String value) {
        this.productAlternativeNumber = value;
    }

    /**
     * Gets the value of the productCodeAlternativeClassCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCodeAlternativeClassCode() {
        return productCodeAlternativeClassCode;
    }

    /**
     * Sets the value of the productCodeAlternativeClassCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCodeAlternativeClassCode(String value) {
        this.productCodeAlternativeClassCode = value;
    }

    /**
     * Gets the value of the productSelectionMethodCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * Sets the value of the productSelectionMethodCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * Gets the value of the productTradableCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductTradableCode() {
        return productTradableCode;
    }

    /**
     * Sets the value of the productTradableCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductTradableCode(String value) {
        this.productTradableCode = value;
    }

    /**
     * Gets the value of the productTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductTypeCode() {
        return productTypeCode;
    }

    /**
     * Sets the value of the productTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductTypeCode(String value) {
        this.productTypeCode = value;
    }

    /**
     * Gets the value of the wrapperAccount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wrapperAccount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWrapperAccount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WrapperAccount }
     * 
     * 
     */
    public List<WrapperAccount> getWrapperAccount() {
        if (wrapperAccount == null) {
            wrapperAccount = new ArrayList<WrapperAccount>();
        }
        return this.wrapperAccount;
    }

}
