
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for goalBasicInfoDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="goalBasicInfoDto">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="arrangementIdentifierFinancialPlanning" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="goalCompleteDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="goalObjectiveTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="goalTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="needTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productIdDto" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productIdDto" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="reopenCount" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="reportLastPrintDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalBasicInfoDto", propOrder = {
    "arrangementIdentifierFinancialPlanning",
    "goalCompleteDate",
    "goalObjectiveTypeCode",
    "goalSequenceNumber",
    "goalTypeCode",
    "needTypeCode",
    "productIdDto",
    "reopenCount",
    "reportLastPrintDate",
    "status"
})
public class GoalBasicInfoDto {

    protected Long arrangementIdentifierFinancialPlanning;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalCompleteDate;
    protected String goalObjectiveTypeCode;
    protected Long goalSequenceNumber;
    protected String goalTypeCode;
    protected String needTypeCode;
    @XmlElement(nillable = true)
    protected List<ProductIdDto> productIdDto;
    protected Long reopenCount;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar reportLastPrintDate;
    protected String status;

    /**
     * Gets the value of the arrangementIdentifierFinancialPlanning property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getArrangementIdentifierFinancialPlanning() {
        return arrangementIdentifierFinancialPlanning;
    }

    /**
     * Sets the value of the arrangementIdentifierFinancialPlanning property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setArrangementIdentifierFinancialPlanning(Long value) {
        this.arrangementIdentifierFinancialPlanning = value;
    }

    /**
     * Gets the value of the goalCompleteDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalCompleteDate() {
        return goalCompleteDate;
    }

    /**
     * Sets the value of the goalCompleteDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalCompleteDate(XMLGregorianCalendar value) {
        this.goalCompleteDate = value;
    }

    /**
     * Gets the value of the goalObjectiveTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalObjectiveTypeCode() {
        return goalObjectiveTypeCode;
    }

    /**
     * Sets the value of the goalObjectiveTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalObjectiveTypeCode(String value) {
        this.goalObjectiveTypeCode = value;
    }

    /**
     * Gets the value of the goalSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getGoalSequenceNumber() {
        return goalSequenceNumber;
    }

    /**
     * Sets the value of the goalSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setGoalSequenceNumber(Long value) {
        this.goalSequenceNumber = value;
    }

    /**
     * Gets the value of the goalTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTypeCode() {
        return goalTypeCode;
    }

    /**
     * Sets the value of the goalTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTypeCode(String value) {
        this.goalTypeCode = value;
    }

    /**
     * Gets the value of the needTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeedTypeCode() {
        return needTypeCode;
    }

    /**
     * Sets the value of the needTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeedTypeCode(String value) {
        this.needTypeCode = value;
    }

    /**
     * Gets the value of the productIdDto property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productIdDto property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductIdDto().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductIdDto }
     * 
     * 
     */
    public List<ProductIdDto> getProductIdDto() {
        if (productIdDto == null) {
            productIdDto = new ArrayList<ProductIdDto>();
        }
        return this.productIdDto;
    }

    /**
     * Gets the value of the reopenCount property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getReopenCount() {
        return reopenCount;
    }

    /**
     * Sets the value of the reopenCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setReopenCount(Long value) {
        this.reopenCount = value;
    }

    /**
     * Gets the value of the reportLastPrintDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReportLastPrintDate() {
        return reportLastPrintDate;
    }

    /**
     * Sets the value of the reportLastPrintDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReportLastPrintDate(XMLGregorianCalendar value) {
        this.reportLastPrintDate = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
