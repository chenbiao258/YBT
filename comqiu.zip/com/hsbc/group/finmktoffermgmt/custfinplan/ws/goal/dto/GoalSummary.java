
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;


/**
 * <p>Java class for goalSummary complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="goalSummary">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="additionalAmount" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalAmount" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="additionalInformation" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalInformation" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="comment" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}comment" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="financialGoalProcessPreviousStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="financialGoalProcessStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fundAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="fundAmountCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fundMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="fundMonthlyCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalAcknowledgementDatetime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="goalCompletionDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="goalDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalFeature" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalFeature" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" minOccurs="0"/>
 *         &lt;element name="goalMonthCount" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="goalObjectiveTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalOrderExecutionDatetime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="goalStartDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="goalTargetAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="goalTargetAmountCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalTargetEndDatetime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="goalTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/>
 *         &lt;element name="needTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recordCreateDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="recordUpdateDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="riskCapacityAssignDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="riskCapacityLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="riskCapacityRecommendLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="riskToleranceLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="skipRiskProfilingIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalSummary", propOrder = {
    "additionalAmount",
    "additionalInformation",
    "comment",
    "customers",
    "financialGoalProcessPreviousStatusCode",
    "financialGoalProcessStatusCode",
    "fundAmount",
    "fundAmountCurrencyCode",
    "fundMonthlyAmount",
    "fundMonthlyCurrencyCode",
    "goalAcknowledgementDatetime",
    "goalCompletionDateTime",
    "goalDescription",
    "goalFeature",
    "goalKey",
    "goalMonthCount",
    "goalObjectiveTypeCode",
    "goalOrderExecutionDatetime",
    "goalStartDate",
    "goalTargetAmount",
    "goalTargetAmountCurrencyCode",
    "goalTargetEndDatetime",
    "goalTypeCode",
    "jointCustomer",
    "needTypeCode",
    "recordCreateDateTime",
    "recordUpdateDateTime",
    "riskCapacityAssignDate",
    "riskCapacityLevelNumber",
    "riskCapacityRecommendLevelNumber",
    "riskToleranceLevelNumber",
    "skipRiskProfilingIndicator"
})
public class GoalSummary {

    @XmlElement(nillable = true)
    protected List<AdditionalAmount> additionalAmount;
    @XmlElement(nillable = true)
    protected List<AdditionalInformation> additionalInformation;
    @XmlElement(nillable = true)
    protected List<Comment> comment;
    @XmlElement(nillable = true)
    protected List<Customer> customers;
    protected String financialGoalProcessPreviousStatusCode;
    protected String financialGoalProcessStatusCode;
    protected BigDecimal fundAmount;
    protected String fundAmountCurrencyCode;
    protected BigDecimal fundMonthlyAmount;
    protected String fundMonthlyCurrencyCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalAcknowledgementDatetime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalCompletionDateTime;
    protected String goalDescription;
    @XmlElement(nillable = true)
    protected List<GoalFeature> goalFeature;
    protected GoalKey goalKey;
    protected int goalMonthCount;
    protected String goalObjectiveTypeCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalOrderExecutionDatetime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalStartDate;
    protected BigDecimal goalTargetAmount;
    protected String goalTargetAmountCurrencyCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalTargetEndDatetime;
    protected String goalTypeCode;
    protected Customer jointCustomer;
    protected String needTypeCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar recordCreateDateTime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar recordUpdateDateTime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar riskCapacityAssignDate;
    protected Integer riskCapacityLevelNumber;
    protected Integer riskCapacityRecommendLevelNumber;
    protected Integer riskToleranceLevelNumber;
    protected String skipRiskProfilingIndicator;

    /**
     * Gets the value of the additionalAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmount }
     * 
     * 
     */
    public List<AdditionalAmount> getAdditionalAmount() {
        if (additionalAmount == null) {
            additionalAmount = new ArrayList<AdditionalAmount>();
        }
        return this.additionalAmount;
    }

    /**
     * Gets the value of the additionalInformation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalInformation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalInformation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalInformation }
     * 
     * 
     */
    public List<AdditionalInformation> getAdditionalInformation() {
        if (additionalInformation == null) {
            additionalInformation = new ArrayList<AdditionalInformation>();
        }
        return this.additionalInformation;
    }

    /**
     * Gets the value of the comment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Comment }
     * 
     * 
     */
    public List<Comment> getComment() {
        if (comment == null) {
            comment = new ArrayList<Comment>();
        }
        return this.comment;
    }

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the financialGoalProcessPreviousStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialGoalProcessPreviousStatusCode() {
        return financialGoalProcessPreviousStatusCode;
    }

    /**
     * Sets the value of the financialGoalProcessPreviousStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialGoalProcessPreviousStatusCode(String value) {
        this.financialGoalProcessPreviousStatusCode = value;
    }

    /**
     * Gets the value of the financialGoalProcessStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialGoalProcessStatusCode() {
        return financialGoalProcessStatusCode;
    }

    /**
     * Sets the value of the financialGoalProcessStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialGoalProcessStatusCode(String value) {
        this.financialGoalProcessStatusCode = value;
    }

    /**
     * Gets the value of the fundAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundAmount() {
        return fundAmount;
    }

    /**
     * Sets the value of the fundAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundAmount(BigDecimal value) {
        this.fundAmount = value;
    }

    /**
     * Gets the value of the fundAmountCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundAmountCurrencyCode() {
        return fundAmountCurrencyCode;
    }

    /**
     * Sets the value of the fundAmountCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundAmountCurrencyCode(String value) {
        this.fundAmountCurrencyCode = value;
    }

    /**
     * Gets the value of the fundMonthlyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundMonthlyAmount() {
        return fundMonthlyAmount;
    }

    /**
     * Sets the value of the fundMonthlyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundMonthlyAmount(BigDecimal value) {
        this.fundMonthlyAmount = value;
    }

    /**
     * Gets the value of the fundMonthlyCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundMonthlyCurrencyCode() {
        return fundMonthlyCurrencyCode;
    }

    /**
     * Sets the value of the fundMonthlyCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundMonthlyCurrencyCode(String value) {
        this.fundMonthlyCurrencyCode = value;
    }

    /**
     * Gets the value of the goalAcknowledgementDatetime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalAcknowledgementDatetime() {
        return goalAcknowledgementDatetime;
    }

    /**
     * Sets the value of the goalAcknowledgementDatetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalAcknowledgementDatetime(XMLGregorianCalendar value) {
        this.goalAcknowledgementDatetime = value;
    }

    /**
     * Gets the value of the goalCompletionDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalCompletionDateTime() {
        return goalCompletionDateTime;
    }

    /**
     * Sets the value of the goalCompletionDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalCompletionDateTime(XMLGregorianCalendar value) {
        this.goalCompletionDateTime = value;
    }

    /**
     * Gets the value of the goalDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalDescription() {
        return goalDescription;
    }

    /**
     * Sets the value of the goalDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalDescription(String value) {
        this.goalDescription = value;
    }

    /**
     * Gets the value of the goalFeature property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalFeature property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalFeature().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalFeature }
     * 
     * 
     */
    public List<GoalFeature> getGoalFeature() {
        if (goalFeature == null) {
            goalFeature = new ArrayList<GoalFeature>();
        }
        return this.goalFeature;
    }

    /**
     * Gets the value of the goalKey property.
     * 
     * @return
     *     possible object is
     *     {@link GoalKey }
     *     
     */
    public GoalKey getGoalKey() {
        return goalKey;
    }

    /**
     * Sets the value of the goalKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link GoalKey }
     *     
     */
    public void setGoalKey(GoalKey value) {
        this.goalKey = value;
    }

    /**
     * Gets the value of the goalMonthCount property.
     * 
     */
    public int getGoalMonthCount() {
        return goalMonthCount;
    }

    /**
     * Sets the value of the goalMonthCount property.
     * 
     */
    public void setGoalMonthCount(int value) {
        this.goalMonthCount = value;
    }

    /**
     * Gets the value of the goalObjectiveTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalObjectiveTypeCode() {
        return goalObjectiveTypeCode;
    }

    /**
     * Sets the value of the goalObjectiveTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalObjectiveTypeCode(String value) {
        this.goalObjectiveTypeCode = value;
    }

    /**
     * Gets the value of the goalOrderExecutionDatetime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalOrderExecutionDatetime() {
        return goalOrderExecutionDatetime;
    }

    /**
     * Sets the value of the goalOrderExecutionDatetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalOrderExecutionDatetime(XMLGregorianCalendar value) {
        this.goalOrderExecutionDatetime = value;
    }

    /**
     * Gets the value of the goalStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalStartDate() {
        return goalStartDate;
    }

    /**
     * Sets the value of the goalStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalStartDate(XMLGregorianCalendar value) {
        this.goalStartDate = value;
    }

    /**
     * Gets the value of the goalTargetAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoalTargetAmount() {
        return goalTargetAmount;
    }

    /**
     * Sets the value of the goalTargetAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoalTargetAmount(BigDecimal value) {
        this.goalTargetAmount = value;
    }

    /**
     * Gets the value of the goalTargetAmountCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTargetAmountCurrencyCode() {
        return goalTargetAmountCurrencyCode;
    }

    /**
     * Sets the value of the goalTargetAmountCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTargetAmountCurrencyCode(String value) {
        this.goalTargetAmountCurrencyCode = value;
    }

    /**
     * Gets the value of the goalTargetEndDatetime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalTargetEndDatetime() {
        return goalTargetEndDatetime;
    }

    /**
     * Sets the value of the goalTargetEndDatetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalTargetEndDatetime(XMLGregorianCalendar value) {
        this.goalTargetEndDatetime = value;
    }

    /**
     * Gets the value of the goalTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTypeCode() {
        return goalTypeCode;
    }

    /**
     * Sets the value of the goalTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTypeCode(String value) {
        this.goalTypeCode = value;
    }

    /**
     * Gets the value of the jointCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * Sets the value of the jointCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * Gets the value of the needTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeedTypeCode() {
        return needTypeCode;
    }

    /**
     * Sets the value of the needTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeedTypeCode(String value) {
        this.needTypeCode = value;
    }

    /**
     * Gets the value of the recordCreateDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRecordCreateDateTime() {
        return recordCreateDateTime;
    }

    /**
     * Sets the value of the recordCreateDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRecordCreateDateTime(XMLGregorianCalendar value) {
        this.recordCreateDateTime = value;
    }

    /**
     * Gets the value of the recordUpdateDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRecordUpdateDateTime() {
        return recordUpdateDateTime;
    }

    /**
     * Sets the value of the recordUpdateDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRecordUpdateDateTime(XMLGregorianCalendar value) {
        this.recordUpdateDateTime = value;
    }

    /**
     * Gets the value of the riskCapacityAssignDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRiskCapacityAssignDate() {
        return riskCapacityAssignDate;
    }

    /**
     * Sets the value of the riskCapacityAssignDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRiskCapacityAssignDate(XMLGregorianCalendar value) {
        this.riskCapacityAssignDate = value;
    }

    /**
     * Gets the value of the riskCapacityLevelNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskCapacityLevelNumber() {
        return riskCapacityLevelNumber;
    }

    /**
     * Sets the value of the riskCapacityLevelNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskCapacityLevelNumber(Integer value) {
        this.riskCapacityLevelNumber = value;
    }

    /**
     * Gets the value of the riskCapacityRecommendLevelNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskCapacityRecommendLevelNumber() {
        return riskCapacityRecommendLevelNumber;
    }

    /**
     * Sets the value of the riskCapacityRecommendLevelNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskCapacityRecommendLevelNumber(Integer value) {
        this.riskCapacityRecommendLevelNumber = value;
    }

    /**
     * Gets the value of the riskToleranceLevelNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskToleranceLevelNumber() {
        return riskToleranceLevelNumber;
    }

    /**
     * Sets the value of the riskToleranceLevelNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskToleranceLevelNumber(Integer value) {
        this.riskToleranceLevelNumber = value;
    }

    /**
     * Gets the value of the skipRiskProfilingIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSkipRiskProfilingIndicator() {
        return skipRiskProfilingIndicator;
    }

    /**
     * Sets the value of the skipRiskProfilingIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSkipRiskProfilingIndicator(String value) {
        this.skipRiskProfilingIndicator = value;
    }

}
