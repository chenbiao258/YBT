
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link LeadIdInfoResponseDto }
     * 
     */
    public LeadIdInfoResponseDto createLeadIdInfoResponseDto() {
        return new LeadIdInfoResponseDto();
    }

    /**
     * Create an instance of {@link AdditionalInformation }
     * 
     */
    public AdditionalInformation createAdditionalInformation() {
        return new AdditionalInformation();
    }

    /**
     * Create an instance of {@link CalculateTimeHorizonCriteria }
     * 
     */
    public CalculateTimeHorizonCriteria createCalculateTimeHorizonCriteria() {
        return new CalculateTimeHorizonCriteria();
    }

    /**
     * Create an instance of {@link RequestInvestorIndicator }
     * 
     */
    public RequestInvestorIndicator createRequestInvestorIndicator() {
        return new RequestInvestorIndicator();
    }

    /**
     * Create an instance of {@link AdditionalAmount }
     * 
     */
    public AdditionalAmount createAdditionalAmount() {
        return new AdditionalAmount();
    }

    /**
     * Create an instance of {@link LeadIdInfoRequestDto }
     * 
     */
    public LeadIdInfoRequestDto createLeadIdInfoRequestDto() {
        return new LeadIdInfoRequestDto();
    }

    /**
     * Create an instance of {@link GoalFeature }
     * 
     */
    public GoalFeature createGoalFeature() {
        return new GoalFeature();
    }

    /**
     * Create an instance of {@link CommentAction }
     * 
     */
    public CommentAction createCommentAction() {
        return new CommentAction();
    }

    /**
     * Create an instance of {@link GoalLocalFields }
     * 
     */
    public GoalLocalFields createGoalLocalFields() {
        return new GoalLocalFields();
    }

    /**
     * Create an instance of {@link CalculateRiskCapacityCriteria }
     * 
     */
    public CalculateRiskCapacityCriteria createCalculateRiskCapacityCriteria() {
        return new CalculateRiskCapacityCriteria();
    }

    /**
     * Create an instance of {@link ProductIdDto }
     * 
     */
    public ProductIdDto createProductIdDto() {
        return new ProductIdDto();
    }

    /**
     * Create an instance of {@link CalculateRiskCapacity }
     * 
     */
    public CalculateRiskCapacity createCalculateRiskCapacity() {
        return new CalculateRiskCapacity();
    }

    /**
     * Create an instance of {@link CalculatedRiskCapacity }
     * 
     */
    public CalculatedRiskCapacity createCalculatedRiskCapacity() {
        return new CalculatedRiskCapacity();
    }

    /**
     * Create an instance of {@link GoalAttribute }
     * 
     */
    public GoalAttribute createGoalAttribute() {
        return new GoalAttribute();
    }

    /**
     * Create an instance of {@link RequestComment }
     * 
     */
    public RequestComment createRequestComment() {
        return new RequestComment();
    }

    /**
     * Create an instance of {@link ProductAssetAllocationSnapshotId }
     * 
     */
    public ProductAssetAllocationSnapshotId createProductAssetAllocationSnapshotId() {
        return new ProductAssetAllocationSnapshotId();
    }

    /**
     * Create an instance of {@link DocumentChecklist }
     * 
     */
    public DocumentChecklist createDocumentChecklist() {
        return new DocumentChecklist();
    }

    /**
     * Create an instance of {@link GoalKey }
     * 
     */
    public GoalKey createGoalKey() {
        return new GoalKey();
    }

    /**
     * Create an instance of {@link GoalCommentDetail }
     * 
     */
    public GoalCommentDetail createGoalCommentDetail() {
        return new GoalCommentDetail();
    }

    /**
     * Create an instance of {@link ProductAssetAllocationSnapshot }
     * 
     */
    public ProductAssetAllocationSnapshot createProductAssetAllocationSnapshot() {
        return new ProductAssetAllocationSnapshot();
    }

    /**
     * Create an instance of {@link Comment }
     * 
     */
    public Comment createComment() {
        return new Comment();
    }

    /**
     * Create an instance of {@link GoalSummary }
     * 
     */
    public GoalSummary createGoalSummary() {
        return new GoalSummary();
    }

    /**
     * Create an instance of {@link GoalBasicInfoDto }
     * 
     */
    public GoalBasicInfoDto createGoalBasicInfoDto() {
        return new GoalBasicInfoDto();
    }

}
