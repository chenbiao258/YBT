
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for goalKey complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="goalKey">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="arrangementIdentifierFinancialPlanning" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="goalSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalKey", propOrder = {
    "arrangementIdentifierFinancialPlanning",
    "goalSequenceNumber"
})
public class GoalKey {

    protected Long arrangementIdentifierFinancialPlanning;
    protected Long goalSequenceNumber;

    /**
     * Gets the value of the arrangementIdentifierFinancialPlanning property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getArrangementIdentifierFinancialPlanning() {
        return arrangementIdentifierFinancialPlanning;
    }

    /**
     * Sets the value of the arrangementIdentifierFinancialPlanning property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setArrangementIdentifierFinancialPlanning(Long value) {
        this.arrangementIdentifierFinancialPlanning = value;
    }

    /**
     * Gets the value of the goalSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getGoalSequenceNumber() {
        return goalSequenceNumber;
    }

    /**
     * Sets the value of the goalSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setGoalSequenceNumber(Long value) {
        this.goalSequenceNumber = value;
    }

}
