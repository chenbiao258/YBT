
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for productAssetAllocationSnapshotId complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productAssetAllocationSnapshotId">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="allocationSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="arrangementIdentifierFinancialPlanning" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="goalSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productAssetAllocationSnapshotId", propOrder = {
    "allocationSequenceNumber",
    "arrangementIdentifierFinancialPlanning",
    "goalSequenceNumber",
    "productSelectionMethodCode"
})
public class ProductAssetAllocationSnapshotId {

    protected Long allocationSequenceNumber;
    protected Long arrangementIdentifierFinancialPlanning;
    protected Long goalSequenceNumber;
    protected String productSelectionMethodCode;

    /**
     * Gets the value of the allocationSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAllocationSequenceNumber() {
        return allocationSequenceNumber;
    }

    /**
     * Sets the value of the allocationSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAllocationSequenceNumber(Long value) {
        this.allocationSequenceNumber = value;
    }

    /**
     * Gets the value of the arrangementIdentifierFinancialPlanning property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getArrangementIdentifierFinancialPlanning() {
        return arrangementIdentifierFinancialPlanning;
    }

    /**
     * Sets the value of the arrangementIdentifierFinancialPlanning property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setArrangementIdentifierFinancialPlanning(Long value) {
        this.arrangementIdentifierFinancialPlanning = value;
    }

    /**
     * Gets the value of the goalSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getGoalSequenceNumber() {
        return goalSequenceNumber;
    }

    /**
     * Sets the value of the goalSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setGoalSequenceNumber(Long value) {
        this.goalSequenceNumber = value;
    }

    /**
     * Gets the value of the productSelectionMethodCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * Sets the value of the productSelectionMethodCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

}
