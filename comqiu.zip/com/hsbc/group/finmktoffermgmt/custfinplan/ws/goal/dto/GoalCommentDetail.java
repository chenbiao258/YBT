
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for goalCommentDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="goalCommentDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" minOccurs="0"/>
 *         &lt;element name="goalLevelCommentActionList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}commentAction" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="goalLevelCommentList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}comment" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="goalLevelReqCommentList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}requestComment" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalCommentDetail", propOrder = {
    "goalKey",
    "goalLevelCommentActionList",
    "goalLevelCommentList",
    "goalLevelReqCommentList"
})
public class GoalCommentDetail {

    protected GoalKey goalKey;
    @XmlElement(nillable = true)
    protected List<CommentAction> goalLevelCommentActionList;
    @XmlElement(nillable = true)
    protected List<Comment> goalLevelCommentList;
    @XmlElement(nillable = true)
    protected List<RequestComment> goalLevelReqCommentList;

    /**
     * Gets the value of the goalKey property.
     * 
     * @return
     *     possible object is
     *     {@link GoalKey }
     *     
     */
    public GoalKey getGoalKey() {
        return goalKey;
    }

    /**
     * Sets the value of the goalKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link GoalKey }
     *     
     */
    public void setGoalKey(GoalKey value) {
        this.goalKey = value;
    }

    /**
     * Gets the value of the goalLevelCommentActionList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalLevelCommentActionList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalLevelCommentActionList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommentAction }
     * 
     * 
     */
    public List<CommentAction> getGoalLevelCommentActionList() {
        if (goalLevelCommentActionList == null) {
            goalLevelCommentActionList = new ArrayList<CommentAction>();
        }
        return this.goalLevelCommentActionList;
    }

    /**
     * Gets the value of the goalLevelCommentList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalLevelCommentList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalLevelCommentList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Comment }
     * 
     * 
     */
    public List<Comment> getGoalLevelCommentList() {
        if (goalLevelCommentList == null) {
            goalLevelCommentList = new ArrayList<Comment>();
        }
        return this.goalLevelCommentList;
    }

    /**
     * Gets the value of the goalLevelReqCommentList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalLevelReqCommentList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalLevelReqCommentList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestComment }
     * 
     * 
     */
    public List<RequestComment> getGoalLevelReqCommentList() {
        if (goalLevelReqCommentList == null) {
            goalLevelReqCommentList = new ArrayList<RequestComment>();
        }
        return this.goalLevelReqCommentList;
    }

}
