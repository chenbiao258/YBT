@javax.xml.bind.annotation.XmlSchema(namespace = "http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/")
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto;
