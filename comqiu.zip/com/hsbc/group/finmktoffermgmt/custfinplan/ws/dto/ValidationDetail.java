
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for validationDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="validationDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="allowOverrideIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="valiadationResultCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="validationResultAttributes" type="{http://dto.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}validationResultAttribute" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="validationResultLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "validationDetail", propOrder = {
    "allowOverrideIndicator",
    "reasonCode",
    "valiadationResultCode",
    "validationResultAttributes",
    "validationResultLevelCode"
})
public class ValidationDetail {

    protected String allowOverrideIndicator;
    protected String reasonCode;
    protected String valiadationResultCode;
    @XmlElement(nillable = true)
    protected List<ValidationResultAttribute> validationResultAttributes;
    protected String validationResultLevelCode;

    /**
     * Gets the value of the allowOverrideIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowOverrideIndicator() {
        return allowOverrideIndicator;
    }

    /**
     * Sets the value of the allowOverrideIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowOverrideIndicator(String value) {
        this.allowOverrideIndicator = value;
    }

    /**
     * Gets the value of the reasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

    /**
     * Gets the value of the valiadationResultCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValiadationResultCode() {
        return valiadationResultCode;
    }

    /**
     * Sets the value of the valiadationResultCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValiadationResultCode(String value) {
        this.valiadationResultCode = value;
    }

    /**
     * Gets the value of the validationResultAttributes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the validationResultAttributes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValidationResultAttributes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValidationResultAttribute }
     * 
     * 
     */
    public List<ValidationResultAttribute> getValidationResultAttributes() {
        if (validationResultAttributes == null) {
            validationResultAttributes = new ArrayList<ValidationResultAttribute>();
        }
        return this.validationResultAttributes;
    }

    /**
     * Gets the value of the validationResultLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidationResultLevelCode() {
        return validationResultLevelCode;
    }

    /**
     * Sets the value of the validationResultLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidationResultLevelCode(String value) {
        this.validationResultLevelCode = value;
    }

}
