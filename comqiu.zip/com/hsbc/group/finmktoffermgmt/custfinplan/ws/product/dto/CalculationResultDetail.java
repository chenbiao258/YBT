
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for calculationResultDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="calculationResultDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fundContributeCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fundContributeTotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="goalTargetAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="goalTargetCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalTargetYearNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="returnRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="returnShortfallAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="returnShortfallCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="savingMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="savingMonthlyCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="simulateSegmentIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wealthProjectedCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wealthProjectedTotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculationResultDetail", propOrder = {
    "fundContributeCurrencyCode",
    "fundContributeTotalAmount",
    "goalTargetAmount",
    "goalTargetCurrencyCode",
    "goalTargetYearNumber",
    "returnRate",
    "returnShortfallAmount",
    "returnShortfallCurrencyCode",
    "savingMonthlyAmount",
    "savingMonthlyCurrencyCode",
    "simulateSegmentIndicator",
    "wealthProjectedCurrencyCode",
    "wealthProjectedTotalAmount"
})
public class CalculationResultDetail {

    protected String fundContributeCurrencyCode;
    protected BigDecimal fundContributeTotalAmount;
    protected BigDecimal goalTargetAmount;
    protected String goalTargetCurrencyCode;
    protected String goalTargetYearNumber;
    protected BigDecimal returnRate;
    protected BigDecimal returnShortfallAmount;
    protected String returnShortfallCurrencyCode;
    protected BigDecimal savingMonthlyAmount;
    protected String savingMonthlyCurrencyCode;
    protected String simulateSegmentIndicator;
    protected String wealthProjectedCurrencyCode;
    protected BigDecimal wealthProjectedTotalAmount;

    /**
     * Gets the value of the fundContributeCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundContributeCurrencyCode() {
        return fundContributeCurrencyCode;
    }

    /**
     * Sets the value of the fundContributeCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundContributeCurrencyCode(String value) {
        this.fundContributeCurrencyCode = value;
    }

    /**
     * Gets the value of the fundContributeTotalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundContributeTotalAmount() {
        return fundContributeTotalAmount;
    }

    /**
     * Sets the value of the fundContributeTotalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundContributeTotalAmount(BigDecimal value) {
        this.fundContributeTotalAmount = value;
    }

    /**
     * Gets the value of the goalTargetAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoalTargetAmount() {
        return goalTargetAmount;
    }

    /**
     * Sets the value of the goalTargetAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoalTargetAmount(BigDecimal value) {
        this.goalTargetAmount = value;
    }

    /**
     * Gets the value of the goalTargetCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTargetCurrencyCode() {
        return goalTargetCurrencyCode;
    }

    /**
     * Sets the value of the goalTargetCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTargetCurrencyCode(String value) {
        this.goalTargetCurrencyCode = value;
    }

    /**
     * Gets the value of the goalTargetYearNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTargetYearNumber() {
        return goalTargetYearNumber;
    }

    /**
     * Sets the value of the goalTargetYearNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTargetYearNumber(String value) {
        this.goalTargetYearNumber = value;
    }

    /**
     * Gets the value of the returnRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getReturnRate() {
        return returnRate;
    }

    /**
     * Sets the value of the returnRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setReturnRate(BigDecimal value) {
        this.returnRate = value;
    }

    /**
     * Gets the value of the returnShortfallAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getReturnShortfallAmount() {
        return returnShortfallAmount;
    }

    /**
     * Sets the value of the returnShortfallAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setReturnShortfallAmount(BigDecimal value) {
        this.returnShortfallAmount = value;
    }

    /**
     * Gets the value of the returnShortfallCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnShortfallCurrencyCode() {
        return returnShortfallCurrencyCode;
    }

    /**
     * Sets the value of the returnShortfallCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnShortfallCurrencyCode(String value) {
        this.returnShortfallCurrencyCode = value;
    }

    /**
     * Gets the value of the savingMonthlyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSavingMonthlyAmount() {
        return savingMonthlyAmount;
    }

    /**
     * Sets the value of the savingMonthlyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSavingMonthlyAmount(BigDecimal value) {
        this.savingMonthlyAmount = value;
    }

    /**
     * Gets the value of the savingMonthlyCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSavingMonthlyCurrencyCode() {
        return savingMonthlyCurrencyCode;
    }

    /**
     * Sets the value of the savingMonthlyCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSavingMonthlyCurrencyCode(String value) {
        this.savingMonthlyCurrencyCode = value;
    }

    /**
     * Gets the value of the simulateSegmentIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSimulateSegmentIndicator() {
        return simulateSegmentIndicator;
    }

    /**
     * Sets the value of the simulateSegmentIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSimulateSegmentIndicator(String value) {
        this.simulateSegmentIndicator = value;
    }

    /**
     * Gets the value of the wealthProjectedCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWealthProjectedCurrencyCode() {
        return wealthProjectedCurrencyCode;
    }

    /**
     * Sets the value of the wealthProjectedCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWealthProjectedCurrencyCode(String value) {
        this.wealthProjectedCurrencyCode = value;
    }

    /**
     * Gets the value of the wealthProjectedTotalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getWealthProjectedTotalAmount() {
        return wealthProjectedTotalAmount;
    }

    /**
     * Sets the value of the wealthProjectedTotalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setWealthProjectedTotalAmount(BigDecimal value) {
        this.wealthProjectedTotalAmount = value;
    }

}
