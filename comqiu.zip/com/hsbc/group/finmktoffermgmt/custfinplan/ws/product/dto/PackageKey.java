
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for packageKey complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="packageKey">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="financialPlanningProductPackageSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "packageKey", propOrder = {
    "financialPlanningProductPackageSequenceNumber"
})
public class PackageKey {

    protected String financialPlanningProductPackageSequenceNumber;

    /**
     * Gets the value of the financialPlanningProductPackageSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialPlanningProductPackageSequenceNumber() {
        return financialPlanningProductPackageSequenceNumber;
    }

    /**
     * Sets the value of the financialPlanningProductPackageSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialPlanningProductPackageSequenceNumber(String value) {
        this.financialPlanningProductPackageSequenceNumber = value;
    }

}
