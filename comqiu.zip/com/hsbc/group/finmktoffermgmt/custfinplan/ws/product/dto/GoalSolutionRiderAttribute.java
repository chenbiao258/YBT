
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for goalSolutionRiderAttribute complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="goalSolutionRiderAttribute">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="riderAttributeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="riderAttributeValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalSolutionRiderAttribute", propOrder = {
    "riderAttributeCode",
    "riderAttributeValue"
})
public class GoalSolutionRiderAttribute {

    protected String riderAttributeCode;
    protected String riderAttributeValue;

    /**
     * Gets the value of the riderAttributeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRiderAttributeCode() {
        return riderAttributeCode;
    }

    /**
     * Sets the value of the riderAttributeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRiderAttributeCode(String value) {
        this.riderAttributeCode = value;
    }

    /**
     * Gets the value of the riderAttributeValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRiderAttributeValue() {
        return riderAttributeValue;
    }

    /**
     * Sets the value of the riderAttributeValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRiderAttributeValue(String value) {
        this.riderAttributeValue = value;
    }

}
