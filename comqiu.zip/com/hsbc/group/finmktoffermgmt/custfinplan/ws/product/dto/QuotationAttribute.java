
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for quotationAttribute complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="quotationAttribute">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="proReturnAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="proReturnCcy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="projectDef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="quotationIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="targetAge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="targetYear" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "quotationAttribute", propOrder = {
    "proReturnAmount",
    "proReturnCcy",
    "projectDef",
    "quotationIndicator",
    "targetAge",
    "targetYear"
})
public class QuotationAttribute {

    protected BigDecimal proReturnAmount;
    protected String proReturnCcy;
    protected String projectDef;
    protected String quotationIndicator;
    protected String targetAge;
    protected String targetYear;

    /**
     * Gets the value of the proReturnAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getProReturnAmount() {
        return proReturnAmount;
    }

    /**
     * Sets the value of the proReturnAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setProReturnAmount(BigDecimal value) {
        this.proReturnAmount = value;
    }

    /**
     * Gets the value of the proReturnCcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProReturnCcy() {
        return proReturnCcy;
    }

    /**
     * Sets the value of the proReturnCcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProReturnCcy(String value) {
        this.proReturnCcy = value;
    }

    /**
     * Gets the value of the projectDef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProjectDef() {
        return projectDef;
    }

    /**
     * Sets the value of the projectDef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProjectDef(String value) {
        this.projectDef = value;
    }

    /**
     * Gets the value of the quotationIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuotationIndicator() {
        return quotationIndicator;
    }

    /**
     * Sets the value of the quotationIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotationIndicator(String value) {
        this.quotationIndicator = value;
    }

    /**
     * Gets the value of the targetAge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetAge() {
        return targetAge;
    }

    /**
     * Sets the value of the targetAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetAge(String value) {
        this.targetAge = value;
    }

    /**
     * Gets the value of the targetYear property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetYear() {
        return targetYear;
    }

    /**
     * Sets the value of the targetYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetYear(String value) {
        this.targetYear = value;
    }

}
