
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for alternativeProductAttribute complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="alternativeProductAttribute">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="alternativeProductAttributeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="alternativeProductAttributeValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "alternativeProductAttribute", propOrder = {
    "alternativeProductAttributeCode",
    "alternativeProductAttributeValue"
})
public class AlternativeProductAttribute {

    protected String alternativeProductAttributeCode;
    protected String alternativeProductAttributeValue;

    /**
     * Gets the value of the alternativeProductAttributeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternativeProductAttributeCode() {
        return alternativeProductAttributeCode;
    }

    /**
     * Sets the value of the alternativeProductAttributeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternativeProductAttributeCode(String value) {
        this.alternativeProductAttributeCode = value;
    }

    /**
     * Gets the value of the alternativeProductAttributeValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternativeProductAttributeValue() {
        return alternativeProductAttributeValue;
    }

    /**
     * Sets the value of the alternativeProductAttributeValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternativeProductAttributeValue(String value) {
        this.alternativeProductAttributeValue = value;
    }

}
