
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for riskProfile complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="riskProfile">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="riskCapacityAssignDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="riskCapacityLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="riskCapacityRecommendLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="riskToleranceLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "riskProfile", propOrder = {
    "riskCapacityAssignDate",
    "riskCapacityLevelNumber",
    "riskCapacityRecommendLevelNumber",
    "riskToleranceLevelNumber"
})
public class RiskProfile {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar riskCapacityAssignDate;
    protected Integer riskCapacityLevelNumber;
    protected Integer riskCapacityRecommendLevelNumber;
    protected Integer riskToleranceLevelNumber;

    /**
     * Gets the value of the riskCapacityAssignDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRiskCapacityAssignDate() {
        return riskCapacityAssignDate;
    }

    /**
     * Sets the value of the riskCapacityAssignDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRiskCapacityAssignDate(XMLGregorianCalendar value) {
        this.riskCapacityAssignDate = value;
    }

    /**
     * Gets the value of the riskCapacityLevelNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskCapacityLevelNumber() {
        return riskCapacityLevelNumber;
    }

    /**
     * Sets the value of the riskCapacityLevelNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskCapacityLevelNumber(Integer value) {
        this.riskCapacityLevelNumber = value;
    }

    /**
     * Gets the value of the riskCapacityRecommendLevelNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskCapacityRecommendLevelNumber() {
        return riskCapacityRecommendLevelNumber;
    }

    /**
     * Sets the value of the riskCapacityRecommendLevelNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskCapacityRecommendLevelNumber(Integer value) {
        this.riskCapacityRecommendLevelNumber = value;
    }

    /**
     * Gets the value of the riskToleranceLevelNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskToleranceLevelNumber() {
        return riskToleranceLevelNumber;
    }

    /**
     * Sets the value of the riskToleranceLevelNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskToleranceLevelNumber(Integer value) {
        this.riskToleranceLevelNumber = value;
    }

}
