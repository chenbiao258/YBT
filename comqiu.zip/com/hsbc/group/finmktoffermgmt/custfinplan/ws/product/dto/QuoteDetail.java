
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for quoteDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="quoteDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="coverageInsuranceAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="coverageTerm" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="coverageTermPeriodicityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyCoverageInsuranceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyPremiumInsuranceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalSolutionRiderInformationList" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalSolutionRiderInformation" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="insuranceQuotationSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="paymentTermBeyondRetirement" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="periodicityPaymentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="premiumInsuranceAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="quotationAttrubuteList" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}quotationAttribute" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="quotationDataWiringInformation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="quotationPaymentTermMismatchIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="quoteExpired" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "quoteDetail", propOrder = {
    "coverageInsuranceAmount",
    "coverageTerm",
    "coverageTermPeriodicityCode",
    "currencyCoverageInsuranceCode",
    "currencyPremiumInsuranceCode",
    "goalSolutionRiderInformationList",
    "insuranceQuotationSequenceNumber",
    "paymentTermBeyondRetirement",
    "periodicityPaymentCode",
    "premiumInsuranceAmount",
    "quotationAttrubuteList",
    "quotationDataWiringInformation",
    "quotationPaymentTermMismatchIndicator",
    "quoteExpired"
})
public class QuoteDetail {

    protected BigDecimal coverageInsuranceAmount;
    protected BigDecimal coverageTerm;
    protected String coverageTermPeriodicityCode;
    protected String currencyCoverageInsuranceCode;
    protected String currencyPremiumInsuranceCode;
    @XmlElement(nillable = true)
    protected List<GoalSolutionRiderInformation> goalSolutionRiderInformationList;
    protected long insuranceQuotationSequenceNumber;
    protected BigDecimal paymentTermBeyondRetirement;
    protected String periodicityPaymentCode;
    protected BigDecimal premiumInsuranceAmount;
    @XmlElement(nillable = true)
    protected List<QuotationAttribute> quotationAttrubuteList;
    protected String quotationDataWiringInformation;
    protected String quotationPaymentTermMismatchIndicator;
    protected String quoteExpired;

    /**
     * Gets the value of the coverageInsuranceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCoverageInsuranceAmount() {
        return coverageInsuranceAmount;
    }

    /**
     * Sets the value of the coverageInsuranceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCoverageInsuranceAmount(BigDecimal value) {
        this.coverageInsuranceAmount = value;
    }

    /**
     * Gets the value of the coverageTerm property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCoverageTerm() {
        return coverageTerm;
    }

    /**
     * Sets the value of the coverageTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCoverageTerm(BigDecimal value) {
        this.coverageTerm = value;
    }

    /**
     * Gets the value of the coverageTermPeriodicityCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoverageTermPeriodicityCode() {
        return coverageTermPeriodicityCode;
    }

    /**
     * Sets the value of the coverageTermPeriodicityCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoverageTermPeriodicityCode(String value) {
        this.coverageTermPeriodicityCode = value;
    }

    /**
     * Gets the value of the currencyCoverageInsuranceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCoverageInsuranceCode() {
        return currencyCoverageInsuranceCode;
    }

    /**
     * Sets the value of the currencyCoverageInsuranceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCoverageInsuranceCode(String value) {
        this.currencyCoverageInsuranceCode = value;
    }

    /**
     * Gets the value of the currencyPremiumInsuranceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyPremiumInsuranceCode() {
        return currencyPremiumInsuranceCode;
    }

    /**
     * Sets the value of the currencyPremiumInsuranceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyPremiumInsuranceCode(String value) {
        this.currencyPremiumInsuranceCode = value;
    }

    /**
     * Gets the value of the goalSolutionRiderInformationList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalSolutionRiderInformationList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalSolutionRiderInformationList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalSolutionRiderInformation }
     * 
     * 
     */
    public List<GoalSolutionRiderInformation> getGoalSolutionRiderInformationList() {
        if (goalSolutionRiderInformationList == null) {
            goalSolutionRiderInformationList = new ArrayList<GoalSolutionRiderInformation>();
        }
        return this.goalSolutionRiderInformationList;
    }

    /**
     * Gets the value of the insuranceQuotationSequenceNumber property.
     * 
     */
    public long getInsuranceQuotationSequenceNumber() {
        return insuranceQuotationSequenceNumber;
    }

    /**
     * Sets the value of the insuranceQuotationSequenceNumber property.
     * 
     */
    public void setInsuranceQuotationSequenceNumber(long value) {
        this.insuranceQuotationSequenceNumber = value;
    }

    /**
     * Gets the value of the paymentTermBeyondRetirement property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPaymentTermBeyondRetirement() {
        return paymentTermBeyondRetirement;
    }

    /**
     * Sets the value of the paymentTermBeyondRetirement property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPaymentTermBeyondRetirement(BigDecimal value) {
        this.paymentTermBeyondRetirement = value;
    }

    /**
     * Gets the value of the periodicityPaymentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicityPaymentCode() {
        return periodicityPaymentCode;
    }

    /**
     * Sets the value of the periodicityPaymentCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicityPaymentCode(String value) {
        this.periodicityPaymentCode = value;
    }

    /**
     * Gets the value of the premiumInsuranceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPremiumInsuranceAmount() {
        return premiumInsuranceAmount;
    }

    /**
     * Sets the value of the premiumInsuranceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPremiumInsuranceAmount(BigDecimal value) {
        this.premiumInsuranceAmount = value;
    }

    /**
     * Gets the value of the quotationAttrubuteList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the quotationAttrubuteList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQuotationAttrubuteList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link QuotationAttribute }
     * 
     * 
     */
    public List<QuotationAttribute> getQuotationAttrubuteList() {
        if (quotationAttrubuteList == null) {
            quotationAttrubuteList = new ArrayList<QuotationAttribute>();
        }
        return this.quotationAttrubuteList;
    }

    /**
     * Gets the value of the quotationDataWiringInformation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuotationDataWiringInformation() {
        return quotationDataWiringInformation;
    }

    /**
     * Sets the value of the quotationDataWiringInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotationDataWiringInformation(String value) {
        this.quotationDataWiringInformation = value;
    }

    /**
     * Gets the value of the quotationPaymentTermMismatchIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuotationPaymentTermMismatchIndicator() {
        return quotationPaymentTermMismatchIndicator;
    }

    /**
     * Sets the value of the quotationPaymentTermMismatchIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotationPaymentTermMismatchIndicator(String value) {
        this.quotationPaymentTermMismatchIndicator = value;
    }

    /**
     * Gets the value of the quoteExpired property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuoteExpired() {
        return quoteExpired;
    }

    /**
     * Sets the value of the quoteExpired property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuoteExpired(String value) {
        this.quoteExpired = value;
    }

}
