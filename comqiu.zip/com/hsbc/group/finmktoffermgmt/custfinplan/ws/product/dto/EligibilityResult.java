
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for eligibilityResult complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="eligibilityResult">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="eligibilityIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="eligibilityOverrideIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="eligibilityRuleCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="eligibilityTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "eligibilityResult", propOrder = {
    "eligibilityIndicator",
    "eligibilityOverrideIndicator",
    "eligibilityRuleCode",
    "eligibilityTypeCode",
    "reasonCode"
})
public class EligibilityResult {

    protected String eligibilityIndicator;
    protected String eligibilityOverrideIndicator;
    protected String eligibilityRuleCode;
    protected String eligibilityTypeCode;
    protected String reasonCode;

    /**
     * Gets the value of the eligibilityIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityIndicator() {
        return eligibilityIndicator;
    }

    /**
     * Sets the value of the eligibilityIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityIndicator(String value) {
        this.eligibilityIndicator = value;
    }

    /**
     * Gets the value of the eligibilityOverrideIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityOverrideIndicator() {
        return eligibilityOverrideIndicator;
    }

    /**
     * Sets the value of the eligibilityOverrideIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityOverrideIndicator(String value) {
        this.eligibilityOverrideIndicator = value;
    }

    /**
     * Gets the value of the eligibilityRuleCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityRuleCode() {
        return eligibilityRuleCode;
    }

    /**
     * Sets the value of the eligibilityRuleCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityRuleCode(String value) {
        this.eligibilityRuleCode = value;
    }

    /**
     * Gets the value of the eligibilityTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityTypeCode() {
        return eligibilityTypeCode;
    }

    /**
     * Sets the value of the eligibilityTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityTypeCode(String value) {
        this.eligibilityTypeCode = value;
    }

    /**
     * Gets the value of the reasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

}
