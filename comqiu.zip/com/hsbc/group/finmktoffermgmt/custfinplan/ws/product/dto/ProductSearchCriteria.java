
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for productSearchCriteria complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productSearchCriteria">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="filterCriteriaFormula" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}filterCriteriaFormula" minOccurs="0"/>
 *         &lt;element name="keyValueCriteriaWithIndex" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}keyValueCriteriaWithIndex" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="searchCriteria" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}searchCriteria" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="sortingCriteria" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}sortingCriteria" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productSearchCriteria", propOrder = {
    "filterCriteriaFormula",
    "keyValueCriteriaWithIndex",
    "productSelectionMethodCode",
    "searchCriteria",
    "sortingCriteria"
})
public class ProductSearchCriteria {

    protected FilterCriteriaFormula filterCriteriaFormula;
    @XmlElement(nillable = true)
    protected List<KeyValueCriteriaWithIndex> keyValueCriteriaWithIndex;
    protected String productSelectionMethodCode;
    @XmlElement(nillable = true)
    protected List<SearchCriteria> searchCriteria;
    @XmlElement(nillable = true)
    protected List<SortingCriteria> sortingCriteria;

    /**
     * Gets the value of the filterCriteriaFormula property.
     * 
     * @return
     *     possible object is
     *     {@link FilterCriteriaFormula }
     *     
     */
    public FilterCriteriaFormula getFilterCriteriaFormula() {
        return filterCriteriaFormula;
    }

    /**
     * Sets the value of the filterCriteriaFormula property.
     * 
     * @param value
     *     allowed object is
     *     {@link FilterCriteriaFormula }
     *     
     */
    public void setFilterCriteriaFormula(FilterCriteriaFormula value) {
        this.filterCriteriaFormula = value;
    }

    /**
     * Gets the value of the keyValueCriteriaWithIndex property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keyValueCriteriaWithIndex property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeyValueCriteriaWithIndex().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link KeyValueCriteriaWithIndex }
     * 
     * 
     */
    public List<KeyValueCriteriaWithIndex> getKeyValueCriteriaWithIndex() {
        if (keyValueCriteriaWithIndex == null) {
            keyValueCriteriaWithIndex = new ArrayList<KeyValueCriteriaWithIndex>();
        }
        return this.keyValueCriteriaWithIndex;
    }

    /**
     * Gets the value of the productSelectionMethodCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * Sets the value of the productSelectionMethodCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * Gets the value of the searchCriteria property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the searchCriteria property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSearchCriteria().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SearchCriteria }
     * 
     * 
     */
    public List<SearchCriteria> getSearchCriteria() {
        if (searchCriteria == null) {
            searchCriteria = new ArrayList<SearchCriteria>();
        }
        return this.searchCriteria;
    }

    /**
     * Gets the value of the sortingCriteria property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sortingCriteria property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSortingCriteria().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SortingCriteria }
     * 
     * 
     */
    public List<SortingCriteria> getSortingCriteria() {
        if (sortingCriteria == null) {
            sortingCriteria = new ArrayList<SortingCriteria>();
        }
        return this.sortingCriteria;
    }

}
