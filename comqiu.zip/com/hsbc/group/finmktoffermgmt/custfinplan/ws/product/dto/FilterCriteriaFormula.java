
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for filterCriteriaFormula complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="filterCriteriaFormula">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="filterFormula" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "filterCriteriaFormula", propOrder = {
    "filterFormula"
})
public class FilterCriteriaFormula {

    protected String filterFormula;

    /**
     * Gets the value of the filterFormula property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFilterFormula() {
        return filterFormula;
    }

    /**
     * Sets the value of the filterFormula property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFilterFormula(String value) {
        this.filterFormula = value;
    }

}
