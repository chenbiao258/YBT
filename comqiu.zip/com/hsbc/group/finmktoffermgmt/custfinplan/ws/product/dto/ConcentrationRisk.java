
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for concentrationRisk complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="concentrationRisk">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="concentrationRiskRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="concentrationRiskSuitabilityIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="exceedThresholdIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="thresholdValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "concentrationRisk", propOrder = {
    "concentrationRiskRate",
    "concentrationRiskSuitabilityIndicator",
    "exceedThresholdIndicator",
    "thresholdValue"
})
public class ConcentrationRisk {

    protected BigDecimal concentrationRiskRate;
    protected String concentrationRiskSuitabilityIndicator;
    protected String exceedThresholdIndicator;
    protected BigDecimal thresholdValue;

    /**
     * Gets the value of the concentrationRiskRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getConcentrationRiskRate() {
        return concentrationRiskRate;
    }

    /**
     * Sets the value of the concentrationRiskRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setConcentrationRiskRate(BigDecimal value) {
        this.concentrationRiskRate = value;
    }

    /**
     * Gets the value of the concentrationRiskSuitabilityIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConcentrationRiskSuitabilityIndicator() {
        return concentrationRiskSuitabilityIndicator;
    }

    /**
     * Sets the value of the concentrationRiskSuitabilityIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConcentrationRiskSuitabilityIndicator(String value) {
        this.concentrationRiskSuitabilityIndicator = value;
    }

    /**
     * Gets the value of the exceedThresholdIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceedThresholdIndicator() {
        return exceedThresholdIndicator;
    }

    /**
     * Sets the value of the exceedThresholdIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceedThresholdIndicator(String value) {
        this.exceedThresholdIndicator = value;
    }

    /**
     * Gets the value of the thresholdValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getThresholdValue() {
        return thresholdValue;
    }

    /**
     * Sets the value of the thresholdValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setThresholdValue(BigDecimal value) {
        this.thresholdValue = value;
    }

}
