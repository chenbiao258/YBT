
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for eligibleWrapper complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="eligibleWrapper">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="wrapperCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wrapperDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wrapperTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "eligibleWrapper", propOrder = {
    "wrapperCode",
    "wrapperDescription",
    "wrapperTypeCode"
})
public class EligibleWrapper {

    protected String wrapperCode;
    protected String wrapperDescription;
    protected String wrapperTypeCode;

    /**
     * Gets the value of the wrapperCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperCode() {
        return wrapperCode;
    }

    /**
     * Sets the value of the wrapperCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperCode(String value) {
        this.wrapperCode = value;
    }

    /**
     * Gets the value of the wrapperDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperDescription() {
        return wrapperDescription;
    }

    /**
     * Sets the value of the wrapperDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperDescription(String value) {
        this.wrapperDescription = value;
    }

    /**
     * Gets the value of the wrapperTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperTypeCode() {
        return wrapperTypeCode;
    }

    /**
     * Sets the value of the wrapperTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperTypeCode(String value) {
        this.wrapperTypeCode = value;
    }

}
