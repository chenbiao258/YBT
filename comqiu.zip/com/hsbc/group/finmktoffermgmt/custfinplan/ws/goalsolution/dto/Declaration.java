
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for declaration complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="declaration">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="declarationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="declarationValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reasonDeclarationText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reasonDeclarationTextSize" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "declaration", propOrder = {
    "declarationCode",
    "declarationValue",
    "reasonDeclarationText",
    "reasonDeclarationTextSize"
})
public class Declaration {

    protected String declarationCode;
    protected String declarationValue;
    protected String reasonDeclarationText;
    protected int reasonDeclarationTextSize;

    /**
     * Gets the value of the declarationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeclarationCode() {
        return declarationCode;
    }

    /**
     * Sets the value of the declarationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclarationCode(String value) {
        this.declarationCode = value;
    }

    /**
     * Gets the value of the declarationValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeclarationValue() {
        return declarationValue;
    }

    /**
     * Sets the value of the declarationValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclarationValue(String value) {
        this.declarationValue = value;
    }

    /**
     * Gets the value of the reasonDeclarationText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonDeclarationText() {
        return reasonDeclarationText;
    }

    /**
     * Sets the value of the reasonDeclarationText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonDeclarationText(String value) {
        this.reasonDeclarationText = value;
    }

    /**
     * Gets the value of the reasonDeclarationTextSize property.
     * 
     */
    public int getReasonDeclarationTextSize() {
        return reasonDeclarationTextSize;
    }

    /**
     * Sets the value of the reasonDeclarationTextSize property.
     * 
     */
    public void setReasonDeclarationTextSize(int value) {
        this.reasonDeclarationTextSize = value;
    }

}
