
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.CalculateRiskCapacity;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>Java class for calculateRiskCapacityWSRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="calculateRiskCapacityWSRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest">
 *       &lt;sequence>
 *         &lt;element name="calculateRiskCapacity" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculateRiskCapacity" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateRiskCapacityWSRequest", propOrder = {
    "calculateRiskCapacity"
})
public class CalculateRiskCapacityWSRequest
    extends WebServiceRequest
{

    protected CalculateRiskCapacity calculateRiskCapacity;

    /**
     * Gets the value of the calculateRiskCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link CalculateRiskCapacity }
     *     
     */
    public CalculateRiskCapacity getCalculateRiskCapacity() {
        return calculateRiskCapacity;
    }

    /**
     * Sets the value of the calculateRiskCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link CalculateRiskCapacity }
     *     
     */
    public void setCalculateRiskCapacity(CalculateRiskCapacity value) {
        this.calculateRiskCapacity = value;
    }

}
