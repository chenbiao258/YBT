
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ConcentrationRisk;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.EligibilityResult;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.InvestProductFeature;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ProductAttribute;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.QuoteDetail;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.quotation.dto.QuoteId;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.taxoptimization.dto.WrapperAccount;


/**
 * <p>Java class for productTable complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productTable">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="concentrationRisk" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}concentrationRisk" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="eligibilityResult" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}eligibilityResult" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="investProductFeature" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investProductFeature" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="productAttribute" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAttribute" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="productDocument" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAttribute" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="productId" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productId" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="productInfo" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productInfo" minOccurs="0"/>
 *         &lt;element name="quoteDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}quoteDetail" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="quoteId" type="{http://dto.quotation.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}quoteId" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="wrapperAccount" type="{http://dto.taxoptimization.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}wrapperAccount" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productTable", propOrder = {
    "concentrationRisk",
    "eligibilityResult",
    "investProductFeature",
    "productAttribute",
    "productDocument",
    "productId",
    "productInfo",
    "quoteDetail",
    "quoteId",
    "wrapperAccount"
})
public class ProductTable {

    @XmlElement(nillable = true)
    protected List<ConcentrationRisk> concentrationRisk;
    @XmlElement(nillable = true)
    protected List<EligibilityResult> eligibilityResult;
    @XmlElement(nillable = true)
    protected List<InvestProductFeature> investProductFeature;
    @XmlElement(nillable = true)
    protected List<ProductAttribute> productAttribute;
    @XmlElement(nillable = true)
    protected List<ProductAttribute> productDocument;
    @XmlElement(nillable = true)
    protected List<ProductId> productId;
    protected ProductInfo productInfo;
    @XmlElement(nillable = true)
    protected List<QuoteDetail> quoteDetail;
    @XmlElement(nillable = true)
    protected List<QuoteId> quoteId;
    protected WrapperAccount wrapperAccount;

    /**
     * Gets the value of the concentrationRisk property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the concentrationRisk property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConcentrationRisk().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConcentrationRisk }
     * 
     * 
     */
    public List<ConcentrationRisk> getConcentrationRisk() {
        if (concentrationRisk == null) {
            concentrationRisk = new ArrayList<ConcentrationRisk>();
        }
        return this.concentrationRisk;
    }

    /**
     * Gets the value of the eligibilityResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eligibilityResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEligibilityResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EligibilityResult }
     * 
     * 
     */
    public List<EligibilityResult> getEligibilityResult() {
        if (eligibilityResult == null) {
            eligibilityResult = new ArrayList<EligibilityResult>();
        }
        return this.eligibilityResult;
    }

    /**
     * Gets the value of the investProductFeature property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investProductFeature property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestProductFeature().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestProductFeature }
     * 
     * 
     */
    public List<InvestProductFeature> getInvestProductFeature() {
        if (investProductFeature == null) {
            investProductFeature = new ArrayList<InvestProductFeature>();
        }
        return this.investProductFeature;
    }

    /**
     * Gets the value of the productAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAttribute }
     * 
     * 
     */
    public List<ProductAttribute> getProductAttribute() {
        if (productAttribute == null) {
            productAttribute = new ArrayList<ProductAttribute>();
        }
        return this.productAttribute;
    }

    /**
     * Gets the value of the productDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAttribute }
     * 
     * 
     */
    public List<ProductAttribute> getProductDocument() {
        if (productDocument == null) {
            productDocument = new ArrayList<ProductAttribute>();
        }
        return this.productDocument;
    }

    /**
     * Gets the value of the productId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductId }
     * 
     * 
     */
    public List<ProductId> getProductId() {
        if (productId == null) {
            productId = new ArrayList<ProductId>();
        }
        return this.productId;
    }

    /**
     * Gets the value of the productInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ProductInfo }
     *     
     */
    public ProductInfo getProductInfo() {
        return productInfo;
    }

    /**
     * Sets the value of the productInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductInfo }
     *     
     */
    public void setProductInfo(ProductInfo value) {
        this.productInfo = value;
    }

    /**
     * Gets the value of the quoteDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the quoteDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQuoteDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link QuoteDetail }
     * 
     * 
     */
    public List<QuoteDetail> getQuoteDetail() {
        if (quoteDetail == null) {
            quoteDetail = new ArrayList<QuoteDetail>();
        }
        return this.quoteDetail;
    }

    /**
     * Gets the value of the quoteId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the quoteId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQuoteId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link QuoteId }
     * 
     * 
     */
    public List<QuoteId> getQuoteId() {
        if (quoteId == null) {
            quoteId = new ArrayList<QuoteId>();
        }
        return this.quoteId;
    }

    /**
     * Gets the value of the wrapperAccount property.
     * 
     * @return
     *     possible object is
     *     {@link WrapperAccount }
     *     
     */
    public WrapperAccount getWrapperAccount() {
        return wrapperAccount;
    }

    /**
     * Sets the value of the wrapperAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link WrapperAccount }
     *     
     */
    public void setWrapperAccount(WrapperAccount value) {
        this.wrapperAccount = value;
    }

}
