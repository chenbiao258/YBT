
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.CalculatedRiskCapacity;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>Java class for calculateRiskCapacityWSResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="calculateRiskCapacityWSResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse">
 *       &lt;sequence>
 *         &lt;element name="calculatedRiskCapacity" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculatedRiskCapacity" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateRiskCapacityWSResponse", propOrder = {
    "calculatedRiskCapacity"
})
public class CalculateRiskCapacityWSResponse
    extends WebServiceResponse
{

    protected CalculatedRiskCapacity calculatedRiskCapacity;

    /**
     * Gets the value of the calculatedRiskCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link CalculatedRiskCapacity }
     *     
     */
    public CalculatedRiskCapacity getCalculatedRiskCapacity() {
        return calculatedRiskCapacity;
    }

    /**
     * Sets the value of the calculatedRiskCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link CalculatedRiskCapacity }
     *     
     */
    public void setCalculatedRiskCapacity(CalculatedRiskCapacity value) {
        this.calculatedRiskCapacity = value;
    }

}
