
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.AdditionalInformation;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ConcentrationRisk;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.EligibilityResult;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.EligibleWrapper;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.InvestProductFeature;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ProductAttribute;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.QuoteDetail;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.quotation.dto.QuoteId;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.taxoptimization.dto.WrapperAccount;


/**
 * <p>Java class for productList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="additionalInformation" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalInformation" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="allocationInvestmentPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="allocationSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="assetClassGroupCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="concentrationRisk" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}concentrationRisk" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="currencyAssetAllocationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyCurrentInvestmentAmountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyInvestmentInitialCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyInvestmentInitialMinimumAmountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyInvestmentMonthlyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyProductCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyTargetInvestmentAmountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currentInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="eligibilityResult" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}eligibilityResult" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="eligibleWrapper" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}eligibleWrapper" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="fromAllocatedHoldingIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="investProductFeature" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investProductFeature" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="investmentInitialAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="investmentInitialMinimumAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="investmentMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="overiddenEligibilityIntegrityIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productAttribute" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAttribute" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="productDocument" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAttribute" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="productId" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productId" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="productName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productSubtypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="quoteDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}quoteDetail" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="quoteId" type="{http://dto.quotation.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}quoteId" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="recordUpdateDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="riskLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="supportMonthlyInvestmentProgramIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="targetInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="valid" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="wrapperAccount" type="{http://dto.taxoptimization.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}wrapperAccount" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="wrapperEligibleText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wrapperEligibleTextLength" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productList", propOrder = {
    "additionalInformation",
    "allocationInvestmentPercent",
    "allocationSequenceNumber",
    "assetClassGroupCode",
    "concentrationRisk",
    "currencyAssetAllocationCode",
    "currencyCurrentInvestmentAmountCode",
    "currencyInvestmentInitialCode",
    "currencyInvestmentInitialMinimumAmountCode",
    "currencyInvestmentMonthlyCode",
    "currencyProductCode",
    "currencyTargetInvestmentAmountCode",
    "currentInvestmentAmount",
    "eligibilityResult",
    "eligibleWrapper",
    "fromAllocatedHoldingIndicator",
    "investProductFeature",
    "investmentInitialAmount",
    "investmentInitialMinimumAmount",
    "investmentMonthlyAmount",
    "overiddenEligibilityIntegrityIndicator",
    "productAttribute",
    "productDocument",
    "productId",
    "productName",
    "productSelectionMethodCode",
    "productSubtypeCode",
    "quoteDetail",
    "quoteId",
    "recordUpdateDateTime",
    "riskLevelCode",
    "supportMonthlyInvestmentProgramIndicator",
    "targetInvestmentAmount",
    "valid",
    "wrapperAccount",
    "wrapperEligibleText",
    "wrapperEligibleTextLength"
})
public class ProductList {

    @XmlElement(nillable = true)
    protected List<AdditionalInformation> additionalInformation;
    protected BigDecimal allocationInvestmentPercent;
    protected long allocationSequenceNumber;
    protected String assetClassGroupCode;
    @XmlElement(nillable = true)
    protected List<ConcentrationRisk> concentrationRisk;
    protected String currencyAssetAllocationCode;
    protected String currencyCurrentInvestmentAmountCode;
    protected String currencyInvestmentInitialCode;
    protected String currencyInvestmentInitialMinimumAmountCode;
    protected String currencyInvestmentMonthlyCode;
    protected String currencyProductCode;
    protected String currencyTargetInvestmentAmountCode;
    protected BigDecimal currentInvestmentAmount;
    @XmlElement(nillable = true)
    protected List<EligibilityResult> eligibilityResult;
    @XmlElement(nillable = true)
    protected List<EligibleWrapper> eligibleWrapper;
    protected String fromAllocatedHoldingIndicator;
    @XmlElement(nillable = true)
    protected List<InvestProductFeature> investProductFeature;
    protected BigDecimal investmentInitialAmount;
    protected BigDecimal investmentInitialMinimumAmount;
    protected BigDecimal investmentMonthlyAmount;
    protected String overiddenEligibilityIntegrityIndicator;
    @XmlElement(nillable = true)
    protected List<ProductAttribute> productAttribute;
    @XmlElement(nillable = true)
    protected List<ProductAttribute> productDocument;
    @XmlElement(nillable = true)
    protected List<ProductId> productId;
    protected String productName;
    protected String productSelectionMethodCode;
    protected String productSubtypeCode;
    @XmlElement(nillable = true)
    protected List<QuoteDetail> quoteDetail;
    @XmlElement(nillable = true)
    protected List<QuoteId> quoteId;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar recordUpdateDateTime;
    protected String riskLevelCode;
    protected String supportMonthlyInvestmentProgramIndicator;
    protected BigDecimal targetInvestmentAmount;
    protected Boolean valid;
    @XmlElement(nillable = true)
    protected List<WrapperAccount> wrapperAccount;
    protected String wrapperEligibleText;
    protected Integer wrapperEligibleTextLength;

    /**
     * Gets the value of the additionalInformation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalInformation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalInformation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalInformation }
     * 
     * 
     */
    public List<AdditionalInformation> getAdditionalInformation() {
        if (additionalInformation == null) {
            additionalInformation = new ArrayList<AdditionalInformation>();
        }
        return this.additionalInformation;
    }

    /**
     * Gets the value of the allocationInvestmentPercent property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPercent() {
        return allocationInvestmentPercent;
    }

    /**
     * Sets the value of the allocationInvestmentPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPercent(BigDecimal value) {
        this.allocationInvestmentPercent = value;
    }

    /**
     * Gets the value of the allocationSequenceNumber property.
     * 
     */
    public long getAllocationSequenceNumber() {
        return allocationSequenceNumber;
    }

    /**
     * Sets the value of the allocationSequenceNumber property.
     * 
     */
    public void setAllocationSequenceNumber(long value) {
        this.allocationSequenceNumber = value;
    }

    /**
     * Gets the value of the assetClassGroupCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupCode() {
        return assetClassGroupCode;
    }

    /**
     * Sets the value of the assetClassGroupCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupCode(String value) {
        this.assetClassGroupCode = value;
    }

    /**
     * Gets the value of the concentrationRisk property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the concentrationRisk property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConcentrationRisk().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConcentrationRisk }
     * 
     * 
     */
    public List<ConcentrationRisk> getConcentrationRisk() {
        if (concentrationRisk == null) {
            concentrationRisk = new ArrayList<ConcentrationRisk>();
        }
        return this.concentrationRisk;
    }

    /**
     * Gets the value of the currencyAssetAllocationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAssetAllocationCode() {
        return currencyAssetAllocationCode;
    }

    /**
     * Sets the value of the currencyAssetAllocationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAssetAllocationCode(String value) {
        this.currencyAssetAllocationCode = value;
    }

    /**
     * Gets the value of the currencyCurrentInvestmentAmountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCurrentInvestmentAmountCode() {
        return currencyCurrentInvestmentAmountCode;
    }

    /**
     * Sets the value of the currencyCurrentInvestmentAmountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCurrentInvestmentAmountCode(String value) {
        this.currencyCurrentInvestmentAmountCode = value;
    }

    /**
     * Gets the value of the currencyInvestmentInitialCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentInitialCode() {
        return currencyInvestmentInitialCode;
    }

    /**
     * Sets the value of the currencyInvestmentInitialCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentInitialCode(String value) {
        this.currencyInvestmentInitialCode = value;
    }

    /**
     * Gets the value of the currencyInvestmentInitialMinimumAmountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentInitialMinimumAmountCode() {
        return currencyInvestmentInitialMinimumAmountCode;
    }

    /**
     * Sets the value of the currencyInvestmentInitialMinimumAmountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentInitialMinimumAmountCode(String value) {
        this.currencyInvestmentInitialMinimumAmountCode = value;
    }

    /**
     * Gets the value of the currencyInvestmentMonthlyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentMonthlyCode() {
        return currencyInvestmentMonthlyCode;
    }

    /**
     * Sets the value of the currencyInvestmentMonthlyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentMonthlyCode(String value) {
        this.currencyInvestmentMonthlyCode = value;
    }

    /**
     * Gets the value of the currencyProductCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyProductCode() {
        return currencyProductCode;
    }

    /**
     * Sets the value of the currencyProductCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyProductCode(String value) {
        this.currencyProductCode = value;
    }

    /**
     * Gets the value of the currencyTargetInvestmentAmountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyTargetInvestmentAmountCode() {
        return currencyTargetInvestmentAmountCode;
    }

    /**
     * Sets the value of the currencyTargetInvestmentAmountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyTargetInvestmentAmountCode(String value) {
        this.currencyTargetInvestmentAmountCode = value;
    }

    /**
     * Gets the value of the currentInvestmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentInvestmentAmount() {
        return currentInvestmentAmount;
    }

    /**
     * Sets the value of the currentInvestmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentInvestmentAmount(BigDecimal value) {
        this.currentInvestmentAmount = value;
    }

    /**
     * Gets the value of the eligibilityResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eligibilityResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEligibilityResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EligibilityResult }
     * 
     * 
     */
    public List<EligibilityResult> getEligibilityResult() {
        if (eligibilityResult == null) {
            eligibilityResult = new ArrayList<EligibilityResult>();
        }
        return this.eligibilityResult;
    }

    /**
     * Gets the value of the eligibleWrapper property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eligibleWrapper property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEligibleWrapper().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EligibleWrapper }
     * 
     * 
     */
    public List<EligibleWrapper> getEligibleWrapper() {
        if (eligibleWrapper == null) {
            eligibleWrapper = new ArrayList<EligibleWrapper>();
        }
        return this.eligibleWrapper;
    }

    /**
     * Gets the value of the fromAllocatedHoldingIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromAllocatedHoldingIndicator() {
        return fromAllocatedHoldingIndicator;
    }

    /**
     * Sets the value of the fromAllocatedHoldingIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromAllocatedHoldingIndicator(String value) {
        this.fromAllocatedHoldingIndicator = value;
    }

    /**
     * Gets the value of the investProductFeature property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investProductFeature property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestProductFeature().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestProductFeature }
     * 
     * 
     */
    public List<InvestProductFeature> getInvestProductFeature() {
        if (investProductFeature == null) {
            investProductFeature = new ArrayList<InvestProductFeature>();
        }
        return this.investProductFeature;
    }

    /**
     * Gets the value of the investmentInitialAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentInitialAmount() {
        return investmentInitialAmount;
    }

    /**
     * Sets the value of the investmentInitialAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentInitialAmount(BigDecimal value) {
        this.investmentInitialAmount = value;
    }

    /**
     * Gets the value of the investmentInitialMinimumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentInitialMinimumAmount() {
        return investmentInitialMinimumAmount;
    }

    /**
     * Sets the value of the investmentInitialMinimumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentInitialMinimumAmount(BigDecimal value) {
        this.investmentInitialMinimumAmount = value;
    }

    /**
     * Gets the value of the investmentMonthlyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentMonthlyAmount() {
        return investmentMonthlyAmount;
    }

    /**
     * Sets the value of the investmentMonthlyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentMonthlyAmount(BigDecimal value) {
        this.investmentMonthlyAmount = value;
    }

    /**
     * Gets the value of the overiddenEligibilityIntegrityIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOveriddenEligibilityIntegrityIndicator() {
        return overiddenEligibilityIntegrityIndicator;
    }

    /**
     * Sets the value of the overiddenEligibilityIntegrityIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOveriddenEligibilityIntegrityIndicator(String value) {
        this.overiddenEligibilityIntegrityIndicator = value;
    }

    /**
     * Gets the value of the productAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAttribute }
     * 
     * 
     */
    public List<ProductAttribute> getProductAttribute() {
        if (productAttribute == null) {
            productAttribute = new ArrayList<ProductAttribute>();
        }
        return this.productAttribute;
    }

    /**
     * Gets the value of the productDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAttribute }
     * 
     * 
     */
    public List<ProductAttribute> getProductDocument() {
        if (productDocument == null) {
            productDocument = new ArrayList<ProductAttribute>();
        }
        return this.productDocument;
    }

    /**
     * Gets the value of the productId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductId }
     * 
     * 
     */
    public List<ProductId> getProductId() {
        if (productId == null) {
            productId = new ArrayList<ProductId>();
        }
        return this.productId;
    }

    /**
     * Gets the value of the productName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the value of the productName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductName(String value) {
        this.productName = value;
    }

    /**
     * Gets the value of the productSelectionMethodCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * Sets the value of the productSelectionMethodCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * Gets the value of the productSubtypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSubtypeCode() {
        return productSubtypeCode;
    }

    /**
     * Sets the value of the productSubtypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSubtypeCode(String value) {
        this.productSubtypeCode = value;
    }

    /**
     * Gets the value of the quoteDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the quoteDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQuoteDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link QuoteDetail }
     * 
     * 
     */
    public List<QuoteDetail> getQuoteDetail() {
        if (quoteDetail == null) {
            quoteDetail = new ArrayList<QuoteDetail>();
        }
        return this.quoteDetail;
    }

    /**
     * Gets the value of the quoteId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the quoteId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQuoteId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link QuoteId }
     * 
     * 
     */
    public List<QuoteId> getQuoteId() {
        if (quoteId == null) {
            quoteId = new ArrayList<QuoteId>();
        }
        return this.quoteId;
    }

    /**
     * Gets the value of the recordUpdateDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRecordUpdateDateTime() {
        return recordUpdateDateTime;
    }

    /**
     * Sets the value of the recordUpdateDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRecordUpdateDateTime(XMLGregorianCalendar value) {
        this.recordUpdateDateTime = value;
    }

    /**
     * Gets the value of the riskLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRiskLevelCode() {
        return riskLevelCode;
    }

    /**
     * Sets the value of the riskLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRiskLevelCode(String value) {
        this.riskLevelCode = value;
    }

    /**
     * Gets the value of the supportMonthlyInvestmentProgramIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSupportMonthlyInvestmentProgramIndicator() {
        return supportMonthlyInvestmentProgramIndicator;
    }

    /**
     * Sets the value of the supportMonthlyInvestmentProgramIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSupportMonthlyInvestmentProgramIndicator(String value) {
        this.supportMonthlyInvestmentProgramIndicator = value;
    }

    /**
     * Gets the value of the targetInvestmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTargetInvestmentAmount() {
        return targetInvestmentAmount;
    }

    /**
     * Sets the value of the targetInvestmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTargetInvestmentAmount(BigDecimal value) {
        this.targetInvestmentAmount = value;
    }

    /**
     * Gets the value of the valid property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isValid() {
        return valid;
    }

    /**
     * Sets the value of the valid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setValid(Boolean value) {
        this.valid = value;
    }

    /**
     * Gets the value of the wrapperAccount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wrapperAccount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWrapperAccount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WrapperAccount }
     * 
     * 
     */
    public List<WrapperAccount> getWrapperAccount() {
        if (wrapperAccount == null) {
            wrapperAccount = new ArrayList<WrapperAccount>();
        }
        return this.wrapperAccount;
    }

    /**
     * Gets the value of the wrapperEligibleText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperEligibleText() {
        return wrapperEligibleText;
    }

    /**
     * Sets the value of the wrapperEligibleText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperEligibleText(String value) {
        this.wrapperEligibleText = value;
    }

    /**
     * Gets the value of the wrapperEligibleTextLength property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWrapperEligibleTextLength() {
        return wrapperEligibleTextLength;
    }

    /**
     * Sets the value of the wrapperEligibleTextLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWrapperEligibleTextLength(Integer value) {
        this.wrapperEligibleTextLength = value;
    }

}
