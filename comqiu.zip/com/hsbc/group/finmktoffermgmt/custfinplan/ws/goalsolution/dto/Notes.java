
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for notes complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="notes">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="goalCommentText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalCommentTextSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "notes", propOrder = {
    "goalCommentText",
    "goalCommentTextSize"
})
public class Notes {

    protected String goalCommentText;
    protected Integer goalCommentTextSize;

    /**
     * Gets the value of the goalCommentText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalCommentText() {
        return goalCommentText;
    }

    /**
     * Sets the value of the goalCommentText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalCommentText(String value) {
        this.goalCommentText = value;
    }

    /**
     * Gets the value of the goalCommentTextSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getGoalCommentTextSize() {
        return goalCommentTextSize;
    }

    /**
     * Sets the value of the goalCommentTextSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setGoalCommentTextSize(Integer value) {
        this.goalCommentTextSize = value;
    }

}
