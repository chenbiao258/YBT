
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.MultipleAdviceStyleAmountDetail;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.MultipleAdviceStyleHoldingDetails;


/**
 * <p>Java class for multipleAdviceStyleDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="multipleAdviceStyleDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="eligible" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="multipleAdviceStyleAmountDetail" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}multipleAdviceStyleAmountDetail" minOccurs="0"/>
 *         &lt;element name="multipleAdviceStyleHoldingDetails" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}multipleAdviceStyleHoldingDetails" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="preferred" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="selected" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "multipleAdviceStyleDetails", propOrder = {
    "eligible",
    "multipleAdviceStyleAmountDetail",
    "multipleAdviceStyleHoldingDetails",
    "preferred",
    "productSelectionMethodCode",
    "selected",
    "status"
})
public class MultipleAdviceStyleDetails {

    protected String eligible;
    protected MultipleAdviceStyleAmountDetail multipleAdviceStyleAmountDetail;
    @XmlElement(nillable = true)
    protected List<MultipleAdviceStyleHoldingDetails> multipleAdviceStyleHoldingDetails;
    protected String preferred;
    protected String productSelectionMethodCode;
    protected String selected;
    protected String status;

    /**
     * Gets the value of the eligible property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligible() {
        return eligible;
    }

    /**
     * Sets the value of the eligible property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligible(String value) {
        this.eligible = value;
    }

    /**
     * Gets the value of the multipleAdviceStyleAmountDetail property.
     * 
     * @return
     *     possible object is
     *     {@link MultipleAdviceStyleAmountDetail }
     *     
     */
    public MultipleAdviceStyleAmountDetail getMultipleAdviceStyleAmountDetail() {
        return multipleAdviceStyleAmountDetail;
    }

    /**
     * Sets the value of the multipleAdviceStyleAmountDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link MultipleAdviceStyleAmountDetail }
     *     
     */
    public void setMultipleAdviceStyleAmountDetail(MultipleAdviceStyleAmountDetail value) {
        this.multipleAdviceStyleAmountDetail = value;
    }

    /**
     * Gets the value of the multipleAdviceStyleHoldingDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the multipleAdviceStyleHoldingDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMultipleAdviceStyleHoldingDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MultipleAdviceStyleHoldingDetails }
     * 
     * 
     */
    public List<MultipleAdviceStyleHoldingDetails> getMultipleAdviceStyleHoldingDetails() {
        if (multipleAdviceStyleHoldingDetails == null) {
            multipleAdviceStyleHoldingDetails = new ArrayList<MultipleAdviceStyleHoldingDetails>();
        }
        return this.multipleAdviceStyleHoldingDetails;
    }

    /**
     * Gets the value of the preferred property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreferred() {
        return preferred;
    }

    /**
     * Sets the value of the preferred property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreferred(String value) {
        this.preferred = value;
    }

    /**
     * Gets the value of the productSelectionMethodCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * Sets the value of the productSelectionMethodCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * Gets the value of the selected property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSelected() {
        return selected;
    }

    /**
     * Sets the value of the selected property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSelected(String value) {
        this.selected = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
