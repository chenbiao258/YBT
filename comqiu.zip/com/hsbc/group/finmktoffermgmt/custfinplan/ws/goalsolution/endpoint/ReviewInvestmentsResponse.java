
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.ReviewInvestmentsWSResponse;


/**
 * <p>Java class for reviewInvestmentsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="reviewInvestmentsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}reviewInvestmentsWSResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "reviewInvestmentsResponse", propOrder = {
    "_return"
})
public class ReviewInvestmentsResponse {

    @XmlElement(name = "return")
    protected ReviewInvestmentsWSResponse _return;

    /**
     * Gets the value of the return property.
     * 
     * @return
     *     possible object is
     *     {@link ReviewInvestmentsWSResponse }
     *     
     */
    public ReviewInvestmentsWSResponse getReturn() {
        return _return;
    }

    /**
     * Sets the value of the return property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReviewInvestmentsWSResponse }
     *     
     */
    public void setReturn(ReviewInvestmentsWSResponse value) {
        this._return = value;
    }

}
