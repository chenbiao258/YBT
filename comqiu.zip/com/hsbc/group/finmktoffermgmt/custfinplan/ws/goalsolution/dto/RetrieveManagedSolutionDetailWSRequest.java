
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.ProductSelectionWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.PaginationDetail;


/**
 * <p>Java class for retrieveManagedSolutionDetailWSRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveManagedSolutionDetailWSRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productSelectionWSRequest">
 *       &lt;sequence>
 *         &lt;element name="paginationDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}paginationDetail" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveManagedSolutionDetailWSRequest", propOrder = {
    "paginationDetail"
})
public class RetrieveManagedSolutionDetailWSRequest
    extends ProductSelectionWSRequest
{

    protected PaginationDetail paginationDetail;

    /**
     * Gets the value of the paginationDetail property.
     * 
     * @return
     *     possible object is
     *     {@link PaginationDetail }
     *     
     */
    public PaginationDetail getPaginationDetail() {
        return paginationDetail;
    }

    /**
     * Sets the value of the paginationDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaginationDetail }
     *     
     */
    public void setPaginationDetail(PaginationDetail value) {
        this.paginationDetail = value;
    }

}
