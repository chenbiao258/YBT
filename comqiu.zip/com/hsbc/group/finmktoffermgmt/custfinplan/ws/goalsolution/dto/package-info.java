@javax.xml.bind.annotation.XmlSchema(namespace = "http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/")
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;
