
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for productId complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productId">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="countryProductTradableCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productAlternativeNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productCodeAlternativeClassificationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productId", propOrder = {
    "countryProductTradableCode",
    "productAlternativeNumber",
    "productCodeAlternativeClassificationCode",
    "productTypeCode"
})
public class ProductId {

    protected String countryProductTradableCode;
    protected String productAlternativeNumber;
    protected String productCodeAlternativeClassificationCode;
    protected String productTypeCode;

    /**
     * Gets the value of the countryProductTradableCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryProductTradableCode() {
        return countryProductTradableCode;
    }

    /**
     * Sets the value of the countryProductTradableCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryProductTradableCode(String value) {
        this.countryProductTradableCode = value;
    }

    /**
     * Gets the value of the productAlternativeNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductAlternativeNumber() {
        return productAlternativeNumber;
    }

    /**
     * Sets the value of the productAlternativeNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductAlternativeNumber(String value) {
        this.productAlternativeNumber = value;
    }

    /**
     * Gets the value of the productCodeAlternativeClassificationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCodeAlternativeClassificationCode() {
        return productCodeAlternativeClassificationCode;
    }

    /**
     * Sets the value of the productCodeAlternativeClassificationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCodeAlternativeClassificationCode(String value) {
        this.productCodeAlternativeClassificationCode = value;
    }

    /**
     * Gets the value of the productTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductTypeCode() {
        return productTypeCode;
    }

    /**
     * Sets the value of the productTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductTypeCode(String value) {
        this.productTypeCode = value;
    }

}
