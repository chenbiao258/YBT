
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for accountAllocationSummary complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="accountAllocationSummary">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountAllocationDetails" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}accountAllocationDetail" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="accountAllocationModelTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "accountAllocationSummary", propOrder = {
    "accountAllocationDetails",
    "accountAllocationModelTypeCode"
})
public class AccountAllocationSummary {

    @XmlElement(nillable = true)
    protected List<AccountAllocationDetail> accountAllocationDetails;
    protected String accountAllocationModelTypeCode;

    /**
     * Gets the value of the accountAllocationDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accountAllocationDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccountAllocationDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AccountAllocationDetail }
     * 
     * 
     */
    public List<AccountAllocationDetail> getAccountAllocationDetails() {
        if (accountAllocationDetails == null) {
            accountAllocationDetails = new ArrayList<AccountAllocationDetail>();
        }
        return this.accountAllocationDetails;
    }

    /**
     * Gets the value of the accountAllocationModelTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountAllocationModelTypeCode() {
        return accountAllocationModelTypeCode;
    }

    /**
     * Sets the value of the accountAllocationModelTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountAllocationModelTypeCode(String value) {
        this.accountAllocationModelTypeCode = value;
    }

}
