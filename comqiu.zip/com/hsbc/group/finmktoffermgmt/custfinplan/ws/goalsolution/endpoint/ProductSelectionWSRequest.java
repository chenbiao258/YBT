
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalKey;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveManagedSolutionDetailWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveProductSearchResultWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ProductSearchCriteria;
import com.hsbc.swp.common.ws.dto.LocaleCode;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>Java class for productSelectionWSRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productSelectionWSRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest">
 *       &lt;sequence>
 *         &lt;element name="cacheDataToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" minOccurs="0"/>
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/>
 *         &lt;element name="localeCode" type="{http://dto.ws.common.swp.hsbc.com/}localeCode" minOccurs="0"/>
 *         &lt;element name="productSearchCriteria" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productSearchCriteria" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="requestModes" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productSelectionWSRequest", propOrder = {
    "cacheDataToken",
    "customers",
    "goalKey",
    "jointCustomer",
    "localeCode",
    "productSearchCriteria",
    "requestModes"
})
@XmlSeeAlso({
    RetrieveManagedSolutionDetailWSRequest.class,
    RetrieveProductSearchResultWSRequest.class
})
public class ProductSelectionWSRequest
    extends WebServiceRequest
{

    protected String cacheDataToken;
    @XmlElement(nillable = true)
    protected List<Customer> customers;
    protected GoalKey goalKey;
    protected Customer jointCustomer;
    protected LocaleCode localeCode;
    @XmlElement(nillable = true)
    protected List<ProductSearchCriteria> productSearchCriteria;
    @XmlElement(nillable = true)
    protected List<String> requestModes;

    /**
     * Gets the value of the cacheDataToken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCacheDataToken() {
        return cacheDataToken;
    }

    /**
     * Sets the value of the cacheDataToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCacheDataToken(String value) {
        this.cacheDataToken = value;
    }

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the goalKey property.
     * 
     * @return
     *     possible object is
     *     {@link GoalKey }
     *     
     */
    public GoalKey getGoalKey() {
        return goalKey;
    }

    /**
     * Sets the value of the goalKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link GoalKey }
     *     
     */
    public void setGoalKey(GoalKey value) {
        this.goalKey = value;
    }

    /**
     * Gets the value of the jointCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * Sets the value of the jointCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * Gets the value of the localeCode property.
     * 
     * @return
     *     possible object is
     *     {@link LocaleCode }
     *     
     */
    public LocaleCode getLocaleCode() {
        return localeCode;
    }

    /**
     * Sets the value of the localeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocaleCode }
     *     
     */
    public void setLocaleCode(LocaleCode value) {
        this.localeCode = value;
    }

    /**
     * Gets the value of the productSearchCriteria property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productSearchCriteria property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductSearchCriteria().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductSearchCriteria }
     * 
     * 
     */
    public List<ProductSearchCriteria> getProductSearchCriteria() {
        if (productSearchCriteria == null) {
            productSearchCriteria = new ArrayList<ProductSearchCriteria>();
        }
        return this.productSearchCriteria;
    }

    /**
     * Gets the value of the requestModes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestModes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestModes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getRequestModes() {
        if (requestModes == null) {
            requestModes = new ArrayList<String>();
        }
        return this.requestModes;
    }

}
