
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.dto.FilteringCriteria;
import com.hsbc.swp.common.ws.dto.LocaleCode;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>Java class for retrieveGoalSummaryListWSRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveGoalSummaryListWSRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest">
 *       &lt;sequence>
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="filteringCriteria" type="{http://dto.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}filteringCriteria" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/>
 *         &lt;element name="localeCode" type="{http://dto.ws.common.swp.hsbc.com/}localeCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveGoalSummaryListWSRequest", propOrder = {
    "customers",
    "filteringCriteria",
    "jointCustomer",
    "localeCode"
})
public class RetrieveGoalSummaryListWSRequest
    extends WebServiceRequest
{

    @XmlElement(nillable = true)
    protected List<Customer> customers;
    @XmlElement(nillable = true)
    protected List<FilteringCriteria> filteringCriteria;
    protected Customer jointCustomer;
    protected LocaleCode localeCode;

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the filteringCriteria property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the filteringCriteria property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFilteringCriteria().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FilteringCriteria }
     * 
     * 
     */
    public List<FilteringCriteria> getFilteringCriteria() {
        if (filteringCriteria == null) {
            filteringCriteria = new ArrayList<FilteringCriteria>();
        }
        return this.filteringCriteria;
    }

    /**
     * Gets the value of the jointCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * Sets the value of the jointCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * Gets the value of the localeCode property.
     * 
     * @return
     *     possible object is
     *     {@link LocaleCode }
     *     
     */
    public LocaleCode getLocaleCode() {
        return localeCode;
    }

    /**
     * Sets the value of the localeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocaleCode }
     *     
     */
    public void setLocaleCode(LocaleCode value) {
        this.localeCode = value;
    }

}
