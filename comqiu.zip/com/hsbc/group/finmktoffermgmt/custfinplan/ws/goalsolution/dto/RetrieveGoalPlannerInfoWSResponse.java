
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.Comment;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.DocumentChecklist;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalCommentDetail;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>Java class for retrieveGoalPlannerInfoWSResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveGoalPlannerInfoWSResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse">
 *       &lt;sequence>
 *         &lt;element name="planLevelCommentList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}comment" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="documentChecklist" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}documentChecklist" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="goalCommentDetailList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalCommentDetail" maxOccurs="999" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveGoalPlannerInfoWSResponse", propOrder = {
    "planLevelCommentList",
    "documentChecklist",
    "goalCommentDetailList"
})
public class RetrieveGoalPlannerInfoWSResponse
    extends WebServiceResponse
{

    @XmlElement(nillable = true)
    protected List<Comment> planLevelCommentList;
    @XmlElement(nillable = true)
    protected List<DocumentChecklist> documentChecklist;
    @XmlElement(nillable = true)
    protected List<GoalCommentDetail> goalCommentDetailList;

    /**
     * Gets the value of the planLevelCommentList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the planLevelCommentList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPlanLevelCommentList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Comment }
     * 
     * 
     */
    public List<Comment> getPlanLevelCommentList() {
        if (planLevelCommentList == null) {
            planLevelCommentList = new ArrayList<Comment>();
        }
        return this.planLevelCommentList;
    }

    /**
     * Gets the value of the documentChecklist property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documentChecklist property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumentChecklist().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentChecklist }
     * 
     * 
     */
    public List<DocumentChecklist> getDocumentChecklist() {
        if (documentChecklist == null) {
            documentChecklist = new ArrayList<DocumentChecklist>();
        }
        return this.documentChecklist;
    }

    /**
     * Gets the value of the goalCommentDetailList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalCommentDetailList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalCommentDetailList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalCommentDetail }
     * 
     * 
     */
    public List<GoalCommentDetail> getGoalCommentDetailList() {
        if (goalCommentDetailList == null) {
            goalCommentDetailList = new ArrayList<GoalCommentDetail>();
        }
        return this.goalCommentDetailList;
    }

}
