
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for portfolioAssetAllocationSummary complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="portfolioAssetAllocationSummary">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="portfolioAssetAllocations" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}portfolioAssetAllocation" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="portfolioLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "portfolioAssetAllocationSummary", propOrder = {
    "portfolioAssetAllocations",
    "portfolioLevelCode"
})
public class PortfolioAssetAllocationSummary {

    @XmlElement(nillable = true)
    protected List<PortfolioAssetAllocation> portfolioAssetAllocations;
    protected String portfolioLevelCode;

    /**
     * Gets the value of the portfolioAssetAllocations property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the portfolioAssetAllocations property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPortfolioAssetAllocations().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PortfolioAssetAllocation }
     * 
     * 
     */
    public List<PortfolioAssetAllocation> getPortfolioAssetAllocations() {
        if (portfolioAssetAllocations == null) {
            portfolioAssetAllocations = new ArrayList<PortfolioAssetAllocation>();
        }
        return this.portfolioAssetAllocations;
    }

    /**
     * Gets the value of the portfolioLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortfolioLevelCode() {
        return portfolioLevelCode;
    }

    /**
     * Sets the value of the portfolioLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortfolioLevelCode(String value) {
        this.portfolioLevelCode = value;
    }

}
