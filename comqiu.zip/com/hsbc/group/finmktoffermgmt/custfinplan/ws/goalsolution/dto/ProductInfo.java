
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for productInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="allocationSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="assetClassGroupCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="assetClassGroupName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyAssetAllocationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyCurrentInvestmentAmountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyInvestmentInitialCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyInvestmentMonthlyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyProductCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyTargetInvestmentAmountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currentInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="investmentInitialAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="investmentMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="overiddenEligibilityIntegrityIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productSubtypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="riskLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="targetInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productInfo", propOrder = {
    "allocationSequenceNumber",
    "assetClassGroupCode",
    "assetClassGroupName",
    "currencyAssetAllocationCode",
    "currencyCurrentInvestmentAmountCode",
    "currencyInvestmentInitialCode",
    "currencyInvestmentMonthlyCode",
    "currencyProductCode",
    "currencyTargetInvestmentAmountCode",
    "currentInvestmentAmount",
    "investmentInitialAmount",
    "investmentMonthlyAmount",
    "overiddenEligibilityIntegrityIndicator",
    "productName",
    "productSelectionMethodCode",
    "productSubtypeCode",
    "riskLevelCode",
    "targetInvestmentAmount"
})
public class ProductInfo {

    protected long allocationSequenceNumber;
    protected String assetClassGroupCode;
    protected String assetClassGroupName;
    protected String currencyAssetAllocationCode;
    protected String currencyCurrentInvestmentAmountCode;
    protected String currencyInvestmentInitialCode;
    protected String currencyInvestmentMonthlyCode;
    protected String currencyProductCode;
    protected String currencyTargetInvestmentAmountCode;
    protected BigDecimal currentInvestmentAmount;
    protected BigDecimal investmentInitialAmount;
    protected BigDecimal investmentMonthlyAmount;
    protected String overiddenEligibilityIntegrityIndicator;
    protected String productName;
    protected String productSelectionMethodCode;
    protected String productSubtypeCode;
    protected String riskLevelCode;
    protected BigDecimal targetInvestmentAmount;

    /**
     * Gets the value of the allocationSequenceNumber property.
     * 
     */
    public long getAllocationSequenceNumber() {
        return allocationSequenceNumber;
    }

    /**
     * Sets the value of the allocationSequenceNumber property.
     * 
     */
    public void setAllocationSequenceNumber(long value) {
        this.allocationSequenceNumber = value;
    }

    /**
     * Gets the value of the assetClassGroupCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupCode() {
        return assetClassGroupCode;
    }

    /**
     * Sets the value of the assetClassGroupCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupCode(String value) {
        this.assetClassGroupCode = value;
    }

    /**
     * Gets the value of the assetClassGroupName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupName() {
        return assetClassGroupName;
    }

    /**
     * Sets the value of the assetClassGroupName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupName(String value) {
        this.assetClassGroupName = value;
    }

    /**
     * Gets the value of the currencyAssetAllocationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAssetAllocationCode() {
        return currencyAssetAllocationCode;
    }

    /**
     * Sets the value of the currencyAssetAllocationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAssetAllocationCode(String value) {
        this.currencyAssetAllocationCode = value;
    }

    /**
     * Gets the value of the currencyCurrentInvestmentAmountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCurrentInvestmentAmountCode() {
        return currencyCurrentInvestmentAmountCode;
    }

    /**
     * Sets the value of the currencyCurrentInvestmentAmountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCurrentInvestmentAmountCode(String value) {
        this.currencyCurrentInvestmentAmountCode = value;
    }

    /**
     * Gets the value of the currencyInvestmentInitialCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentInitialCode() {
        return currencyInvestmentInitialCode;
    }

    /**
     * Sets the value of the currencyInvestmentInitialCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentInitialCode(String value) {
        this.currencyInvestmentInitialCode = value;
    }

    /**
     * Gets the value of the currencyInvestmentMonthlyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentMonthlyCode() {
        return currencyInvestmentMonthlyCode;
    }

    /**
     * Sets the value of the currencyInvestmentMonthlyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentMonthlyCode(String value) {
        this.currencyInvestmentMonthlyCode = value;
    }

    /**
     * Gets the value of the currencyProductCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyProductCode() {
        return currencyProductCode;
    }

    /**
     * Sets the value of the currencyProductCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyProductCode(String value) {
        this.currencyProductCode = value;
    }

    /**
     * Gets the value of the currencyTargetInvestmentAmountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyTargetInvestmentAmountCode() {
        return currencyTargetInvestmentAmountCode;
    }

    /**
     * Sets the value of the currencyTargetInvestmentAmountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyTargetInvestmentAmountCode(String value) {
        this.currencyTargetInvestmentAmountCode = value;
    }

    /**
     * Gets the value of the currentInvestmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentInvestmentAmount() {
        return currentInvestmentAmount;
    }

    /**
     * Sets the value of the currentInvestmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentInvestmentAmount(BigDecimal value) {
        this.currentInvestmentAmount = value;
    }

    /**
     * Gets the value of the investmentInitialAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentInitialAmount() {
        return investmentInitialAmount;
    }

    /**
     * Sets the value of the investmentInitialAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentInitialAmount(BigDecimal value) {
        this.investmentInitialAmount = value;
    }

    /**
     * Gets the value of the investmentMonthlyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentMonthlyAmount() {
        return investmentMonthlyAmount;
    }

    /**
     * Sets the value of the investmentMonthlyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentMonthlyAmount(BigDecimal value) {
        this.investmentMonthlyAmount = value;
    }

    /**
     * Gets the value of the overiddenEligibilityIntegrityIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOveriddenEligibilityIntegrityIndicator() {
        return overiddenEligibilityIntegrityIndicator;
    }

    /**
     * Sets the value of the overiddenEligibilityIntegrityIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOveriddenEligibilityIntegrityIndicator(String value) {
        this.overiddenEligibilityIntegrityIndicator = value;
    }

    /**
     * Gets the value of the productName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the value of the productName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductName(String value) {
        this.productName = value;
    }

    /**
     * Gets the value of the productSelectionMethodCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * Sets the value of the productSelectionMethodCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * Gets the value of the productSubtypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSubtypeCode() {
        return productSubtypeCode;
    }

    /**
     * Sets the value of the productSubtypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSubtypeCode(String value) {
        this.productSubtypeCode = value;
    }

    /**
     * Gets the value of the riskLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRiskLevelCode() {
        return riskLevelCode;
    }

    /**
     * Sets the value of the riskLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRiskLevelCode(String value) {
        this.riskLevelCode = value;
    }

    /**
     * Gets the value of the targetInvestmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTargetInvestmentAmount() {
        return targetInvestmentAmount;
    }

    /**
     * Sets the value of the targetInvestmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTargetInvestmentAmount(BigDecimal value) {
        this.targetInvestmentAmount = value;
    }

}
