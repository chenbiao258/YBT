
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for portfolioCalculationResult complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="portfolioCalculationResult">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="portfolioRickLevelValidationIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="riskLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "portfolioCalculationResult", propOrder = {
    "portfolioRickLevelValidationIndicator",
    "riskLevelNumber"
})
public class PortfolioCalculationResult {

    protected String portfolioRickLevelValidationIndicator;
    protected int riskLevelNumber;

    /**
     * Gets the value of the portfolioRickLevelValidationIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortfolioRickLevelValidationIndicator() {
        return portfolioRickLevelValidationIndicator;
    }

    /**
     * Sets the value of the portfolioRickLevelValidationIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortfolioRickLevelValidationIndicator(String value) {
        this.portfolioRickLevelValidationIndicator = value;
    }

    /**
     * Gets the value of the riskLevelNumber property.
     * 
     */
    public int getRiskLevelNumber() {
        return riskLevelNumber;
    }

    /**
     * Sets the value of the riskLevelNumber property.
     * 
     */
    public void setRiskLevelNumber(int value) {
        this.riskLevelNumber = value;
    }

}
