
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveManagedSolutionDetailWSResponse;


/**
 * <p>Java class for retrieveManagedSolutionDetailResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveManagedSolutionDetailResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}retrieveManagedSolutionDetailWSResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveManagedSolutionDetailResponse", propOrder = {
    "_return"
})
public class RetrieveManagedSolutionDetailResponse {

    @XmlElement(name = "return")
    protected RetrieveManagedSolutionDetailWSResponse _return;

    /**
     * Gets the value of the return property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveManagedSolutionDetailWSResponse }
     *     
     */
    public RetrieveManagedSolutionDetailWSResponse getReturn() {
        return _return;
    }

    /**
     * Sets the value of the return property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveManagedSolutionDetailWSResponse }
     *     
     */
    public void setReturn(RetrieveManagedSolutionDetailWSResponse value) {
        this._return = value;
    }

}
