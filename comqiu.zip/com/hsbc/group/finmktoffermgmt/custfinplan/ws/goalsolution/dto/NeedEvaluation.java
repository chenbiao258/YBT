
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for needEvaluation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="needEvaluation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="currencyInsuranceNeedCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="insuranceNeedAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="insuranceNeedOtherText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="insuranceNeedTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "needEvaluation", propOrder = {
    "currencyInsuranceNeedCode",
    "insuranceNeedAmount",
    "insuranceNeedOtherText",
    "insuranceNeedTypeCode"
})
public class NeedEvaluation {

    protected String currencyInsuranceNeedCode;
    protected BigDecimal insuranceNeedAmount;
    protected String insuranceNeedOtherText;
    protected String insuranceNeedTypeCode;

    /**
     * Gets the value of the currencyInsuranceNeedCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInsuranceNeedCode() {
        return currencyInsuranceNeedCode;
    }

    /**
     * Sets the value of the currencyInsuranceNeedCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInsuranceNeedCode(String value) {
        this.currencyInsuranceNeedCode = value;
    }

    /**
     * Gets the value of the insuranceNeedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInsuranceNeedAmount() {
        return insuranceNeedAmount;
    }

    /**
     * Sets the value of the insuranceNeedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInsuranceNeedAmount(BigDecimal value) {
        this.insuranceNeedAmount = value;
    }

    /**
     * Gets the value of the insuranceNeedOtherText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsuranceNeedOtherText() {
        return insuranceNeedOtherText;
    }

    /**
     * Sets the value of the insuranceNeedOtherText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsuranceNeedOtherText(String value) {
        this.insuranceNeedOtherText = value;
    }

    /**
     * Gets the value of the insuranceNeedTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsuranceNeedTypeCode() {
        return insuranceNeedTypeCode;
    }

    /**
     * Sets the value of the insuranceNeedTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsuranceNeedTypeCode(String value) {
        this.insuranceNeedTypeCode = value;
    }

}
