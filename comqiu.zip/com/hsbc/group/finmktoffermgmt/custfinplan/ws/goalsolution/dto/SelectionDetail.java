
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for selectionDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="selectionDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="employeeAdviceIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="financialPlanningProductPackageName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="financialPlanningProductPackageSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productSelectionCompleteDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="riskLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="solutionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "selectionDetail", propOrder = {
    "employeeAdviceIndicator",
    "financialPlanningProductPackageName",
    "financialPlanningProductPackageSequenceNumber",
    "productSelectionCompleteDateTime",
    "productSelectionMethodCode",
    "riskLevelNumber",
    "solutionId"
})
public class SelectionDetail {

    protected String employeeAdviceIndicator;
    protected String financialPlanningProductPackageName;
    protected String financialPlanningProductPackageSequenceNumber;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar productSelectionCompleteDateTime;
    protected String productSelectionMethodCode;
    protected Integer riskLevelNumber;
    protected String solutionId;

    /**
     * Gets the value of the employeeAdviceIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeAdviceIndicator() {
        return employeeAdviceIndicator;
    }

    /**
     * Sets the value of the employeeAdviceIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeAdviceIndicator(String value) {
        this.employeeAdviceIndicator = value;
    }

    /**
     * Gets the value of the financialPlanningProductPackageName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialPlanningProductPackageName() {
        return financialPlanningProductPackageName;
    }

    /**
     * Sets the value of the financialPlanningProductPackageName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialPlanningProductPackageName(String value) {
        this.financialPlanningProductPackageName = value;
    }

    /**
     * Gets the value of the financialPlanningProductPackageSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialPlanningProductPackageSequenceNumber() {
        return financialPlanningProductPackageSequenceNumber;
    }

    /**
     * Sets the value of the financialPlanningProductPackageSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialPlanningProductPackageSequenceNumber(String value) {
        this.financialPlanningProductPackageSequenceNumber = value;
    }

    /**
     * Gets the value of the productSelectionCompleteDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getProductSelectionCompleteDateTime() {
        return productSelectionCompleteDateTime;
    }

    /**
     * Sets the value of the productSelectionCompleteDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setProductSelectionCompleteDateTime(XMLGregorianCalendar value) {
        this.productSelectionCompleteDateTime = value;
    }

    /**
     * Gets the value of the productSelectionMethodCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * Sets the value of the productSelectionMethodCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * Gets the value of the riskLevelNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskLevelNumber() {
        return riskLevelNumber;
    }

    /**
     * Sets the value of the riskLevelNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskLevelNumber(Integer value) {
        this.riskLevelNumber = value;
    }

    /**
     * Gets the value of the solutionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSolutionId() {
        return solutionId;
    }

    /**
     * Sets the value of the solutionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSolutionId(String value) {
        this.solutionId = value;
    }

}
