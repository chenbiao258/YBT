
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for currentPortfolioAllocation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="currentPortfolioAllocation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="allocationInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="allocationInvestmentAmountCurrency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="allocationInvestmentPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="allocationInvestmentPieChartPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="allocationInvestmentPieChartPercentLongShortIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="assetClassGroupCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="assetClassGroupName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "currentPortfolioAllocation", propOrder = {
    "allocationInvestmentAmount",
    "allocationInvestmentAmountCurrency",
    "allocationInvestmentPercent",
    "allocationInvestmentPieChartPercent",
    "allocationInvestmentPieChartPercentLongShortIndicator",
    "assetClassGroupCode",
    "assetClassGroupName"
})
public class CurrentPortfolioAllocation {

    protected BigDecimal allocationInvestmentAmount;
    protected String allocationInvestmentAmountCurrency;
    protected BigDecimal allocationInvestmentPercent;
    protected BigDecimal allocationInvestmentPieChartPercent;
    protected String allocationInvestmentPieChartPercentLongShortIndicator;
    protected String assetClassGroupCode;
    protected String assetClassGroupName;

    /**
     * Gets the value of the allocationInvestmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentAmount() {
        return allocationInvestmentAmount;
    }

    /**
     * Sets the value of the allocationInvestmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentAmount(BigDecimal value) {
        this.allocationInvestmentAmount = value;
    }

    /**
     * Gets the value of the allocationInvestmentAmountCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocationInvestmentAmountCurrency() {
        return allocationInvestmentAmountCurrency;
    }

    /**
     * Sets the value of the allocationInvestmentAmountCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocationInvestmentAmountCurrency(String value) {
        this.allocationInvestmentAmountCurrency = value;
    }

    /**
     * Gets the value of the allocationInvestmentPercent property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPercent() {
        return allocationInvestmentPercent;
    }

    /**
     * Sets the value of the allocationInvestmentPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPercent(BigDecimal value) {
        this.allocationInvestmentPercent = value;
    }

    /**
     * Gets the value of the allocationInvestmentPieChartPercent property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPieChartPercent() {
        return allocationInvestmentPieChartPercent;
    }

    /**
     * Sets the value of the allocationInvestmentPieChartPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPieChartPercent(BigDecimal value) {
        this.allocationInvestmentPieChartPercent = value;
    }

    /**
     * Gets the value of the allocationInvestmentPieChartPercentLongShortIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocationInvestmentPieChartPercentLongShortIndicator() {
        return allocationInvestmentPieChartPercentLongShortIndicator;
    }

    /**
     * Sets the value of the allocationInvestmentPieChartPercentLongShortIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocationInvestmentPieChartPercentLongShortIndicator(String value) {
        this.allocationInvestmentPieChartPercentLongShortIndicator = value;
    }

    /**
     * Gets the value of the assetClassGroupCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupCode() {
        return assetClassGroupCode;
    }

    /**
     * Sets the value of the assetClassGroupCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupCode(String value) {
        this.assetClassGroupCode = value;
    }

    /**
     * Gets the value of the assetClassGroupName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupName() {
        return assetClassGroupName;
    }

    /**
     * Sets the value of the assetClassGroupName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupName(String value) {
        this.assetClassGroupName = value;
    }

}
