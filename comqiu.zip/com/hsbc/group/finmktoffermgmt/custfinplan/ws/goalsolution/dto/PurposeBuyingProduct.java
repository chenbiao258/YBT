
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for purposeBuyingProduct complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="purposeBuyingProduct">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="purposeBuyingProductCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="purposeBuyingProductText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "purposeBuyingProduct", propOrder = {
    "purposeBuyingProductCode",
    "purposeBuyingProductText"
})
public class PurposeBuyingProduct {

    protected String purposeBuyingProductCode;
    protected String purposeBuyingProductText;

    /**
     * Gets the value of the purposeBuyingProductCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPurposeBuyingProductCode() {
        return purposeBuyingProductCode;
    }

    /**
     * Sets the value of the purposeBuyingProductCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPurposeBuyingProductCode(String value) {
        this.purposeBuyingProductCode = value;
    }

    /**
     * Gets the value of the purposeBuyingProductText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPurposeBuyingProductText() {
        return purposeBuyingProductText;
    }

    /**
     * Sets the value of the purposeBuyingProductText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPurposeBuyingProductText(String value) {
        this.purposeBuyingProductText = value;
    }

}
