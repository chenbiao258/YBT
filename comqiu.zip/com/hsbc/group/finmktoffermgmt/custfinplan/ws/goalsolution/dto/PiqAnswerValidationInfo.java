
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for piqAnswerValidationInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="piqAnswerValidationInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="age" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="currencyCurrentTaxIncomeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyCurrentTotalWealthCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currentTaxIncomeAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="currentTotalWealthAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="financialKnowledge" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="fiscalStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="highestMarginalTaxRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="investmentPercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="investmentPreferenceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="investmentPreferenceTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="investmentTerm" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="isValid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="riskProfile" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="timeHorizon" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "piqAnswerValidationInfo", propOrder = {
    "age",
    "currencyCurrentTaxIncomeCode",
    "currencyCurrentTotalWealthCode",
    "currentTaxIncomeAmount",
    "currentTotalWealthAmount",
    "financialKnowledge",
    "fiscalStatus",
    "highestMarginalTaxRate",
    "investmentPercentage",
    "investmentPreferenceCode",
    "investmentPreferenceTypeCode",
    "investmentTerm",
    "isValid",
    "riskProfile",
    "timeHorizon"
})
public class PiqAnswerValidationInfo {

    protected Long age;
    protected String currencyCurrentTaxIncomeCode;
    protected String currencyCurrentTotalWealthCode;
    protected BigDecimal currentTaxIncomeAmount;
    protected BigDecimal currentTotalWealthAmount;
    protected Long financialKnowledge;
    protected String fiscalStatus;
    protected BigDecimal highestMarginalTaxRate;
    protected BigDecimal investmentPercentage;
    protected String investmentPreferenceCode;
    protected String investmentPreferenceTypeCode;
    protected BigDecimal investmentTerm;
    protected String isValid;
    protected Long riskProfile;
    protected BigDecimal timeHorizon;

    /**
     * Gets the value of the age property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAge() {
        return age;
    }

    /**
     * Sets the value of the age property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAge(Long value) {
        this.age = value;
    }

    /**
     * Gets the value of the currencyCurrentTaxIncomeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCurrentTaxIncomeCode() {
        return currencyCurrentTaxIncomeCode;
    }

    /**
     * Sets the value of the currencyCurrentTaxIncomeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCurrentTaxIncomeCode(String value) {
        this.currencyCurrentTaxIncomeCode = value;
    }

    /**
     * Gets the value of the currencyCurrentTotalWealthCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCurrentTotalWealthCode() {
        return currencyCurrentTotalWealthCode;
    }

    /**
     * Sets the value of the currencyCurrentTotalWealthCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCurrentTotalWealthCode(String value) {
        this.currencyCurrentTotalWealthCode = value;
    }

    /**
     * Gets the value of the currentTaxIncomeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentTaxIncomeAmount() {
        return currentTaxIncomeAmount;
    }

    /**
     * Sets the value of the currentTaxIncomeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentTaxIncomeAmount(BigDecimal value) {
        this.currentTaxIncomeAmount = value;
    }

    /**
     * Gets the value of the currentTotalWealthAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentTotalWealthAmount() {
        return currentTotalWealthAmount;
    }

    /**
     * Sets the value of the currentTotalWealthAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentTotalWealthAmount(BigDecimal value) {
        this.currentTotalWealthAmount = value;
    }

    /**
     * Gets the value of the financialKnowledge property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getFinancialKnowledge() {
        return financialKnowledge;
    }

    /**
     * Sets the value of the financialKnowledge property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setFinancialKnowledge(Long value) {
        this.financialKnowledge = value;
    }

    /**
     * Gets the value of the fiscalStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFiscalStatus() {
        return fiscalStatus;
    }

    /**
     * Sets the value of the fiscalStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFiscalStatus(String value) {
        this.fiscalStatus = value;
    }

    /**
     * Gets the value of the highestMarginalTaxRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHighestMarginalTaxRate() {
        return highestMarginalTaxRate;
    }

    /**
     * Sets the value of the highestMarginalTaxRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHighestMarginalTaxRate(BigDecimal value) {
        this.highestMarginalTaxRate = value;
    }

    /**
     * Gets the value of the investmentPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentPercentage() {
        return investmentPercentage;
    }

    /**
     * Sets the value of the investmentPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentPercentage(BigDecimal value) {
        this.investmentPercentage = value;
    }

    /**
     * Gets the value of the investmentPreferenceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentPreferenceCode() {
        return investmentPreferenceCode;
    }

    /**
     * Sets the value of the investmentPreferenceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentPreferenceCode(String value) {
        this.investmentPreferenceCode = value;
    }

    /**
     * Gets the value of the investmentPreferenceTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentPreferenceTypeCode() {
        return investmentPreferenceTypeCode;
    }

    /**
     * Sets the value of the investmentPreferenceTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentPreferenceTypeCode(String value) {
        this.investmentPreferenceTypeCode = value;
    }

    /**
     * Gets the value of the investmentTerm property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentTerm() {
        return investmentTerm;
    }

    /**
     * Sets the value of the investmentTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentTerm(BigDecimal value) {
        this.investmentTerm = value;
    }

    /**
     * Gets the value of the isValid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsValid() {
        return isValid;
    }

    /**
     * Sets the value of the isValid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsValid(String value) {
        this.isValid = value;
    }

    /**
     * Gets the value of the riskProfile property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRiskProfile() {
        return riskProfile;
    }

    /**
     * Sets the value of the riskProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRiskProfile(Long value) {
        this.riskProfile = value;
    }

    /**
     * Gets the value of the timeHorizon property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTimeHorizon() {
        return timeHorizon;
    }

    /**
     * Sets the value of the timeHorizon property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTimeHorizon(BigDecimal value) {
        this.timeHorizon = value;
    }

}
