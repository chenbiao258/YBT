
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalPlannerInfoWSRequest;


/**
 * <p>Java class for retrieveGoalPlannerInfoWebService complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveGoalPlannerInfoWebService">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="arg0" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}retrieveGoalPlannerInfoWSRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveGoalPlannerInfoWebService", propOrder = {
    "arg0"
})
public class RetrieveGoalPlannerInfoWebService {

    protected RetrieveGoalPlannerInfoWSRequest arg0;

    /**
     * Gets the value of the arg0 property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveGoalPlannerInfoWSRequest }
     *     
     */
    public RetrieveGoalPlannerInfoWSRequest getArg0() {
        return arg0;
    }

    /**
     * Sets the value of the arg0 property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveGoalPlannerInfoWSRequest }
     *     
     */
    public void setArg0(RetrieveGoalPlannerInfoWSRequest value) {
        this.arg0 = value;
    }

}
