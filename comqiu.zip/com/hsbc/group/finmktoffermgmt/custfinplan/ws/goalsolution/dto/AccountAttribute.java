
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for accountAttribute complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="accountAttribute">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountNickName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountProductTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="countryAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dashboardAccountSubGroupIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="groupMemberAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="restrictWrapperFromSwitchingIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="wrapperManagementStyle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "accountAttribute", propOrder = {
    "accountNickName",
    "accountNumber",
    "accountProductTypeCode",
    "accountTypeCode",
    "countryAccountCode",
    "currencyAccountCode",
    "dashboardAccountSubGroupIdentifier",
    "groupMemberAccountCode",
    "restrictWrapperFromSwitchingIndicator",
    "wrapperManagementStyle"
})
public class AccountAttribute {

    protected String accountNickName;
    protected String accountNumber;
    protected String accountProductTypeCode;
    protected String accountTypeCode;
    protected String countryAccountCode;
    protected String currencyAccountCode;
    protected String dashboardAccountSubGroupIdentifier;
    protected String groupMemberAccountCode;
    protected Boolean restrictWrapperFromSwitchingIndicator;
    protected String wrapperManagementStyle;

    /**
     * Gets the value of the accountNickName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNickName() {
        return accountNickName;
    }

    /**
     * Sets the value of the accountNickName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNickName(String value) {
        this.accountNickName = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the accountProductTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountProductTypeCode() {
        return accountProductTypeCode;
    }

    /**
     * Sets the value of the accountProductTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountProductTypeCode(String value) {
        this.accountProductTypeCode = value;
    }

    /**
     * Gets the value of the accountTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTypeCode() {
        return accountTypeCode;
    }

    /**
     * Sets the value of the accountTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTypeCode(String value) {
        this.accountTypeCode = value;
    }

    /**
     * Gets the value of the countryAccountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryAccountCode() {
        return countryAccountCode;
    }

    /**
     * Sets the value of the countryAccountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryAccountCode(String value) {
        this.countryAccountCode = value;
    }

    /**
     * Gets the value of the currencyAccountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAccountCode() {
        return currencyAccountCode;
    }

    /**
     * Sets the value of the currencyAccountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAccountCode(String value) {
        this.currencyAccountCode = value;
    }

    /**
     * Gets the value of the dashboardAccountSubGroupIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDashboardAccountSubGroupIdentifier() {
        return dashboardAccountSubGroupIdentifier;
    }

    /**
     * Sets the value of the dashboardAccountSubGroupIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDashboardAccountSubGroupIdentifier(String value) {
        this.dashboardAccountSubGroupIdentifier = value;
    }

    /**
     * Gets the value of the groupMemberAccountCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupMemberAccountCode() {
        return groupMemberAccountCode;
    }

    /**
     * Sets the value of the groupMemberAccountCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupMemberAccountCode(String value) {
        this.groupMemberAccountCode = value;
    }

    /**
     * Gets the value of the restrictWrapperFromSwitchingIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRestrictWrapperFromSwitchingIndicator() {
        return restrictWrapperFromSwitchingIndicator;
    }

    /**
     * Sets the value of the restrictWrapperFromSwitchingIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRestrictWrapperFromSwitchingIndicator(Boolean value) {
        this.restrictWrapperFromSwitchingIndicator = value;
    }

    /**
     * Gets the value of the wrapperManagementStyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperManagementStyle() {
        return wrapperManagementStyle;
    }

    /**
     * Sets the value of the wrapperManagementStyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperManagementStyle(String value) {
        this.wrapperManagementStyle = value;
    }

}
