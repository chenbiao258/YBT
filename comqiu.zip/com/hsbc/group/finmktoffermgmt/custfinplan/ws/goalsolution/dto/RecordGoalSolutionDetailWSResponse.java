
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.CacheIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.simulator.dto.Status;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>Java class for recordGoalSolutionDetailWSResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="recordGoalSolutionDetailWSResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse">
 *       &lt;sequence>
 *         &lt;element name="status" type="{http://dto.simulator.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}status" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="cacheIndicator" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}cacheIndicator" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "recordGoalSolutionDetailWSResponse", propOrder = {
    "status",
    "cacheIndicator"
})
public class RecordGoalSolutionDetailWSResponse
    extends WebServiceResponse
{

    @XmlElement(nillable = true)
    protected List<Status> status;
    protected CacheIndicator cacheIndicator;

    /**
     * Gets the value of the status property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the status property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Status }
     * 
     * 
     */
    public List<Status> getStatus() {
        if (status == null) {
            status = new ArrayList<Status>();
        }
        return this.status;
    }

    /**
     * Gets the value of the cacheIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link CacheIndicator }
     *     
     */
    public CacheIndicator getCacheIndicator() {
        return cacheIndicator;
    }

    /**
     * Sets the value of the cacheIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link CacheIndicator }
     *     
     */
    public void setCacheIndicator(CacheIndicator value) {
        this.cacheIndicator = value;
    }

}
