
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalKey;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.RequestComment;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.RequestInvestorIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.CacheIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.quotation.dto.LocaleCode;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>Java class for retrieveGoalSolutionDetailWSRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveGoalSolutionDetailWSRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest">
 *       &lt;sequence>
 *         &lt;element name="cacheIndicator" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}cacheIndicator" minOccurs="0"/>
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" minOccurs="0"/>
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/>
 *         &lt;element name="localeCode" type="{http://dto.quotation.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}localeCode" minOccurs="0"/>
 *         &lt;element name="requestComment" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}requestComment" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="requestDataType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="requestInvestorIndicator" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}requestInvestorIndicator" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="subserviceId" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}subserviceId" maxOccurs="999" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveGoalSolutionDetailWSRequest", propOrder = {
    "cacheIndicator",
    "customers",
    "goalKey",
    "jointCustomer",
    "localeCode",
    "requestComment",
    "requestDataType",
    "requestInvestorIndicator",
    "subserviceId"
})
public class RetrieveGoalSolutionDetailWSRequest
    extends WebServiceRequest
{

    protected CacheIndicator cacheIndicator;
    @XmlElement(nillable = true)
    protected List<Customer> customers;
    protected GoalKey goalKey;
    protected Customer jointCustomer;
    protected LocaleCode localeCode;
    @XmlElement(nillable = true)
    protected List<RequestComment> requestComment;
    protected String requestDataType;
    @XmlElement(nillable = true)
    protected List<RequestInvestorIndicator> requestInvestorIndicator;
    @XmlElement(nillable = true)
    protected List<SubserviceId> subserviceId;

    /**
     * Gets the value of the cacheIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link CacheIndicator }
     *     
     */
    public CacheIndicator getCacheIndicator() {
        return cacheIndicator;
    }

    /**
     * Sets the value of the cacheIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link CacheIndicator }
     *     
     */
    public void setCacheIndicator(CacheIndicator value) {
        this.cacheIndicator = value;
    }

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the goalKey property.
     * 
     * @return
     *     possible object is
     *     {@link GoalKey }
     *     
     */
    public GoalKey getGoalKey() {
        return goalKey;
    }

    /**
     * Sets the value of the goalKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link GoalKey }
     *     
     */
    public void setGoalKey(GoalKey value) {
        this.goalKey = value;
    }

    /**
     * Gets the value of the jointCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * Sets the value of the jointCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * Gets the value of the localeCode property.
     * 
     * @return
     *     possible object is
     *     {@link LocaleCode }
     *     
     */
    public LocaleCode getLocaleCode() {
        return localeCode;
    }

    /**
     * Sets the value of the localeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocaleCode }
     *     
     */
    public void setLocaleCode(LocaleCode value) {
        this.localeCode = value;
    }

    /**
     * Gets the value of the requestComment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestComment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestComment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestComment }
     * 
     * 
     */
    public List<RequestComment> getRequestComment() {
        if (requestComment == null) {
            requestComment = new ArrayList<RequestComment>();
        }
        return this.requestComment;
    }

    /**
     * Gets the value of the requestDataType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestDataType() {
        return requestDataType;
    }

    /**
     * Sets the value of the requestDataType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestDataType(String value) {
        this.requestDataType = value;
    }

    /**
     * Gets the value of the requestInvestorIndicator property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestInvestorIndicator property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestInvestorIndicator().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestInvestorIndicator }
     * 
     * 
     */
    public List<RequestInvestorIndicator> getRequestInvestorIndicator() {
        if (requestInvestorIndicator == null) {
            requestInvestorIndicator = new ArrayList<RequestInvestorIndicator>();
        }
        return this.requestInvestorIndicator;
    }

    /**
     * Gets the value of the subserviceId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subserviceId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubserviceId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SubserviceId }
     * 
     * 
     */
    public List<SubserviceId> getSubserviceId() {
        if (subserviceId == null) {
            subserviceId = new ArrayList<SubserviceId>();
        }
        return this.subserviceId;
    }

}
