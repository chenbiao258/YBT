
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for multipleAdviceStyleAmountDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="multipleAdviceStyleAmountDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="lumpSumAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="lumpSumCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="monthlyInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="monthlyInvestmentCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalAllocatedAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="totalAllocatedCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "multipleAdviceStyleAmountDetail", propOrder = {
    "lumpSumAmount",
    "lumpSumCurrencyCode",
    "monthlyInvestmentAmount",
    "monthlyInvestmentCurrencyCode",
    "totalAllocatedAmount",
    "totalAllocatedCurrencyCode"
})
public class MultipleAdviceStyleAmountDetail {

    protected BigDecimal lumpSumAmount;
    protected String lumpSumCurrencyCode;
    protected BigDecimal monthlyInvestmentAmount;
    protected String monthlyInvestmentCurrencyCode;
    protected BigDecimal totalAllocatedAmount;
    protected String totalAllocatedCurrencyCode;

    /**
     * Gets the value of the lumpSumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getLumpSumAmount() {
        return lumpSumAmount;
    }

    /**
     * Sets the value of the lumpSumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLumpSumAmount(BigDecimal value) {
        this.lumpSumAmount = value;
    }

    /**
     * Gets the value of the lumpSumCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLumpSumCurrencyCode() {
        return lumpSumCurrencyCode;
    }

    /**
     * Sets the value of the lumpSumCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLumpSumCurrencyCode(String value) {
        this.lumpSumCurrencyCode = value;
    }

    /**
     * Gets the value of the monthlyInvestmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMonthlyInvestmentAmount() {
        return monthlyInvestmentAmount;
    }

    /**
     * Sets the value of the monthlyInvestmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMonthlyInvestmentAmount(BigDecimal value) {
        this.monthlyInvestmentAmount = value;
    }

    /**
     * Gets the value of the monthlyInvestmentCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMonthlyInvestmentCurrencyCode() {
        return monthlyInvestmentCurrencyCode;
    }

    /**
     * Sets the value of the monthlyInvestmentCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMonthlyInvestmentCurrencyCode(String value) {
        this.monthlyInvestmentCurrencyCode = value;
    }

    /**
     * Gets the value of the totalAllocatedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalAllocatedAmount() {
        return totalAllocatedAmount;
    }

    /**
     * Sets the value of the totalAllocatedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalAllocatedAmount(BigDecimal value) {
        this.totalAllocatedAmount = value;
    }

    /**
     * Gets the value of the totalAllocatedCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalAllocatedCurrencyCode() {
        return totalAllocatedCurrencyCode;
    }

    /**
     * Sets the value of the totalAllocatedCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalAllocatedCurrencyCode(String value) {
        this.totalAllocatedCurrencyCode = value;
    }

}
