
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>Java class for calculateGoalPortfolioWSResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="calculateGoalPortfolioWSResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse">
 *       &lt;sequence>
 *         &lt;element name="actualPortfolioAllocation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}actualPortfolioAllocation" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="currentPortfolioAllocation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}currentPortfolioAllocation" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="modelPortfolioAssetClassAllocation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}modelPortfolioAssetClassAllocation" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="portfolioCalculationResult" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}portfolioCalculationResult" minOccurs="0"/>
 *         &lt;element name="affordability" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}affordability" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="affordabilityValidation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}affordabilityValidation" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="assetConcentration" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assetConcentration" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="assetConcentrationValidation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assetConcentrationValidation" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="productConcentrationRiskCalculationResult" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productConcentrationRiskCalculationResult" maxOccurs="999" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateGoalPortfolioWSResponse", propOrder = {
    "actualPortfolioAllocation",
    "currentPortfolioAllocation",
    "modelPortfolioAssetClassAllocation",
    "portfolioCalculationResult",
    "affordability",
    "affordabilityValidation",
    "assetConcentration",
    "assetConcentrationValidation",
    "productConcentrationRiskCalculationResult"
})
public class CalculateGoalPortfolioWSResponse
    extends WebServiceResponse
{

    @XmlElement(nillable = true)
    protected List<ActualPortfolioAllocation> actualPortfolioAllocation;
    @XmlElement(nillable = true)
    protected List<CurrentPortfolioAllocation> currentPortfolioAllocation;
    @XmlElement(nillable = true)
    protected List<ModelPortfolioAssetClassAllocation> modelPortfolioAssetClassAllocation;
    protected PortfolioCalculationResult portfolioCalculationResult;
    @XmlElement(nillable = true)
    protected List<Affordability> affordability;
    @XmlElement(nillable = true)
    protected List<AffordabilityValidation> affordabilityValidation;
    @XmlElement(nillable = true)
    protected List<AssetConcentration> assetConcentration;
    @XmlElement(nillable = true)
    protected List<AssetConcentrationValidation> assetConcentrationValidation;
    @XmlElement(nillable = true)
    protected List<ProductConcentrationRiskCalculationResult> productConcentrationRiskCalculationResult;

    /**
     * Gets the value of the actualPortfolioAllocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the actualPortfolioAllocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActualPortfolioAllocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActualPortfolioAllocation }
     * 
     * 
     */
    public List<ActualPortfolioAllocation> getActualPortfolioAllocation() {
        if (actualPortfolioAllocation == null) {
            actualPortfolioAllocation = new ArrayList<ActualPortfolioAllocation>();
        }
        return this.actualPortfolioAllocation;
    }

    /**
     * Gets the value of the currentPortfolioAllocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the currentPortfolioAllocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCurrentPortfolioAllocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrentPortfolioAllocation }
     * 
     * 
     */
    public List<CurrentPortfolioAllocation> getCurrentPortfolioAllocation() {
        if (currentPortfolioAllocation == null) {
            currentPortfolioAllocation = new ArrayList<CurrentPortfolioAllocation>();
        }
        return this.currentPortfolioAllocation;
    }

    /**
     * Gets the value of the modelPortfolioAssetClassAllocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the modelPortfolioAssetClassAllocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getModelPortfolioAssetClassAllocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModelPortfolioAssetClassAllocation }
     * 
     * 
     */
    public List<ModelPortfolioAssetClassAllocation> getModelPortfolioAssetClassAllocation() {
        if (modelPortfolioAssetClassAllocation == null) {
            modelPortfolioAssetClassAllocation = new ArrayList<ModelPortfolioAssetClassAllocation>();
        }
        return this.modelPortfolioAssetClassAllocation;
    }

    /**
     * Gets the value of the portfolioCalculationResult property.
     * 
     * @return
     *     possible object is
     *     {@link PortfolioCalculationResult }
     *     
     */
    public PortfolioCalculationResult getPortfolioCalculationResult() {
        return portfolioCalculationResult;
    }

    /**
     * Sets the value of the portfolioCalculationResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link PortfolioCalculationResult }
     *     
     */
    public void setPortfolioCalculationResult(PortfolioCalculationResult value) {
        this.portfolioCalculationResult = value;
    }

    /**
     * Gets the value of the affordability property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affordability property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffordability().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Affordability }
     * 
     * 
     */
    public List<Affordability> getAffordability() {
        if (affordability == null) {
            affordability = new ArrayList<Affordability>();
        }
        return this.affordability;
    }

    /**
     * Gets the value of the affordabilityValidation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affordabilityValidation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffordabilityValidation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AffordabilityValidation }
     * 
     * 
     */
    public List<AffordabilityValidation> getAffordabilityValidation() {
        if (affordabilityValidation == null) {
            affordabilityValidation = new ArrayList<AffordabilityValidation>();
        }
        return this.affordabilityValidation;
    }

    /**
     * Gets the value of the assetConcentration property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assetConcentration property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssetConcentration().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssetConcentration }
     * 
     * 
     */
    public List<AssetConcentration> getAssetConcentration() {
        if (assetConcentration == null) {
            assetConcentration = new ArrayList<AssetConcentration>();
        }
        return this.assetConcentration;
    }

    /**
     * Gets the value of the assetConcentrationValidation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assetConcentrationValidation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssetConcentrationValidation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssetConcentrationValidation }
     * 
     * 
     */
    public List<AssetConcentrationValidation> getAssetConcentrationValidation() {
        if (assetConcentrationValidation == null) {
            assetConcentrationValidation = new ArrayList<AssetConcentrationValidation>();
        }
        return this.assetConcentrationValidation;
    }

    /**
     * Gets the value of the productConcentrationRiskCalculationResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productConcentrationRiskCalculationResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductConcentrationRiskCalculationResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductConcentrationRiskCalculationResult }
     * 
     * 
     */
    public List<ProductConcentrationRiskCalculationResult> getProductConcentrationRiskCalculationResult() {
        if (productConcentrationRiskCalculationResult == null) {
            productConcentrationRiskCalculationResult = new ArrayList<ProductConcentrationRiskCalculationResult>();
        }
        return this.productConcentrationRiskCalculationResult;
    }

}
