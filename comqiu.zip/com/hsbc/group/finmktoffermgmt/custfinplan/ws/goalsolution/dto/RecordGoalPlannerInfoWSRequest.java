
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.Comment;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.CommentAction;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.DocumentChecklist;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalCommentDetail;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>Java class for recordGoalPlannerInfoWSRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="recordGoalPlannerInfoWSRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest">
 *       &lt;sequence>
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="documentChecklist" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}documentChecklist" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="goalLevelCommentDetailList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalCommentDetail" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/>
 *         &lt;element name="planLevelCommentActionList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}commentAction" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="planLevelCommentList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}comment" maxOccurs="999" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "recordGoalPlannerInfoWSRequest", propOrder = {
    "customers",
    "documentChecklist",
    "goalLevelCommentDetailList",
    "jointCustomer",
    "planLevelCommentActionList",
    "planLevelCommentList"
})
public class RecordGoalPlannerInfoWSRequest
    extends WebServiceRequest
{

    @XmlElement(nillable = true)
    protected List<Customer> customers;
    @XmlElement(nillable = true)
    protected List<DocumentChecklist> documentChecklist;
    @XmlElement(nillable = true)
    protected List<GoalCommentDetail> goalLevelCommentDetailList;
    protected Customer jointCustomer;
    @XmlElement(nillable = true)
    protected List<CommentAction> planLevelCommentActionList;
    @XmlElement(nillable = true)
    protected List<Comment> planLevelCommentList;

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the documentChecklist property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documentChecklist property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumentChecklist().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentChecklist }
     * 
     * 
     */
    public List<DocumentChecklist> getDocumentChecklist() {
        if (documentChecklist == null) {
            documentChecklist = new ArrayList<DocumentChecklist>();
        }
        return this.documentChecklist;
    }

    /**
     * Gets the value of the goalLevelCommentDetailList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalLevelCommentDetailList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalLevelCommentDetailList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalCommentDetail }
     * 
     * 
     */
    public List<GoalCommentDetail> getGoalLevelCommentDetailList() {
        if (goalLevelCommentDetailList == null) {
            goalLevelCommentDetailList = new ArrayList<GoalCommentDetail>();
        }
        return this.goalLevelCommentDetailList;
    }

    /**
     * Gets the value of the jointCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * Sets the value of the jointCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * Gets the value of the planLevelCommentActionList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the planLevelCommentActionList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPlanLevelCommentActionList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommentAction }
     * 
     * 
     */
    public List<CommentAction> getPlanLevelCommentActionList() {
        if (planLevelCommentActionList == null) {
            planLevelCommentActionList = new ArrayList<CommentAction>();
        }
        return this.planLevelCommentActionList;
    }

    /**
     * Gets the value of the planLevelCommentList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the planLevelCommentList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPlanLevelCommentList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Comment }
     * 
     * 
     */
    public List<Comment> getPlanLevelCommentList() {
        if (planLevelCommentList == null) {
            planLevelCommentList = new ArrayList<Comment>();
        }
        return this.planLevelCommentList;
    }

}
