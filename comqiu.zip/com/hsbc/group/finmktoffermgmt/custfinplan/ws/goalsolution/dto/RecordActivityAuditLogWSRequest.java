
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.dto.AuditLog;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalKey;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>Java class for recordActivityAuditLogWSRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="recordActivityAuditLogWSRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest">
 *       &lt;sequence>
 *         &lt;element name="auditLog" type="{http://dto.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}auditLog" minOccurs="0"/>
 *         &lt;element name="cacheInfo" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}cacheInfo" minOccurs="0"/>
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" maxOccurs="999" minOccurs="0"/>
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "recordActivityAuditLogWSRequest", propOrder = {
    "auditLog",
    "cacheInfo",
    "customers",
    "goalKey",
    "jointCustomer"
})
public class RecordActivityAuditLogWSRequest
    extends WebServiceRequest
{

    protected AuditLog auditLog;
    protected CacheInfo cacheInfo;
    @XmlElement(nillable = true)
    protected List<Customer> customers;
    @XmlElement(nillable = true)
    protected List<GoalKey> goalKey;
    protected Customer jointCustomer;

    /**
     * Gets the value of the auditLog property.
     * 
     * @return
     *     possible object is
     *     {@link AuditLog }
     *     
     */
    public AuditLog getAuditLog() {
        return auditLog;
    }

    /**
     * Sets the value of the auditLog property.
     * 
     * @param value
     *     allowed object is
     *     {@link AuditLog }
     *     
     */
    public void setAuditLog(AuditLog value) {
        this.auditLog = value;
    }

    /**
     * Gets the value of the cacheInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CacheInfo }
     *     
     */
    public CacheInfo getCacheInfo() {
        return cacheInfo;
    }

    /**
     * Sets the value of the cacheInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CacheInfo }
     *     
     */
    public void setCacheInfo(CacheInfo value) {
        this.cacheInfo = value;
    }

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the goalKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalKey }
     * 
     * 
     */
    public List<GoalKey> getGoalKey() {
        if (goalKey == null) {
            goalKey = new ArrayList<GoalKey>();
        }
        return this.goalKey;
    }

    /**
     * Gets the value of the jointCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * Sets the value of the jointCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

}
