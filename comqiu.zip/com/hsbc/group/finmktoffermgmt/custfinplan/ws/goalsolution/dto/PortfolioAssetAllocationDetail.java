
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for portfolioAssetAllocationDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="portfolioAssetAllocationDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="allocationInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="allocationInvestmentAmountCurrency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="allocationInvestmentPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="allocationInvestmentPieChartPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="allocationInvestmentPieChartPercentLongShortIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="assetClassGroupCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="assetClassGroupName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="maximumAllocationInvestmentAmountCurrencyFirstRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="maximumAllocationInvestmentAmountCurrencySecondRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="maximumAllocationInvestmentAmountFirstRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="maximumAllocationInvestmentAmountSecondRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="maximumAllocationInvestmentPercentFirstRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="maximumAllocationInvestmentPercentSecondRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="minimumAllocationInvestmentAmountCurrencyFirstRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="minimumAllocationInvestmentAmountCurrencySecondRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="minimumAllocationInvestmentAmountFirstRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="minimumAllocationInvestmentAmountSecondRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="minimumAllocationInvestmentPercentFirstRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="minimumAllocationInvestmentPercentSecondRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "portfolioAssetAllocationDetail", propOrder = {
    "allocationInvestmentAmount",
    "allocationInvestmentAmountCurrency",
    "allocationInvestmentPercent",
    "allocationInvestmentPieChartPercent",
    "allocationInvestmentPieChartPercentLongShortIndicator",
    "assetClassGroupCode",
    "assetClassGroupName",
    "maximumAllocationInvestmentAmountCurrencyFirstRange",
    "maximumAllocationInvestmentAmountCurrencySecondRange",
    "maximumAllocationInvestmentAmountFirstRange",
    "maximumAllocationInvestmentAmountSecondRange",
    "maximumAllocationInvestmentPercentFirstRange",
    "maximumAllocationInvestmentPercentSecondRange",
    "minimumAllocationInvestmentAmountCurrencyFirstRange",
    "minimumAllocationInvestmentAmountCurrencySecondRange",
    "minimumAllocationInvestmentAmountFirstRange",
    "minimumAllocationInvestmentAmountSecondRange",
    "minimumAllocationInvestmentPercentFirstRange",
    "minimumAllocationInvestmentPercentSecondRange"
})
public class PortfolioAssetAllocationDetail {

    protected BigDecimal allocationInvestmentAmount;
    protected String allocationInvestmentAmountCurrency;
    protected BigDecimal allocationInvestmentPercent;
    protected BigDecimal allocationInvestmentPieChartPercent;
    protected String allocationInvestmentPieChartPercentLongShortIndicator;
    protected String assetClassGroupCode;
    protected String assetClassGroupName;
    protected String maximumAllocationInvestmentAmountCurrencyFirstRange;
    protected String maximumAllocationInvestmentAmountCurrencySecondRange;
    protected BigDecimal maximumAllocationInvestmentAmountFirstRange;
    protected BigDecimal maximumAllocationInvestmentAmountSecondRange;
    protected BigDecimal maximumAllocationInvestmentPercentFirstRange;
    protected BigDecimal maximumAllocationInvestmentPercentSecondRange;
    protected String minimumAllocationInvestmentAmountCurrencyFirstRange;
    protected String minimumAllocationInvestmentAmountCurrencySecondRange;
    protected BigDecimal minimumAllocationInvestmentAmountFirstRange;
    protected BigDecimal minimumAllocationInvestmentAmountSecondRange;
    protected BigDecimal minimumAllocationInvestmentPercentFirstRange;
    protected BigDecimal minimumAllocationInvestmentPercentSecondRange;

    /**
     * Gets the value of the allocationInvestmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentAmount() {
        return allocationInvestmentAmount;
    }

    /**
     * Sets the value of the allocationInvestmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentAmount(BigDecimal value) {
        this.allocationInvestmentAmount = value;
    }

    /**
     * Gets the value of the allocationInvestmentAmountCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocationInvestmentAmountCurrency() {
        return allocationInvestmentAmountCurrency;
    }

    /**
     * Sets the value of the allocationInvestmentAmountCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocationInvestmentAmountCurrency(String value) {
        this.allocationInvestmentAmountCurrency = value;
    }

    /**
     * Gets the value of the allocationInvestmentPercent property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPercent() {
        return allocationInvestmentPercent;
    }

    /**
     * Sets the value of the allocationInvestmentPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPercent(BigDecimal value) {
        this.allocationInvestmentPercent = value;
    }

    /**
     * Gets the value of the allocationInvestmentPieChartPercent property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPieChartPercent() {
        return allocationInvestmentPieChartPercent;
    }

    /**
     * Sets the value of the allocationInvestmentPieChartPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPieChartPercent(BigDecimal value) {
        this.allocationInvestmentPieChartPercent = value;
    }

    /**
     * Gets the value of the allocationInvestmentPieChartPercentLongShortIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocationInvestmentPieChartPercentLongShortIndicator() {
        return allocationInvestmentPieChartPercentLongShortIndicator;
    }

    /**
     * Sets the value of the allocationInvestmentPieChartPercentLongShortIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocationInvestmentPieChartPercentLongShortIndicator(String value) {
        this.allocationInvestmentPieChartPercentLongShortIndicator = value;
    }

    /**
     * Gets the value of the assetClassGroupCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupCode() {
        return assetClassGroupCode;
    }

    /**
     * Sets the value of the assetClassGroupCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupCode(String value) {
        this.assetClassGroupCode = value;
    }

    /**
     * Gets the value of the assetClassGroupName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupName() {
        return assetClassGroupName;
    }

    /**
     * Sets the value of the assetClassGroupName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupName(String value) {
        this.assetClassGroupName = value;
    }

    /**
     * Gets the value of the maximumAllocationInvestmentAmountCurrencyFirstRange property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaximumAllocationInvestmentAmountCurrencyFirstRange() {
        return maximumAllocationInvestmentAmountCurrencyFirstRange;
    }

    /**
     * Sets the value of the maximumAllocationInvestmentAmountCurrencyFirstRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaximumAllocationInvestmentAmountCurrencyFirstRange(String value) {
        this.maximumAllocationInvestmentAmountCurrencyFirstRange = value;
    }

    /**
     * Gets the value of the maximumAllocationInvestmentAmountCurrencySecondRange property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaximumAllocationInvestmentAmountCurrencySecondRange() {
        return maximumAllocationInvestmentAmountCurrencySecondRange;
    }

    /**
     * Sets the value of the maximumAllocationInvestmentAmountCurrencySecondRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaximumAllocationInvestmentAmountCurrencySecondRange(String value) {
        this.maximumAllocationInvestmentAmountCurrencySecondRange = value;
    }

    /**
     * Gets the value of the maximumAllocationInvestmentAmountFirstRange property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximumAllocationInvestmentAmountFirstRange() {
        return maximumAllocationInvestmentAmountFirstRange;
    }

    /**
     * Sets the value of the maximumAllocationInvestmentAmountFirstRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximumAllocationInvestmentAmountFirstRange(BigDecimal value) {
        this.maximumAllocationInvestmentAmountFirstRange = value;
    }

    /**
     * Gets the value of the maximumAllocationInvestmentAmountSecondRange property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximumAllocationInvestmentAmountSecondRange() {
        return maximumAllocationInvestmentAmountSecondRange;
    }

    /**
     * Sets the value of the maximumAllocationInvestmentAmountSecondRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximumAllocationInvestmentAmountSecondRange(BigDecimal value) {
        this.maximumAllocationInvestmentAmountSecondRange = value;
    }

    /**
     * Gets the value of the maximumAllocationInvestmentPercentFirstRange property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximumAllocationInvestmentPercentFirstRange() {
        return maximumAllocationInvestmentPercentFirstRange;
    }

    /**
     * Sets the value of the maximumAllocationInvestmentPercentFirstRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximumAllocationInvestmentPercentFirstRange(BigDecimal value) {
        this.maximumAllocationInvestmentPercentFirstRange = value;
    }

    /**
     * Gets the value of the maximumAllocationInvestmentPercentSecondRange property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximumAllocationInvestmentPercentSecondRange() {
        return maximumAllocationInvestmentPercentSecondRange;
    }

    /**
     * Sets the value of the maximumAllocationInvestmentPercentSecondRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximumAllocationInvestmentPercentSecondRange(BigDecimal value) {
        this.maximumAllocationInvestmentPercentSecondRange = value;
    }

    /**
     * Gets the value of the minimumAllocationInvestmentAmountCurrencyFirstRange property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinimumAllocationInvestmentAmountCurrencyFirstRange() {
        return minimumAllocationInvestmentAmountCurrencyFirstRange;
    }

    /**
     * Sets the value of the minimumAllocationInvestmentAmountCurrencyFirstRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinimumAllocationInvestmentAmountCurrencyFirstRange(String value) {
        this.minimumAllocationInvestmentAmountCurrencyFirstRange = value;
    }

    /**
     * Gets the value of the minimumAllocationInvestmentAmountCurrencySecondRange property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinimumAllocationInvestmentAmountCurrencySecondRange() {
        return minimumAllocationInvestmentAmountCurrencySecondRange;
    }

    /**
     * Sets the value of the minimumAllocationInvestmentAmountCurrencySecondRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinimumAllocationInvestmentAmountCurrencySecondRange(String value) {
        this.minimumAllocationInvestmentAmountCurrencySecondRange = value;
    }

    /**
     * Gets the value of the minimumAllocationInvestmentAmountFirstRange property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMinimumAllocationInvestmentAmountFirstRange() {
        return minimumAllocationInvestmentAmountFirstRange;
    }

    /**
     * Sets the value of the minimumAllocationInvestmentAmountFirstRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMinimumAllocationInvestmentAmountFirstRange(BigDecimal value) {
        this.minimumAllocationInvestmentAmountFirstRange = value;
    }

    /**
     * Gets the value of the minimumAllocationInvestmentAmountSecondRange property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMinimumAllocationInvestmentAmountSecondRange() {
        return minimumAllocationInvestmentAmountSecondRange;
    }

    /**
     * Sets the value of the minimumAllocationInvestmentAmountSecondRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMinimumAllocationInvestmentAmountSecondRange(BigDecimal value) {
        this.minimumAllocationInvestmentAmountSecondRange = value;
    }

    /**
     * Gets the value of the minimumAllocationInvestmentPercentFirstRange property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMinimumAllocationInvestmentPercentFirstRange() {
        return minimumAllocationInvestmentPercentFirstRange;
    }

    /**
     * Sets the value of the minimumAllocationInvestmentPercentFirstRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMinimumAllocationInvestmentPercentFirstRange(BigDecimal value) {
        this.minimumAllocationInvestmentPercentFirstRange = value;
    }

    /**
     * Gets the value of the minimumAllocationInvestmentPercentSecondRange property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMinimumAllocationInvestmentPercentSecondRange() {
        return minimumAllocationInvestmentPercentSecondRange;
    }

    /**
     * Sets the value of the minimumAllocationInvestmentPercentSecondRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMinimumAllocationInvestmentPercentSecondRange(BigDecimal value) {
        this.minimumAllocationInvestmentPercentSecondRange = value;
    }

}
