
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RetrieveGoalSolutionDetailWSResponse }
     * 
     */
    public RetrieveGoalSolutionDetailWSResponse createRetrieveGoalSolutionDetailWSResponse() {
        return new RetrieveGoalSolutionDetailWSResponse();
    }

    /**
     * Create an instance of {@link RetrieveGoalSolutionDetailWSResponse.Context }
     * 
     */
    public RetrieveGoalSolutionDetailWSResponse.Context createRetrieveGoalSolutionDetailWSResponseContext() {
        return new RetrieveGoalSolutionDetailWSResponse.Context();
    }

    /**
     * Create an instance of {@link RecordGoalSolutionDetailWSRequest }
     * 
     */
    public RecordGoalSolutionDetailWSRequest createRecordGoalSolutionDetailWSRequest() {
        return new RecordGoalSolutionDetailWSRequest();
    }

    /**
     * Create an instance of {@link RecordGoalSolutionDetailWSRequest.Context }
     * 
     */
    public RecordGoalSolutionDetailWSRequest.Context createRecordGoalSolutionDetailWSRequestContext() {
        return new RecordGoalSolutionDetailWSRequest.Context();
    }

    /**
     * Create an instance of {@link PortfolioCalculationResult }
     * 
     */
    public PortfolioCalculationResult createPortfolioCalculationResult() {
        return new PortfolioCalculationResult();
    }

    /**
     * Create an instance of {@link Notes }
     * 
     */
    public Notes createNotes() {
        return new Notes();
    }

    /**
     * Create an instance of {@link PurposeBuyingProduct }
     * 
     */
    public PurposeBuyingProduct createPurposeBuyingProduct() {
        return new PurposeBuyingProduct();
    }

    /**
     * Create an instance of {@link ReviewInvestmentsWSResponse }
     * 
     */
    public ReviewInvestmentsWSResponse createReviewInvestmentsWSResponse() {
        return new ReviewInvestmentsWSResponse();
    }

    /**
     * Create an instance of {@link Affordability }
     * 
     */
    public Affordability createAffordability() {
        return new Affordability();
    }

    /**
     * Create an instance of {@link AssetConcentration }
     * 
     */
    public AssetConcentration createAssetConcentration() {
        return new AssetConcentration();
    }

    /**
     * Create an instance of {@link CalculateAggregateAffordabilityRatioWSRequest }
     * 
     */
    public CalculateAggregateAffordabilityRatioWSRequest createCalculateAggregateAffordabilityRatioWSRequest() {
        return new CalculateAggregateAffordabilityRatioWSRequest();
    }

    /**
     * Create an instance of {@link RecordGoalSolutionDetailWSResponse }
     * 
     */
    public RecordGoalSolutionDetailWSResponse createRecordGoalSolutionDetailWSResponse() {
        return new RecordGoalSolutionDetailWSResponse();
    }

    /**
     * Create an instance of {@link OptOutDetails }
     * 
     */
    public OptOutDetails createOptOutDetails() {
        return new OptOutDetails();
    }

    /**
     * Create an instance of {@link PortfolioAssetAllocation }
     * 
     */
    public PortfolioAssetAllocation createPortfolioAssetAllocation() {
        return new PortfolioAssetAllocation();
    }

    /**
     * Create an instance of {@link StaffAdviseSeg }
     * 
     */
    public StaffAdviseSeg createStaffAdviseSeg() {
        return new StaffAdviseSeg();
    }

    /**
     * Create an instance of {@link NeedEvaluation }
     * 
     */
    public NeedEvaluation createNeedEvaluation() {
        return new NeedEvaluation();
    }

    /**
     * Create an instance of {@link CalculateAggregateAffordabilityRatioWSResponse }
     * 
     */
    public CalculateAggregateAffordabilityRatioWSResponse createCalculateAggregateAffordabilityRatioWSResponse() {
        return new CalculateAggregateAffordabilityRatioWSResponse();
    }

    /**
     * Create an instance of {@link InvestmentProductList }
     * 
     */
    public InvestmentProductList createInvestmentProductList() {
        return new InvestmentProductList();
    }

    /**
     * Create an instance of {@link AmountDeviationPercentage }
     * 
     */
    public AmountDeviationPercentage createAmountDeviationPercentage() {
        return new AmountDeviationPercentage();
    }

    /**
     * Create an instance of {@link CurrentPortfolioAllocation }
     * 
     */
    public CurrentPortfolioAllocation createCurrentPortfolioAllocation() {
        return new CurrentPortfolioAllocation();
    }

    /**
     * Create an instance of {@link ProductId }
     * 
     */
    public ProductId createProductId() {
        return new ProductId();
    }

    /**
     * Create an instance of {@link RequestCriteria }
     * 
     */
    public RequestCriteria createRequestCriteria() {
        return new RequestCriteria();
    }

    /**
     * Create an instance of {@link Suitability }
     * 
     */
    public Suitability createSuitability() {
        return new Suitability();
    }

    /**
     * Create an instance of {@link ExistingHolding }
     * 
     */
    public ExistingHolding createExistingHolding() {
        return new ExistingHolding();
    }

    /**
     * Create an instance of {@link CacheInfo }
     * 
     */
    public CacheInfo createCacheInfo() {
        return new CacheInfo();
    }

    /**
     * Create an instance of {@link SubserviceId }
     * 
     */
    public SubserviceId createSubserviceId() {
        return new SubserviceId();
    }

    /**
     * Create an instance of {@link CalculateRiskCapacityWSRequest }
     * 
     */
    public CalculateRiskCapacityWSRequest createCalculateRiskCapacityWSRequest() {
        return new CalculateRiskCapacityWSRequest();
    }

    /**
     * Create an instance of {@link ProductConcentrationRiskCalculationResult }
     * 
     */
    public ProductConcentrationRiskCalculationResult createProductConcentrationRiskCalculationResult() {
        return new ProductConcentrationRiskCalculationResult();
    }

    /**
     * Create an instance of {@link ProductInfo }
     * 
     */
    public ProductInfo createProductInfo() {
        return new ProductInfo();
    }

    /**
     * Create an instance of {@link ControlAdviceJourney }
     * 
     */
    public ControlAdviceJourney createControlAdviceJourney() {
        return new ControlAdviceJourney();
    }

    /**
     * Create an instance of {@link PortfolioAssetAllocationSummary }
     * 
     */
    public PortfolioAssetAllocationSummary createPortfolioAssetAllocationSummary() {
        return new PortfolioAssetAllocationSummary();
    }

    /**
     * Create an instance of {@link AssetConcentrationValidation }
     * 
     */
    public AssetConcentrationValidation createAssetConcentrationValidation() {
        return new AssetConcentrationValidation();
    }

    /**
     * Create an instance of {@link RecordActivityAuditLogWSRequest }
     * 
     */
    public RecordActivityAuditLogWSRequest createRecordActivityAuditLogWSRequest() {
        return new RecordActivityAuditLogWSRequest();
    }

    /**
     * Create an instance of {@link PortfolioCalculationParameter }
     * 
     */
    public PortfolioCalculationParameter createPortfolioCalculationParameter() {
        return new PortfolioCalculationParameter();
    }

    /**
     * Create an instance of {@link ModelPortfolioAssetClassAllocation }
     * 
     */
    public ModelPortfolioAssetClassAllocation createModelPortfolioAssetClassAllocation() {
        return new ModelPortfolioAssetClassAllocation();
    }

    /**
     * Create an instance of {@link CurrentPortfolioAllocationList }
     * 
     */
    public CurrentPortfolioAllocationList createCurrentPortfolioAllocationList() {
        return new CurrentPortfolioAllocationList();
    }

    /**
     * Create an instance of {@link CalculateRiskCapacityWSResponse }
     * 
     */
    public CalculateRiskCapacityWSResponse createCalculateRiskCapacityWSResponse() {
        return new CalculateRiskCapacityWSResponse();
    }

    /**
     * Create an instance of {@link RetrieveGoalSummaryListByLeadIdWSResponse }
     * 
     */
    public RetrieveGoalSummaryListByLeadIdWSResponse createRetrieveGoalSummaryListByLeadIdWSResponse() {
        return new RetrieveGoalSummaryListByLeadIdWSResponse();
    }

    /**
     * Create an instance of {@link AdditionalItem }
     * 
     */
    public AdditionalItem createAdditionalItem() {
        return new AdditionalItem();
    }

    /**
     * Create an instance of {@link PiqQuestAndAnsDetails }
     * 
     */
    public PiqQuestAndAnsDetails createPiqQuestAndAnsDetails() {
        return new PiqQuestAndAnsDetails();
    }

    /**
     * Create an instance of {@link ReviewInvestmentsWSRequest }
     * 
     */
    public ReviewInvestmentsWSRequest createReviewInvestmentsWSRequest() {
        return new ReviewInvestmentsWSRequest();
    }

    /**
     * Create an instance of {@link AffordabilityValidation }
     * 
     */
    public AffordabilityValidation createAffordabilityValidation() {
        return new AffordabilityValidation();
    }

    /**
     * Create an instance of {@link ProductList }
     * 
     */
    public ProductList createProductList() {
        return new ProductList();
    }

    /**
     * Create an instance of {@link AccountDescription }
     * 
     */
    public AccountDescription createAccountDescription() {
        return new AccountDescription();
    }

    /**
     * Create an instance of {@link AccountAttribute }
     * 
     */
    public AccountAttribute createAccountAttribute() {
        return new AccountAttribute();
    }

    /**
     * Create an instance of {@link RequestCriteriaValueAttribute }
     * 
     */
    public RequestCriteriaValueAttribute createRequestCriteriaValueAttribute() {
        return new RequestCriteriaValueAttribute();
    }

    /**
     * Create an instance of {@link ProductTable }
     * 
     */
    public ProductTable createProductTable() {
        return new ProductTable();
    }

    /**
     * Create an instance of {@link RecordGoalPlannerInfoWSRequest }
     * 
     */
    public RecordGoalPlannerInfoWSRequest createRecordGoalPlannerInfoWSRequest() {
        return new RecordGoalPlannerInfoWSRequest();
    }

    /**
     * Create an instance of {@link ModelPortfolioAssetClassAllocationList }
     * 
     */
    public ModelPortfolioAssetClassAllocationList createModelPortfolioAssetClassAllocationList() {
        return new ModelPortfolioAssetClassAllocationList();
    }

    /**
     * Create an instance of {@link CalculateGoalPortfolioWSRequest }
     * 
     */
    public CalculateGoalPortfolioWSRequest createCalculateGoalPortfolioWSRequest() {
        return new CalculateGoalPortfolioWSRequest();
    }

    /**
     * Create an instance of {@link CalculateGoalPortfolioWSResponse }
     * 
     */
    public CalculateGoalPortfolioWSResponse createCalculateGoalPortfolioWSResponse() {
        return new CalculateGoalPortfolioWSResponse();
    }

    /**
     * Create an instance of {@link RetrieveManagedSolutionDetailWSRequest }
     * 
     */
    public RetrieveManagedSolutionDetailWSRequest createRetrieveManagedSolutionDetailWSRequest() {
        return new RetrieveManagedSolutionDetailWSRequest();
    }

    /**
     * Create an instance of {@link PortfolioAssetAllocationDetail }
     * 
     */
    public PortfolioAssetAllocationDetail createPortfolioAssetAllocationDetail() {
        return new PortfolioAssetAllocationDetail();
    }

    /**
     * Create an instance of {@link RetrieveProductSearchResultWSRequest }
     * 
     */
    public RetrieveProductSearchResultWSRequest createRetrieveProductSearchResultWSRequest() {
        return new RetrieveProductSearchResultWSRequest();
    }

    /**
     * Create an instance of {@link MultipleAdviceStyleDetails }
     * 
     */
    public MultipleAdviceStyleDetails createMultipleAdviceStyleDetails() {
        return new MultipleAdviceStyleDetails();
    }

    /**
     * Create an instance of {@link Attribute }
     * 
     */
    public Attribute createAttribute() {
        return new Attribute();
    }

    /**
     * Create an instance of {@link GoalSummary }
     * 
     */
    public GoalSummary createGoalSummary() {
        return new GoalSummary();
    }

    /**
     * Create an instance of {@link RetrieveGoalSummaryListWSRequest }
     * 
     */
    public RetrieveGoalSummaryListWSRequest createRetrieveGoalSummaryListWSRequest() {
        return new RetrieveGoalSummaryListWSRequest();
    }

    /**
     * Create an instance of {@link AccountAllocationSummary }
     * 
     */
    public AccountAllocationSummary createAccountAllocationSummary() {
        return new AccountAllocationSummary();
    }

    /**
     * Create an instance of {@link AlternativeProduct }
     * 
     */
    public AlternativeProduct createAlternativeProduct() {
        return new AlternativeProduct();
    }

    /**
     * Create an instance of {@link RetrieveGoalSummaryListWSResponse }
     * 
     */
    public RetrieveGoalSummaryListWSResponse createRetrieveGoalSummaryListWSResponse() {
        return new RetrieveGoalSummaryListWSResponse();
    }

    /**
     * Create an instance of {@link RecordGoalPlannerInfoWSResponse }
     * 
     */
    public RecordGoalPlannerInfoWSResponse createRecordGoalPlannerInfoWSResponse() {
        return new RecordGoalPlannerInfoWSResponse();
    }

    /**
     * Create an instance of {@link PiqAnswerValidationInfo }
     * 
     */
    public PiqAnswerValidationInfo createPiqAnswerValidationInfo() {
        return new PiqAnswerValidationInfo();
    }

    /**
     * Create an instance of {@link RetrieveManagedSolutionDetailWSResponse }
     * 
     */
    public RetrieveManagedSolutionDetailWSResponse createRetrieveManagedSolutionDetailWSResponse() {
        return new RetrieveManagedSolutionDetailWSResponse();
    }

    /**
     * Create an instance of {@link RetrieveGoalPlannerInfoWSRequest }
     * 
     */
    public RetrieveGoalPlannerInfoWSRequest createRetrieveGoalPlannerInfoWSRequest() {
        return new RetrieveGoalPlannerInfoWSRequest();
    }

    /**
     * Create an instance of {@link SelectionDetail }
     * 
     */
    public SelectionDetail createSelectionDetail() {
        return new SelectionDetail();
    }

    /**
     * Create an instance of {@link Declaration }
     * 
     */
    public Declaration createDeclaration() {
        return new Declaration();
    }

    /**
     * Create an instance of {@link RetrieveGoalSolutionDetailWSRequest }
     * 
     */
    public RetrieveGoalSolutionDetailWSRequest createRetrieveGoalSolutionDetailWSRequest() {
        return new RetrieveGoalSolutionDetailWSRequest();
    }

    /**
     * Create an instance of {@link RetrieveGoalSummaryListByLeadIdWSRequest }
     * 
     */
    public RetrieveGoalSummaryListByLeadIdWSRequest createRetrieveGoalSummaryListByLeadIdWSRequest() {
        return new RetrieveGoalSummaryListByLeadIdWSRequest();
    }

    /**
     * Create an instance of {@link RetrieveGoalPlannerInfoWSResponse }
     * 
     */
    public RetrieveGoalPlannerInfoWSResponse createRetrieveGoalPlannerInfoWSResponse() {
        return new RetrieveGoalPlannerInfoWSResponse();
    }

    /**
     * Create an instance of {@link ActualPortfolioAllocation }
     * 
     */
    public ActualPortfolioAllocation createActualPortfolioAllocation() {
        return new ActualPortfolioAllocation();
    }

    /**
     * Create an instance of {@link RetrieveProductSearchResultWSResponse }
     * 
     */
    public RetrieveProductSearchResultWSResponse createRetrieveProductSearchResultWSResponse() {
        return new RetrieveProductSearchResultWSResponse();
    }

    /**
     * Create an instance of {@link AccountAllocationDetail }
     * 
     */
    public AccountAllocationDetail createAccountAllocationDetail() {
        return new AccountAllocationDetail();
    }

    /**
     * Create an instance of {@link RecordActivityAuditLogWSResponse }
     * 
     */
    public RecordActivityAuditLogWSResponse createRecordActivityAuditLogWSResponse() {
        return new RecordActivityAuditLogWSResponse();
    }

    /**
     * Create an instance of {@link EligibleForControlAdvice }
     * 
     */
    public EligibleForControlAdvice createEligibleForControlAdvice() {
        return new EligibleForControlAdvice();
    }

    /**
     * Create an instance of {@link RetrieveGoalSolutionDetailWSResponse.Context.Entry }
     * 
     */
    public RetrieveGoalSolutionDetailWSResponse.Context.Entry createRetrieveGoalSolutionDetailWSResponseContextEntry() {
        return new RetrieveGoalSolutionDetailWSResponse.Context.Entry();
    }

    /**
     * Create an instance of {@link RecordGoalSolutionDetailWSRequest.Context.Entry }
     * 
     */
    public RecordGoalSolutionDetailWSRequest.Context.Entry createRecordGoalSolutionDetailWSRequestContextEntry() {
        return new RecordGoalSolutionDetailWSRequest.Context.Entry();
    }

}
