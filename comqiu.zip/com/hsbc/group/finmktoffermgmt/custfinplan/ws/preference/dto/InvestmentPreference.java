
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.preference.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for investmentPreference complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="investmentPreference">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="investmentPreferenceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="investmentPreferenceTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "investmentPreference", propOrder = {
    "investmentPreferenceCode",
    "investmentPreferenceTypeCode"
})
public class InvestmentPreference {

    protected String investmentPreferenceCode;
    protected String investmentPreferenceTypeCode;

    /**
     * Gets the value of the investmentPreferenceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentPreferenceCode() {
        return investmentPreferenceCode;
    }

    /**
     * Sets the value of the investmentPreferenceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentPreferenceCode(String value) {
        this.investmentPreferenceCode = value;
    }

    /**
     * Gets the value of the investmentPreferenceTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentPreferenceTypeCode() {
        return investmentPreferenceTypeCode;
    }

    /**
     * Sets the value of the investmentPreferenceTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentPreferenceTypeCode(String value) {
        this.investmentPreferenceTypeCode = value;
    }

}
