
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.preference.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for investmentAppropriateness complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="investmentAppropriateness">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="appropriatenessFeedback" type="{http://dto.preference.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}appropriatenessFeedback" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="appropriatenessResultCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="appropriatenessTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="interestedIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "investmentAppropriateness", propOrder = {
    "appropriatenessFeedback",
    "appropriatenessResultCode",
    "appropriatenessTypeCode",
    "interestedIndicator"
})
public class InvestmentAppropriateness {

    @XmlElement(nillable = true)
    protected List<AppropriatenessFeedback> appropriatenessFeedback;
    protected String appropriatenessResultCode;
    protected String appropriatenessTypeCode;
    protected String interestedIndicator;

    /**
     * Gets the value of the appropriatenessFeedback property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the appropriatenessFeedback property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAppropriatenessFeedback().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AppropriatenessFeedback }
     * 
     * 
     */
    public List<AppropriatenessFeedback> getAppropriatenessFeedback() {
        if (appropriatenessFeedback == null) {
            appropriatenessFeedback = new ArrayList<AppropriatenessFeedback>();
        }
        return this.appropriatenessFeedback;
    }

    /**
     * Gets the value of the appropriatenessResultCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppropriatenessResultCode() {
        return appropriatenessResultCode;
    }

    /**
     * Sets the value of the appropriatenessResultCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppropriatenessResultCode(String value) {
        this.appropriatenessResultCode = value;
    }

    /**
     * Gets the value of the appropriatenessTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppropriatenessTypeCode() {
        return appropriatenessTypeCode;
    }

    /**
     * Sets the value of the appropriatenessTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppropriatenessTypeCode(String value) {
        this.appropriatenessTypeCode = value;
    }

    /**
     * Gets the value of the interestedIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterestedIndicator() {
        return interestedIndicator;
    }

    /**
     * Sets the value of the interestedIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterestedIndicator(String value) {
        this.interestedIndicator = value;
    }

}
