
package com.hsbc.group.finmktoffermgmt.custfinplan.svc.model.ws.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fundingDetailByWrapper complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="fundingDetailByWrapper">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fundAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="fundCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fundMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="fundMonthlyCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="wrapperType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fundingDetailByWrapper", propOrder = {
    "fundAmount",
    "fundCurrencyCode",
    "fundMonthlyAmount",
    "fundMonthlyCurrencyCode",
    "wrapperType"
})
public class FundingDetailByWrapper {

    protected BigDecimal fundAmount;
    protected String fundCurrencyCode;
    protected BigDecimal fundMonthlyAmount;
    protected String fundMonthlyCurrencyCode;
    protected String wrapperType;

    /**
     * Gets the value of the fundAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundAmount() {
        return fundAmount;
    }

    /**
     * Sets the value of the fundAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundAmount(BigDecimal value) {
        this.fundAmount = value;
    }

    /**
     * Gets the value of the fundCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCurrencyCode() {
        return fundCurrencyCode;
    }

    /**
     * Sets the value of the fundCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCurrencyCode(String value) {
        this.fundCurrencyCode = value;
    }

    /**
     * Gets the value of the fundMonthlyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundMonthlyAmount() {
        return fundMonthlyAmount;
    }

    /**
     * Sets the value of the fundMonthlyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundMonthlyAmount(BigDecimal value) {
        this.fundMonthlyAmount = value;
    }

    /**
     * Gets the value of the fundMonthlyCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundMonthlyCurrencyCode() {
        return fundMonthlyCurrencyCode;
    }

    /**
     * Sets the value of the fundMonthlyCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundMonthlyCurrencyCode(String value) {
        this.fundMonthlyCurrencyCode = value;
    }

    /**
     * Gets the value of the wrapperType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperType() {
        return wrapperType;
    }

    /**
     * Sets the value of the wrapperType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperType(String value) {
        this.wrapperType = value;
    }

}
