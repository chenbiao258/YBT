
package com.hsbc.group.finmktoffermgmt.custfinplan.svc.model.ws.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fundingDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="fundingDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fundAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="fundCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fundMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="fundMonthlyCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fundingDetailByWrapper" type="{http://dto.ws.model.svc.custfinplan.finmktoffermgmt.group.hsbc.com/}fundingDetailByWrapper" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fundingDetails", propOrder = {
    "fundAmount",
    "fundCurrencyCode",
    "fundMonthlyAmount",
    "fundMonthlyCurrencyCode",
    "fundingDetailByWrapper"
})
public class FundingDetails {

    protected BigDecimal fundAmount;
    protected String fundCurrencyCode;
    protected BigDecimal fundMonthlyAmount;
    protected String fundMonthlyCurrencyCode;
    @XmlElement(nillable = true)
    protected List<FundingDetailByWrapper> fundingDetailByWrapper;

    /**
     * Gets the value of the fundAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundAmount() {
        return fundAmount;
    }

    /**
     * Sets the value of the fundAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundAmount(BigDecimal value) {
        this.fundAmount = value;
    }

    /**
     * Gets the value of the fundCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCurrencyCode() {
        return fundCurrencyCode;
    }

    /**
     * Sets the value of the fundCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCurrencyCode(String value) {
        this.fundCurrencyCode = value;
    }

    /**
     * Gets the value of the fundMonthlyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundMonthlyAmount() {
        return fundMonthlyAmount;
    }

    /**
     * Sets the value of the fundMonthlyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundMonthlyAmount(BigDecimal value) {
        this.fundMonthlyAmount = value;
    }

    /**
     * Gets the value of the fundMonthlyCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundMonthlyCurrencyCode() {
        return fundMonthlyCurrencyCode;
    }

    /**
     * Sets the value of the fundMonthlyCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundMonthlyCurrencyCode(String value) {
        this.fundMonthlyCurrencyCode = value;
    }

    /**
     * Gets the value of the fundingDetailByWrapper property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fundingDetailByWrapper property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFundingDetailByWrapper().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FundingDetailByWrapper }
     * 
     * 
     */
    public List<FundingDetailByWrapper> getFundingDetailByWrapper() {
        if (fundingDetailByWrapper == null) {
            fundingDetailByWrapper = new ArrayList<FundingDetailByWrapper>();
        }
        return this.fundingDetailByWrapper;
    }

}
