
package com.hsbc.group.finmktoffermgmt.custfinplan.svc.model.ws.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for financialGoal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="financialGoal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="goalCompletionDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="goalDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalMonthCount" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="goalObjectiveTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalTargetAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="goalTargetCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="goalTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jurisdictionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="needTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="periodicityGoalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recordCreateDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="recordUpdateDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="skipRiskProfilingIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "financialGoal", propOrder = {
    "goalCompletionDateTime",
    "goalDescription",
    "goalMonthCount",
    "goalObjectiveTypeCode",
    "goalTargetAmount",
    "goalTargetCurrencyCode",
    "goalTypeCode",
    "jurisdictionType",
    "needTypeCode",
    "periodicityGoalCode",
    "recordCreateDateTime",
    "recordUpdateDateTime",
    "skipRiskProfilingIndicator"
})
public class FinancialGoal {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalCompletionDateTime;
    protected String goalDescription;
    protected int goalMonthCount;
    protected String goalObjectiveTypeCode;
    protected BigDecimal goalTargetAmount;
    protected String goalTargetCurrencyCode;
    protected String goalTypeCode;
    protected String jurisdictionType;
    protected String needTypeCode;
    protected String periodicityGoalCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar recordCreateDateTime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar recordUpdateDateTime;
    protected String skipRiskProfilingIndicator;

    /**
     * Gets the value of the goalCompletionDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalCompletionDateTime() {
        return goalCompletionDateTime;
    }

    /**
     * Sets the value of the goalCompletionDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalCompletionDateTime(XMLGregorianCalendar value) {
        this.goalCompletionDateTime = value;
    }

    /**
     * Gets the value of the goalDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalDescription() {
        return goalDescription;
    }

    /**
     * Sets the value of the goalDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalDescription(String value) {
        this.goalDescription = value;
    }

    /**
     * Gets the value of the goalMonthCount property.
     * 
     */
    public int getGoalMonthCount() {
        return goalMonthCount;
    }

    /**
     * Sets the value of the goalMonthCount property.
     * 
     */
    public void setGoalMonthCount(int value) {
        this.goalMonthCount = value;
    }

    /**
     * Gets the value of the goalObjectiveTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalObjectiveTypeCode() {
        return goalObjectiveTypeCode;
    }

    /**
     * Sets the value of the goalObjectiveTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalObjectiveTypeCode(String value) {
        this.goalObjectiveTypeCode = value;
    }

    /**
     * Gets the value of the goalTargetAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoalTargetAmount() {
        return goalTargetAmount;
    }

    /**
     * Sets the value of the goalTargetAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoalTargetAmount(BigDecimal value) {
        this.goalTargetAmount = value;
    }

    /**
     * Gets the value of the goalTargetCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTargetCurrencyCode() {
        return goalTargetCurrencyCode;
    }

    /**
     * Sets the value of the goalTargetCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTargetCurrencyCode(String value) {
        this.goalTargetCurrencyCode = value;
    }

    /**
     * Gets the value of the goalTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTypeCode() {
        return goalTypeCode;
    }

    /**
     * Sets the value of the goalTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTypeCode(String value) {
        this.goalTypeCode = value;
    }

    /**
     * Gets the value of the jurisdictionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJurisdictionType() {
        return jurisdictionType;
    }

    /**
     * Sets the value of the jurisdictionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJurisdictionType(String value) {
        this.jurisdictionType = value;
    }

    /**
     * Gets the value of the needTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeedTypeCode() {
        return needTypeCode;
    }

    /**
     * Sets the value of the needTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeedTypeCode(String value) {
        this.needTypeCode = value;
    }

    /**
     * Gets the value of the periodicityGoalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicityGoalCode() {
        return periodicityGoalCode;
    }

    /**
     * Sets the value of the periodicityGoalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicityGoalCode(String value) {
        this.periodicityGoalCode = value;
    }

    /**
     * Gets the value of the recordCreateDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRecordCreateDateTime() {
        return recordCreateDateTime;
    }

    /**
     * Sets the value of the recordCreateDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRecordCreateDateTime(XMLGregorianCalendar value) {
        this.recordCreateDateTime = value;
    }

    /**
     * Gets the value of the recordUpdateDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRecordUpdateDateTime() {
        return recordUpdateDateTime;
    }

    /**
     * Sets the value of the recordUpdateDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRecordUpdateDateTime(XMLGregorianCalendar value) {
        this.recordUpdateDateTime = value;
    }

    /**
     * Gets the value of the skipRiskProfilingIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSkipRiskProfilingIndicator() {
        return skipRiskProfilingIndicator;
    }

    /**
     * Sets the value of the skipRiskProfilingIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSkipRiskProfilingIndicator(String value) {
        this.skipRiskProfilingIndicator = value;
    }

}
